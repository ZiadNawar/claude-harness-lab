import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { test } from 'node:test';
import { CorruptLogError, ManualClock, openQueue, RecordTooLargeError } from '../src/index.mjs';
import { encodeFrame } from '../src/frame.mjs';
import { crashChild, tempDir } from './helpers/tmp.mjs';

const POWER_LOSS = { WALQ_SIMULATE_POWER_LOSS: '1' };

function seed(t, count = 3) {
  const dir = tempDir(t);
  const clock = new ManualClock(1_000);
  const queue = openQueue(dir, { clock });
  for (let i = 0; i < count; i += 1) queue.enqueue('x', `job ${i}`);
  queue.close();
  return { dir, clock, log: path.join(dir, 'wal.log') };
}

const payloads = (queue) => queue.listJobs().map((j) => j.payload);

test('writes after a cut-off write are not lost behind it (G3)', (t) => {
  const { dir, clock, log } = seed(t);
  fs.truncateSync(log, fs.statSync(log).size - 5);

  const first = openQueue(dir, { clock });
  assert.deepEqual(payloads(first), ['job 0', 'job 1']);
  first.enqueue('x', 'after');
  first.close();

  // The old code left the stub in the middle of the log and refused to open here.
  const second = openQueue(dir, { clock });
  assert.deepEqual(payloads(second), ['job 0', 'job 1', 'after']);
});

test('a tail that fails its checksum is also removed before the next write', (t) => {
  const { dir, clock, log } = seed(t);
  const bytes = fs.readFileSync(log);
  bytes[bytes.length - 2] ^= 0xff;
  fs.writeFileSync(log, bytes);

  const first = openQueue(dir, { clock });
  assert.equal(first.stats().tornTailsDropped, 1);
  first.enqueue('x', 'after');
  first.close();
  assert.deepEqual(payloads(openQueue(dir, { clock })), ['job 0', 'job 1', 'after']);
});

test('a second process sees the stub removed and carries on (several writers)', (t) => {
  const { dir, clock, log } = seed(t);
  fs.truncateSync(log, fs.statSync(log).size - 5);
  const a = openQueue(dir, { clock });
  const b = openQueue(dir, { clock });
  a.enqueue('x', 'from a');
  b.enqueue('x', 'from b');
  a.enqueue('x', 'from a again');
  assert.deepEqual(payloads(b), ['job 0', 'job 1', 'from a', 'from b', 'from a again']);
  assert.deepEqual(payloads(openQueue(dir, { clock })), payloads(b));
});

test('damage in the middle of the log is reported with its offset and nothing is touched (G4)', (t) => {
  const { dir, clock, log } = seed(t);
  const before = fs.readFileSync(log);
  const first = encodeFrame({ t: 'enqueue', id: 'j1', type: 'x', payload: 'job 0', key: null, priority: 0, maxAttempts: 5, availableAt: 1_000, at: 1_000 });
  const victim = 20 + first.length + 12;
  before[victim] ^= 0xff;
  fs.writeFileSync(log, before);
  const damaged = Buffer.from(before);

  assert.throws(() => openQueue(dir, { clock }), (err) => {
    assert.ok(err instanceof CorruptLogError);
    assert.equal(err.offset, 20 + first.length);
    return true;
  });
  assert.ok(fs.readFileSync(log).equals(damaged), 'the log must be left as it was found');
  // and it keeps saying so, rather than half-working
  assert.throws(() => openQueue(dir, { clock }), CorruptLogError);
});

test('a bad checksum with records after it is damage, not a cut-off write', (t) => {
  const { dir, clock, log } = seed(t, 2);
  const bytes = fs.readFileSync(log);
  bytes[bytes.length - 2] ^= 0xff;
  fs.writeFileSync(log, Buffer.concat([bytes, encodeFrame({ t: 'unknown-but-valid' })]));
  assert.throws(() => openQueue(dir, { clock }), CorruptLogError);
});

test('a log of many megabytes opens completely (G5)', { timeout: 60_000 }, (t) => {
  const dir = tempDir(t);
  const clock = new ManualClock(0);
  const writer = openQueue(dir, { clock, compactAfterBytes: 0 });
  const pad = 'x'.repeat(2_000);
  const total = 3_000; // ~6 MB of log, several read chunks
  for (let start = 0; start < total; start += 500) {
    writer.enqueueMany(Array.from({ length: 500 }, (_, n) => ({ type: 'x', payload: { n: start + n, pad } })));
  }
  const job = writer.claim('w');
  writer.close();

  assert.ok(fs.statSync(path.join(dir, 'wal.log')).size > 5 * 1024 * 1024);
  const reopened = openQueue(dir, { clock, compactAfterBytes: 0 });
  assert.equal(reopened.stats().total, total);
  assert.equal(reopened.getJob(job.id).status, 'leased');
  assert.equal(reopened.stats().tornTailsDropped, 0);
  assert.equal(reopened.stats().logBytes, fs.statSync(path.join(dir, 'wal.log')).size);
});

test('a single record bigger than a read chunk survives, and so does what follows it', (t) => {
  const dir = tempDir(t);
  const clock = new ManualClock(0);
  const queue = openQueue(dir, { clock, compactAfterBytes: 0 });
  queue.enqueue('x', 'small');
  const big = 'b'.repeat(3 * 1024 * 1024);
  const { id } = queue.enqueue('x', big);
  queue.enqueue('x', 'small too');
  queue.close();

  const reopened = openQueue(dir, { clock, compactAfterBytes: 0 });
  assert.equal(reopened.stats().total, 3);
  assert.equal(reopened.getJob(id).payload.length, big.length);
  assert.equal(reopened.stats().tornTailsDropped, 0);
  reopened.compact();
  assert.equal(openQueue(dir, { clock }).getJob(id).payload.length, big.length);
});

test('a record over the format limit is refused before anything is written', (t) => {
  const { dir, clock, log } = seed(t, 1);
  const before = fs.readFileSync(log);
  const queue = openQueue(dir, { clock });
  assert.throws(() => queue.enqueue('x', 'z'.repeat(65 * 1024 * 1024)), RecordTooLargeError);
  assert.ok(fs.readFileSync(log).equals(before));
  queue.enqueue('x', 'still fine');
  assert.equal(openQueue(dir, { clock }).stats().total, 2);
});

test('an acknowledged complete survives power loss (G1)', async (t) => {
  const dir = tempDir(t);
  const seeded = openQueue(dir);
  const { id } = seeded.enqueue('x', 1);
  seeded.close();
  const run = await crashChild(t, dir, 'complete', {
    env: { ...POWER_LOSS, WALQ_FAILPOINTS: 'wal.after-fsync#complete=kill' },
  });
  assert.ok(run.killed, run.stderr || 'the failpoint should have fired');
  assert.equal(openQueue(dir).getJob(id).status, 'done');
});

for (const point of ['wal.before-append', 'wal.mid-append', 'wal.after-write']) {
  test(`a power cut at ${point} leaves a queue that opens and has only acknowledged work`, async (t) => {
    const dir = tempDir(t);
    const seeded = openQueue(dir);
    seeded.enqueue('x', 'acked');
    seeded.close();
    const run = await crashChild(t, dir, 'enqueue', {
      args: { n: 1 },
      env: { ...POWER_LOSS, WALQ_FAILPOINTS: `${point}=kill` },
    });
    assert.ok(run.killed, run.stderr || 'the failpoint should have fired');
    const queue = openQueue(dir);
    assert.deepEqual(payloads(queue), ['acked']);
    queue.enqueue('x', 'later');
    assert.deepEqual(payloads(openQueue(dir)), ['acked', 'later']);
  });
}

test('a process killed mid-append without power loss leaves a stub that is cleaned up', async (t) => {
  const dir = tempDir(t);
  const seeded = openQueue(dir);
  seeded.enqueue('x', 'acked');
  seeded.close();
  const run = await crashChild(t, dir, 'enqueue', {
    args: { n: 1, padding: 200 },
    env: { WALQ_FAILPOINTS: 'wal.mid-append=kill' },
  });
  assert.ok(run.killed, run.stderr || 'the failpoint should have fired');
  const log = path.join(dir, 'wal.log');
  const queue = openQueue(dir);
  assert.equal(queue.stats().tornTailsDropped, 1);
  queue.enqueue('x', 'later');
  queue.close();
  const inspected = fs.statSync(log).size;
  assert.deepEqual(payloads(openQueue(dir)), ['acked', 'later']);
  assert.equal(fs.statSync(log).size, inspected);
});

test('a brand new queue survives a power cut right after its log is created (G2)', async (t) => {
  const dir = tempDir(t);
  const run = await crashChild(t, dir, 'open', {
    env: { ...POWER_LOSS, WALQ_FAILPOINTS: 'wal.after-create=kill' },
  });
  assert.ok(run.killed, run.stderr || 'the failpoint should have fired');
  const queue = openQueue(dir);
  assert.equal(queue.stats().total, 0);
});
