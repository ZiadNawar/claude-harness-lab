import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import { test } from 'node:test';
import { ManualClock, openQueue } from '../src/index.mjs';
import { crashChild, defer, tempDir } from './helpers/tmp.mjs';

function seed(t, options = {}) {
  const dir = tempDir(t);
  const queue = openQueue(dir, options);
  for (let i = 0; i < 5; i += 1) queue.enqueue('x', `job ${i}`);
  const job = queue.claim('w');
  queue.complete(job.id, job.token, 'r');
  queue.close();
  return { dir, log: path.join(dir, 'wal.log'), temp: path.join(dir, 'wal.log.compact') };
}

const summary = (queue) => queue.listJobs().map((j) => `${j.id}:${j.status}`).join(',');

test('a temp file left by a dead compaction does not stop the next one (G12)', (t) => {
  const { dir, temp } = seed(t);
  fs.writeFileSync(temp, 'half a log from a compaction that died');
  const queue = openQueue(dir);
  const before = summary(queue);
  queue.compact();
  assert.equal(summary(queue), before);
  assert.equal(fs.existsSync(temp), false);
  assert.equal(summary(openQueue(dir)), before);
});

for (const point of ['compact.after-tmp-write', 'compact.before-rename', 'compact.after-rename']) {
  for (const powerLoss of [false, true]) {
    test(`a compaction killed at ${point}${powerLoss ? ' with power loss' : ''} loses nothing and the next one works (G12)`, async (t) => {
      const { dir } = seed(t);
      const expected = summary(openQueue(dir));
      const run = await crashChild(t, dir, 'compact', {
        env: { WALQ_FAILPOINTS: `${point}=kill`, ...(powerLoss ? { WALQ_SIMULATE_POWER_LOSS: '1' } : {}) },
      });
      assert.ok(run.killed, run.stderr || 'the failpoint should have fired');
      const queue = openQueue(dir);
      assert.equal(summary(queue), expected);
      assert.ok(fs.statSync(path.join(dir, 'wal.log')).size > 20, 'the log is not empty');
      queue.enqueue('x', 'more');
      queue.compact();
      queue.compact();
      assert.equal(openQueue(dir).stats().total, 6);
    });
  }
}

test('automatic compaction recovers by itself after a compaction that died', async (t) => {
  const { dir } = seed(t);
  await crashChild(t, dir, 'compact', { env: { WALQ_FAILPOINTS: 'compact.before-rename=kill' } });
  const queue = openQueue(dir, { compactAfterBytes: 100 });
  queue.enqueue('x', 'trigger');
  assert.equal(queue.stats().lastCompactionError, null);
  assert.ok(queue.stats().generation >= 2);
});

test('a file someone holds open delays compaction but cannot break it (G12)', { skip: process.platform !== 'win32' }, (t) => {
  const { dir, log, temp } = seed(t);
  const queue = openQueue(dir, { compactAfterBytes: 0 });
  const before = summary(queue);
  const held = fs.openSync(log, 'r'); // what `tail` used to do, or a backup
  let released = false;
  const release = () => {
    if (!released) fs.closeSync(held);
    released = true;
  };
  defer(t, release);

  assert.throws(() => queue.compact(), /compaction failed/);
  assert.equal(fs.existsSync(temp), false, 'no temp file is left behind');
  assert.equal(summary(queue), before);
  queue.enqueue('x', 'still writable');
  assert.equal(openQueue(dir).stats().total, 6);

  release();
  queue.compact();
  assert.equal(queue.stats().total, 6);
  assert.equal(summary(openQueue(dir)), summary(queue));
});

test('automatic compaction failing does not fail the write, and is reported', { skip: process.platform !== 'win32' }, (t) => {
  const { dir, log } = seed(t);
  const queue = openQueue(dir, { compactAfterBytes: 100 });
  const held = fs.openSync(log, 'r');
  let released = false;
  defer(t, () => !released && fs.closeSync(held));
  const { id } = queue.enqueue('x', 'written anyway');
  assert.ok(queue.getJob(id));
  assert.match(queue.stats().lastCompactionError, /compaction failed/);
  fs.closeSync(held);
  released = true;
  queue.enqueue('x', 'again');
  assert.equal(queue.stats().lastCompactionError, null);
});

test('a brief hold on the log is waited out', { skip: process.platform !== 'win32' }, async (t) => {
  const { dir, log } = seed(t);
  const queue = openQueue(dir, { compactAfterBytes: 0 });
  const holder = spawn(process.execPath, [
    '-e',
    `const fs=require('fs');const fd=fs.openSync(${JSON.stringify(log)},'r');console.log('held');setTimeout(()=>{fs.closeSync(fd);process.exit(0)},15)`,
  ], { stdio: ['ignore', 'pipe', 'ignore'] });
  defer(t, () => holder.kill());
  await new Promise((resolve) => holder.stdout.once('data', resolve));
  // The holder lets go after 15 ms. A compaction that begins inside that window must
  // get through rather than leave the operator's `walq compact` failing at random.
  queue.compact();
  assert.equal(queue.stats().total, 5);
});

test('the log is never replaced by an empty file after power loss, at any step', async (t) => {
  for (const point of ['compact.after-tmp-write', 'compact.before-rename', 'compact.after-rename']) {
    const { dir, log } = seed(t);
    await crashChild(t, dir, 'compact', { env: { WALQ_SIMULATE_POWER_LOSS: '1', WALQ_FAILPOINTS: `${point}=kill` } });
    assert.ok(fs.statSync(log).size > 20, point);
    assert.equal(openQueue(dir).stats().total, 5, point);
  }
});

test('cli tail does not keep the log open, so compaction goes through while it runs', { skip: process.platform !== 'win32', timeout: 20_000 }, async (t) => {
  const { dir } = seed(t);
  const cli = path.resolve('src/cli.mjs');
  const follower = spawn(process.execPath, [cli, 'tail', dir], { stdio: ['ignore', 'pipe', 'pipe'] });
  defer(t, () => follower.kill());
  let output = '';
  follower.stdout.on('data', (chunk) => { output += chunk; });
  await new Promise((resolve) => setTimeout(resolve, 600));

  const queue = openQueue(dir, { clock: new ManualClock(Date.now()) });
  for (let i = 0; i < 6; i += 1) {
    queue.compact();
    queue.enqueue('x', `after ${i}`);
    await new Promise((resolve) => setTimeout(resolve, 250));
  }
  await new Promise((resolve) => setTimeout(resolve, 600));
  assert.match(output, /compacted: generation/);
  assert.match(output, /enqueue j11/, 'it kept following across compactions');
});
