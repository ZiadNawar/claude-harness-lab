// RFC 007: exactly-once completion.

import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { test } from 'node:test';
import { fileURLToPath } from 'node:url';
import {
  clearFailpoints,
  JobRunner,
  ManualClock,
  LockTimeoutError,
  openQueue,
  StaleLeaseError,
  UnknownJobError,
  WorkerPool,
} from '../src/index.mjs';
import { encodeFrame, encodeHeader } from '../src/frame.mjs';
import { defer, readLedger, tempDir, waitUntil } from './helpers/tmp.mjs';

const HANDLERS = fileURLToPath(new URL('./helpers/handlers.mjs', import.meta.url));
const OPTIONS = { backoff: { baseMs: 100, factor: 2, maxMs: 1_000 } };

function setup(t, extra = {}) {
  const clock = new ManualClock(1_000);
  const dir = tempDir(t);
  t.after(clearFailpoints);
  const open = () => openQueue(dir, { clock, ...OPTIONS, ...extra });
  return { clock, dir, open, queue: open() };
}

function claimed(queue, worker = 'w') {
  queue.enqueue('x', null);
  return queue.claim(worker);
}

test('complete returns a receipt, and a repeat returns the same one without writing', (t) => {
  const { queue, dir, open, clock } = setup(t);
  const job = claimed(queue);
  clock.advance(5);
  const first = queue.complete(job.id, job.token, { a: 1 });
  assert.deepEqual(first, {
    id: job.id,
    outcome: 'committed',
    token: job.token,
    result: { a: 1 },
    completedAt: 1_005,
    completionSeq: 1,
  });
  const size = fs.statSync(path.join(dir, 'wal.log')).size;

  clock.advance(5);
  const again = queue.complete(job.id, job.token, { a: 'ignored' });
  assert.deepEqual(again, { ...first, outcome: 'already-committed' });
  assert.equal(fs.statSync(path.join(dir, 'wal.log')).size, size, 'nothing is written');

  queue.compact();
  assert.deepEqual(queue.complete(job.id, job.token, 'x'), { ...first, outcome: 'already-committed' });
  assert.deepEqual(open().complete(job.id, job.token, 'x'), { ...first, outcome: 'already-committed' });
});

test('any other token is stale, and a pruned job is unknown', (t) => {
  const { queue, clock } = setup(t, { retainCompletedMs: 100 });
  const job = claimed(queue);
  queue.complete(job.id, job.token, 1);
  assert.throws(() => queue.complete(job.id, job.token + 1, 1), StaleLeaseError);
  assert.throws(() => queue.complete(job.id, 0, 1), StaleLeaseError);
  assert.equal(queue.getJob(job.id).result, 1);
  clock.advance(100);
  queue.compact();
  assert.throws(() => queue.complete(job.id, job.token, 1), UnknownJobError);
});

test('a lease past its deadline can still commit until someone acts on it', (t) => {
  const { queue, clock } = setup(t);
  const job = claimed(queue);
  clock.advance(1_000_000);
  assert.equal(queue.complete(job.id, job.token, 'late but first').outcome, 'committed');

  const second = claimed(queue);
  clock.advance(1_000_000);
  queue.reapExpired();
  assert.throws(() => queue.complete(second.id, second.token, 'too late'), StaleLeaseError);
});

test('getResult says what is known about a job', (t) => {
  const { queue, open, clock } = setup(t, { retainCompletedMs: 500 });
  const { id: waiting } = queue.enqueue('x', null);
  assert.deepEqual(queue.getResult(waiting), { id: waiting, status: 'ready' });
  const job = queue.claim('w');
  assert.deepEqual(queue.getResult(job.id), { id: job.id, status: 'leased' });
  queue.complete(job.id, job.token, { ok: true });
  const expected = { id: job.id, status: 'done', result: { ok: true }, token: job.token, attempts: 1, completedAt: 1_000, completionSeq: 1 };
  assert.deepEqual(queue.getResult(job.id), expected);
  queue.compact();
  assert.deepEqual(open().getResult(job.id), expected);
  assert.equal(queue.getResult('j999'), null);
  clock.advance(500);
  queue.compact();
  assert.equal(queue.getResult(job.id), null);
});

test('completions come in commit order, numbered without gaps across restarts, compaction and pruning', (t) => {
  const { queue, open, clock } = setup(t, { retainCompletedMs: 1_000 });
  const ids = [];
  for (let i = 0; i < 4; i += 1) queue.enqueue('x', i);
  for (let i = 0; i < 4; i += 1) {
    const job = queue.claim('w');
    ids.push(job.id);
    clock.advance(10);
    if (i === 1) queue.compact();
    queue.complete(job.id, job.token, `r${i}`);
  }
  const all = open().completions();
  assert.deepEqual(all.map((c) => c.seq), [1, 2, 3, 4]);
  assert.deepEqual(all.map((c) => c.id), ids);
  assert.deepEqual(all.map((c) => c.result), ['r0', 'r1', 'r2', 'r3']);
  assert.deepEqual(Object.keys(all[0]).sort(), ['completedAt', 'id', 'result', 'seq', 'token']);
  assert.deepEqual(queue.completions({ after: 2 }).map((c) => c.seq), [3, 4]);
  assert.deepEqual(queue.completions({ after: 1, limit: 2 }).map((c) => c.seq), [2, 3]);
  assert.deepEqual(queue.completions({ after: 4 }), []);

  clock.advance(1_000_000);
  queue.compact();
  assert.deepEqual(open().completions(), [], 'everything is past retention');
  queue.enqueue('x', 'next');
  const job = queue.claim('w');
  assert.equal(queue.complete(job.id, job.token, 'r4').completionSeq, 5);
  assert.deepEqual(open().completions({ after: 4 }).map((c) => c.seq), [5]);
});

test('failed, dead and cancelled jobs are not completions', (t) => {
  const { queue } = setup(t, { maxAttempts: 1 });
  const job = claimed(queue);
  queue.fail(job.id, job.token, 'x');
  const { id } = queue.enqueue('x', null);
  queue.cancel(id);
  assert.deepEqual(queue.completions(), []);
});

test('reclaimWorker gives a dead worker\'s jobs back at once, without backoff', (t) => {
  const { queue, open, clock } = setup(t);
  queue.enqueueMany([{ type: 'x', payload: 1 }, { type: 'x', payload: 2 }, { type: 'x', payload: 3 }]);
  const a1 = queue.claim('dead-worker', { leaseMs: 60_000 });
  const a2 = queue.claim('dead-worker', { leaseMs: 60_000 });
  const keep = queue.claim('live-worker', { leaseMs: 60_000 });
  queue.complete(a2.id, a2.token, 'finished before dying');

  const reclaimed = queue.reclaimWorker('dead-worker', { reason: 'host check failed' });
  assert.deepEqual(reclaimed, [{ id: a1.id, status: 'ready' }]);
  const job = queue.getJob(a1.id);
  assert.equal(job.status, 'ready');
  assert.equal(job.availableAt, clock.now(), 'runnable straight away');
  assert.equal(job.lastError, 'host check failed');
  assert.equal(job.attempts, 1, 'the attempt counts');
  assert.equal(queue.getJob(a2.id).status, 'done');
  assert.equal(queue.getJob(keep.id).status, 'leased');
  assert.throws(() => queue.heartbeat(a1.id, a1.token), StaleLeaseError);
  assert.throws(() => queue.complete(a1.id, a1.token, 'zombie'), StaleLeaseError);
  assert.deepEqual(queue.reclaimWorker('dead-worker'), [], 'nothing left to reclaim, and no record written');

  const again = open();
  assert.equal(again.getJob(a1.id).status, 'ready');
  const next = again.claim('replacement');
  assert.equal(next.id, a1.id);
  assert.equal(next.attempt, 2);
  assert.ok(next.token > a1.token);
});

test('reclaimWorker sends a job to dead when its attempts have run out', (t) => {
  const { queue } = setup(t, { maxAttempts: 1 });
  const job = claimed(queue, 'doomed');
  assert.deepEqual(queue.reclaimWorker('doomed', { reason: 'gone' }), [{ id: job.id, status: 'dead' }]);
  assert.equal(queue.getJob(job.id).status, 'dead');
  assert.equal(queue.getJob(job.id).lastError, 'gone');
});

test('release records are in the log with the documented fields, and old readers skip them', (t) => {
  const { queue, dir } = setup(t);
  const job = claimed(queue, 'w');
  queue.reclaimWorker('w', { reason: 'r' });
  const text = fs.readFileSync(path.join(dir, 'wal.log'), 'latin1');
  assert.match(text, /"t":"release","id":"j1","fence":1,"error":"r","at":1000/);
  assert.equal(job.id, 'j1');
});

test('an old log with no completion numbers still opens, and numbering carries on', (t) => {
  const dir = tempDir(t);
  const job = (id, status, extra = {}) => ({
    id, type: 'x', payload: id, key: null, status, maxAttempts: 5, availableAt: 0, lease: null,
    result: status === 'done' ? 'old' : null, lastError: null, enqueuedAt: 0, completedAt: status === 'done' ? 5 : null, seq: Number(id.slice(1)), ...extra,
  });
  const snapshot = { t: 'snapshot', at: 10, seq: 2, jobs: [job('j1', 'done'), job('j2', 'ready')] };
  fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(path.join(dir, 'wal.log'), Buffer.concat([encodeHeader(3), encodeFrame(snapshot)]));
  const queue = openQueue(dir, { clock: new ManualClock(20) });
  assert.deepEqual(queue.completions(), []);
  assert.equal(queue.getResult('j1').completionSeq, null);
  const next = queue.claim('w');
  assert.equal(queue.complete(next.id, next.token, 'new').completionSeq, 1);
  assert.deepEqual(queue.completions().map((c) => c.id), ['j2']);
});

// ----- the worker side ---------------------------------------------------------

function fakeQueue(real, hooks) {
  return new Proxy(real, {
    get(target, name) {
      if (hooks[name]) return (...args) => hooks[name](() => target[name](...args), ...args);
      const value = target[name];
      return typeof value === 'function' ? value.bind(target) : value;
    },
  });
}

const handlers = new Map([['x', { run: async () => 'handled', timeoutMs: null }]]);

test('a worker keeps trying to record a finished job, and takes no other job meanwhile', async (t) => {
  const { queue } = setup(t);
  queue.enqueueMany([{ type: 'x', payload: 1 }, { type: 'x', payload: 2 }]);
  let failures = 3;
  const events = [];
  const claims = [];
  const runner = new JobRunner({
    queue: fakeQueue(queue, {
      complete: (call) => {
        if (failures-- > 0) throw new LockTimeoutError('lock', 1);
        return call();
      },
      claim: (call) => {
        const job = call();
        claims.push(job?.id);
        return job;
      },
    }),
    workerId: 'w',
    handlers,
    leaseMs: 60_000,
    pollMs: 1,
    emit: (e) => events.push(e),
  });
  const job = queue.claim('w');
  await runner.execute(job);
  assert.equal(failures, -1, 'it tried three times and then succeeded');
  assert.equal(queue.getJob(job.id).status, 'done');
  assert.deepEqual(claims, [], 'no claim happened while the outcome was unrecorded');
  assert.equal(events.filter((e) => e.kind === 'job-completed').length, 1);
  assert.equal(events.filter((e) => e.kind === 'worker-error').length, 3);
});

test('a worker keeps heartbeating while it waits to record, so the reaper leaves its job alone', async (t) => {
  const { queue } = setup(t, { lockTimeoutMs: 50 });
  const clock = queue.clock;
  queue.enqueue('x', null);
  const job = queue.claim('w', { leaseMs: 300 });
  let blocked = 8;
  const runner = new JobRunner({
    queue: fakeQueue(queue, {
      complete: (call) => {
        if (blocked-- > 0) {
          clock.advance(100);
          throw new LockTimeoutError('lock', 1);
        }
        return call();
      },
    }),
    workerId: 'w',
    handlers,
    leaseMs: 300,
    heartbeatMs: 5,
    pollMs: 1,
  });
  await runner.execute(job);
  assert.equal(queue.getJob(job.id).status, 'done');
  assert.equal(queue.getJob(job.id).attempts, 1);
});

test('a fenced worker stops, reports job-fenced and discards its result', async (t) => {
  const { queue, clock } = setup(t);
  const job = claimed(queue, 'slow');
  clock.advance(1_000_000);
  queue.reapExpired();
  const events = [];
  const runner = new JobRunner({ queue, workerId: 'slow', handlers, leaseMs: 60_000, pollMs: 1, emit: (e) => events.push(e.kind) });
  await runner.execute(job);
  assert.deepEqual(events.filter((k) => k !== 'job-started'), ['job-fenced']);
  assert.equal(queue.getJob(job.id).status, 'ready');
  assert.equal(queue.getJob(job.id).result, null);
});

test('a result that cannot be recorded fails the attempt instead of being retried for ever', async (t) => {
  const { queue } = setup(t);
  const job = claimed(queue);
  const circular = {};
  circular.self = circular;
  const bad = new Map([['x', { run: async () => circular, timeoutMs: null }]]);
  const events = [];
  const runner = new JobRunner({ queue, workerId: 'w', handlers: bad, leaseMs: 60_000, pollMs: 1, emit: (e) => events.push(e.kind) });
  await runner.execute(job);
  assert.ok(events.includes('job-failed'));
  assert.equal(queue.getJob(job.id).status, 'ready');
});

// ----- crashes, with real workers ----------------------------------------------

function poolSetup(t, { leaseMs = 60_000, failpoints, env = {}, queueOptions = OPTIONS, size = 1 } = {}) {
  const dir = tempDir(t);
  const markers = tempDir(t, 'walq-markers-');
  const ledger = path.join(dir, 'runs.jsonl');
  const queue = openQueue(dir, queueOptions);
  const pool = new WorkerPool({
    dir,
    handlers: HANDLERS,
    size,
    leaseMs,
    pollMs: 5,
    queue: queueOptions,
    env: { WALQ_TEST_LEDGER: ledger, WALQ_FAILPOINT_DIR: markers, ...(failpoints ? { WALQ_FAILPOINTS: failpoints } : {}), ...env },
  });
  defer(t, () => pool.stop());
  return { dir, queue, pool, ledger, markers };
}

const startsOf = (ledger, id) => readLedger(ledger).filter((e) => e.event === 'start' && e.id === id).length;

// The lease is a minute: a job can only come back inside the test's time because
// the pool reclaims the dead worker's leases when it sees the worker go.
for (const [point, rerunsSpec, handlerRuns] of [
  ['job.before-handler=kill', true, 1],
  ['job.after-handler=kill', true],
  ['wal.mid-append#complete=kill', true],
  ['wal.before-append#complete=kill', true],
  // written but not synced: only a power cut takes it back
  ['wal.after-write#complete=kill', 'power'],
  ['wal.after-fsync#complete=kill', false],
  ['job.after-complete=kill', false],
]) {
  for (const powerLoss of [false, true]) {
    const reruns = rerunsSpec === 'power' ? powerLoss : rerunsSpec;
    test(`worker killed at ${point}${powerLoss ? ' with power loss' : ''}: ${reruns ? 'the job runs again at once' : 'the job does not run again'}`, { timeout: 30_000 }, async (t) => {
      const { queue, pool, ledger, markers } = poolSetup(t, {
        failpoints: point,
        env: powerLoss ? { WALQ_SIMULATE_POWER_LOSS: '1' } : {},
      });
      const exits = [];
      pool.on('exit', (e) => exits.push(e));
      const { id } = queue.enqueue('quick', { n: 1 });
      const started = Date.now();
      pool.start();
      await pool.drain({ timeoutMs: 20_000 });
      const name = point.split('=')[0].replace('#', '.');
      assert.ok(fs.existsSync(path.join(markers, `${name}.hit`)), 'the failpoint fired');
      await waitUntil(() => exits.length > 0);
      assert.ok(exits.some((e) => e.signal === 'SIGKILL' || e.code !== 0), 'a worker died');
      const job = queue.getJob(id);
      assert.equal(job.status, 'done');
      assert.equal(job.attempts, reruns ? 2 : 1);
      assert.equal(startsOf(ledger, id), handlerRuns ?? (reruns ? 2 : 1));
      assert.ok(Date.now() - started < 15_000, 'did not wait for the 60 s lease');
      const done = queue.getResult(id);
      assert.equal(done.completionSeq, 1);
    });
  }
}

test('a worker killed during its job gives the job back with the reason, and the attempt counted', { timeout: 30_000 }, async (t) => {
  const { queue, pool } = poolSetup(t, { failpoints: 'job.after-handler=kill' });
  const { id } = queue.enqueue('quick', null);
  pool.start();
  await pool.drain({ timeoutMs: 20_000 });
  assert.equal(queue.getJob(id).attempts, 2);
  const log = fs.readFileSync(path.join(queue.dir, 'wal.log'), 'latin1');
  assert.match(log, /"t":"release","id":"j1","fence":1,"error":"worker exited \((SIGKILL|code 1)\)"/);
});

test('two pools on one queue have different worker ids, and one pool\'s reclaim does not touch the other\'s worker', { timeout: 30_000 }, async (t) => {
  const dir = tempDir(t);
  const markers = tempDir(t, 'walq-markers-');
  const ledger = path.join(dir, 'runs.jsonl');
  const queue = openQueue(dir, OPTIONS);
  const make = (failpoints) => {
    const pool = new WorkerPool({
      dir, handlers: HANDLERS, size: 1, leaseMs: 60_000, pollMs: 5, queue: OPTIONS,
      env: { WALQ_TEST_LEDGER: ledger, WALQ_FAILPOINT_DIR: markers, ...(failpoints ? { WALQ_FAILPOINTS: failpoints } : {}) },
    });
    defer(t, () => pool.stop());
    return pool;
  };
  const steady = make();
  const doomed = make('job.before-handler=kill');
  const workers = new Set();
  for (const pool of [steady, doomed]) pool.on('message', (m) => m.workerId && workers.add(m.workerId));

  const { id: slow } = queue.enqueue('slow', { ms: 1_500 });
  steady.start();
  await new Promise((resolve) => steady.on('message', (m) => m.kind === 'job-started' && resolve()));
  queue.enqueue('quick', null);
  doomed.start();
  await steady.drain({ timeoutMs: 20_000 });

  assert.equal(workers.size >= 3, true, `worker ids must differ across pools: ${[...workers]}`);
  assert.equal(queue.getJob(slow).status, 'done');
  assert.equal(startsOf(ledger, slow), 1, 'the live worker\'s job was left alone');
  assert.equal(queue.getJob(slow).attempts, 1);
});
