// JobRunner: the loop a worker process runs. Claim a job, run its handler with a
// heartbeat going, then record the outcome.

import { sleep } from '../clock.mjs';
import {
  CorruptLogError,
  LockTimeoutError,
  RecordTooLargeError,
  StaleLeaseError,
  UnknownJobError,
  WalqError,
} from '../errors.mjs';
import { hit } from '../failpoints.mjs';
import { JOB_COMPLETED, JOB_FAILED, JOB_FENCED, JOB_STARTED, WORKER_ERROR } from './protocol.mjs';
import { runWithTimeout } from './registry.mjs';

const RECORD_RETRY_MIN_MS = 10;
const RECORD_RETRY_MAX_MS = 500;

// A problem with the call itself, which trying again cannot cure. Anything else
// (a busy lock, a disk that hiccuped) is worth another try.
function cannotRetry(err) {
  return err instanceof WalqError && !(err instanceof LockTimeoutError) && !(err instanceof CorruptLogError);
}

export class JobRunner {
  constructor({ queue, workerId, handlers, leaseMs, heartbeatMs, pollMs = 20, types = null, emit = () => {} }) {
    this.queue = queue;
    this.workerId = workerId;
    this.handlers = handlers;
    this.leaseMs = leaseMs ?? queue.config.leaseMs;
    this.heartbeatMs = heartbeatMs ?? Math.max(10, Math.floor(this.leaseMs / 3));
    this.pollMs = pollMs;
    this.types = types;
    this.emit = emit;
    this.stopping = false;
  }

  stop() {
    this.stopping = true;
  }

  async run() {
    while (!this.stopping) {
      const job = this.#claimNext();
      if (job) await this.execute(job);
      else await sleep(this.pollMs);
    }
  }

  #claimNext() {
    try {
      return this.queue.claim(this.workerId, { leaseMs: this.leaseMs, types: this.types });
    } catch (err) {
      if (!(err instanceof WalqError)) throw err;
      this.emit({ kind: WORKER_ERROR, error: err.message });
      return null;
    }
  }

  async execute(job) {
    const { id, token } = job;
    hit('job.before-handler', { id });
    this.emit({ kind: JOB_STARTED, id, attempt: job.attempt, token });

    const abort = new AbortController();
    const beat = setInterval(() => {
      try {
        this.queue.heartbeat(id, token, { leaseMs: this.leaseMs });
      } catch (err) {
        if (err instanceof StaleLeaseError || err instanceof UnknownJobError) {
          clearInterval(beat);
          abort.abort();
        } else {
          this.emit({ kind: WORKER_ERROR, error: err.message });
        }
      }
    }, this.heartbeatMs);

    // The heartbeat keeps going until the outcome is recorded: a worker that is
    // still trying to hand in its result is still alive.
    try {
      let result;
      let failure;
      try {
        const handler = this.handlers.get(job.type);
        if (!handler) throw new Error(`no handler for job type ${job.type}`);
        result = await runWithTimeout(
          handler,
          job.payload,
          { id, attempt: job.attempt, token, workerId: this.workerId, signal: abort.signal },
          abort,
        );
        // A result that cannot be written down fails the attempt now, rather
        // than being retried for ever below.
        JSON.stringify(result ?? null);
      } catch (err) {
        failure = err;
      }

      if (failure !== undefined) {
        await this.#record(id, () => this.queue.fail(id, token, failure), JOB_FAILED, failure);
        return;
      }
      hit('job.after-handler', { id });
      const refused = await this.#record(id, () => this.queue.complete(id, token, result), JOB_COMPLETED);
      if (refused instanceof RecordTooLargeError) {
        await this.#record(id, () => this.queue.fail(id, token, refused), JOB_FAILED, refused);
      }
      hit('job.after-complete', { id });
    } finally {
      clearInterval(beat);
    }
  }

  /**
   * Records what happened, however long that takes. Once a handler has finished,
   * its outcome matters more than anything else this worker could be doing, so a
   * busy queue or a failing disk is waited out rather than given up on. The two
   * ways out are success and learning that the lease is gone, which is an
   * expected end for this attempt and not an error: the result is discarded.
   */
  async #record(id, call, kind, cause) {
    let wait = RECORD_RETRY_MIN_MS;
    for (;;) {
      try {
        const receipt = call();
        this.emit({ kind, id, error: cause?.message, outcome: receipt?.outcome });
        return null;
      } catch (err) {
        if (err instanceof StaleLeaseError || err instanceof UnknownJobError) {
          this.emit({ kind: JOB_FENCED, id });
          return null;
        }
        this.emit({ kind: WORKER_ERROR, id, error: err.message });
        if (cannotRetry(err)) return err;
      }
      await sleep(wait);
      wait = Math.min(wait * 2, RECORD_RETRY_MAX_MS);
    }
  }
}
