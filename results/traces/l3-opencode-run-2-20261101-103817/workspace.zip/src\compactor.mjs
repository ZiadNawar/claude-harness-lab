// Replaces the log with a one-record log holding the current state. Runs under
// the queue lock. docs/compaction.md describes the protocol.

import path from 'node:path';
import { sleepSync } from './clock.mjs';
import { encodeFrame, encodeHeader, scanFrames } from './frame.mjs';
import { hit } from './failpoints.mjs';
import { buildSnapshot } from './snapshot.mjs';

// Windows refuses to replace a file that anyone has open, however briefly: an
// operator's tool, a backup, a virus scanner. Those holds are normally short, so
// the rename is tried a few times. If the file stays held the compaction fails,
// and the next one starts clean.
const HELD = new Set(['EPERM', 'EBUSY', 'EACCES']);
const RENAME_TRIES = 8;
const RENAME_WAIT_MS = 4;

export function compactionTempPath(walFile) {
  return `${walFile}.compact`;
}

function renameWhenFree(ops, from, to) {
  for (let tries = 1; ; tries += 1) {
    try {
      ops.rename(from, to);
      return;
    } catch (err) {
      if (!HELD.has(err.code) || tries >= RENAME_TRIES) throw err;
      sleepSync(RENAME_WAIT_MS * tries);
    }
  }
}

/**
 * Writes and installs the next generation of the log. Returns the snapshot and
 * the size of the new file. If this throws, the old log is still in place.
 */
export function compactLog({ wal, ops, state, generation, now, config }) {
  const nextGeneration = generation + 1;
  const built = buildSnapshot(state, now, config);
  const frame = encodeFrame(built);
  const bytes = Buffer.concat([encodeHeader(nextGeneration), frame]);
  const tempPath = compactionTempPath(wal.file);

  try {
    // We hold the queue lock, so any temp file already here was left by a
    // compaction that died. It is not ours to keep.
    ops.unlink(tempPath);
    ops.create(tempPath);
    ops.writeAt(tempPath, bytes, 0);
    // Durable before it takes the log's name: a rename can reach the disk ahead
    // of the data, and that would leave an empty log.
    ops.sync(tempPath);
    hit('compact.after-tmp-write', { generation: nextGeneration });
    hit('compact.before-rename', { generation: nextGeneration });
    renameWhenFree(ops, tempPath, wal.file);
    hit('compact.after-rename', { generation: nextGeneration });
    ops.syncDir(path.dirname(wal.file));
  } catch (err) {
    try {
      ops.unlink(tempPath);
    } catch {
      // Left behind, it is removed by the next compaction.
    }
    err.message = `compaction failed: ${err.message}`;
    throw err;
  }

  // What a process reading the new log will see, not the objects we built it from.
  const [{ record: snapshot }] = scanFrames(frame).frames;
  return { snapshot, generation: nextGeneration, size: bytes.length };
}
