// Store: the replayed state plus the rules for reading and writing the log.
// Every read of shared state and every write happens inside withLock(), which
// first brings this process up to date with whatever other processes wrote.

import path from 'node:path';
import { compactLog } from './compactor.mjs';
import { CorruptLogError, QueueClosedError } from './errors.mjs';
import { FORMAT_VERSION, HEADER_SIZE } from './frame.mjs';
import { createFileOps, ensureDir } from './fsops.mjs';
import { acquireLock } from './lock.mjs';
import { createLogger } from './logger.mjs';
import { applyRecord, createState } from './state.mjs';
import { Wal } from './wal.mjs';

export const WAL_FILE = 'wal.log';
export const LOCK_FILE = 'queue.lock';

const log = createLogger('store');

export class Store {
  constructor(dir, config) {
    this.dir = dir;
    this.config = config;
    this.clock = config.clock;
    this.ops = createFileOps();
    this.wal = new Wal(path.join(dir, WAL_FILE), this.ops);
    this.lockPath = path.join(dir, LOCK_FILE);
    this.state = createState();
    this.generation = null;
    this.offset = HEADER_SIZE;
    this.snapshotBytes = 0;
    this.tornTailsDropped = 0;
    this.lastCompactionError = null;
    this.closed = false;
    this.holdingLock = false;
  }

  open() {
    ensureDir(this.dir);
    this.#locked(() => {
      if (!this.wal.exists()) this.wal.create();
      this.catchUp();
    });
  }

  close() {
    this.closed = true;
  }

  #locked(fn) {
    if (this.holdingLock) throw new Error('queue lock is not reentrant');
    const release = acquireLock(this.lockPath, { timeoutMs: this.config.lockTimeoutMs });
    this.holdingLock = true;
    try {
      return fn();
    } finally {
      this.holdingLock = false;
      release();
    }
  }

  withLock(fn) {
    if (this.closed) throw new QueueClosedError();
    return this.#locked(() => {
      this.catchUp();
      return fn();
    });
  }

  /** Brings this.state up to date with the log without doing anything else. */
  refresh() {
    this.withLock(() => {});
  }

  catchUp() {
    const header = this.wal.readHeader();
    const size = this.ops.size(this.wal.file);
    // A different generation means another process compacted: that file is a
    // new history, whatever its size, and has to be read from its start.
    if (this.generation === null || header.generation !== this.generation) {
      this.state = createState();
      this.offset = HEADER_SIZE;
      this.snapshotBytes = 0;
      this.generation = header.generation;
    } else if (size < this.offset) {
      this.generation = null;
      throw new CorruptLogError(`${this.wal.file}: log is ${size} bytes, shorter than the ${this.offset} already read`, {
        offset: size,
        reason: 'shrunk',
      });
    }

    let tail;
    try {
      ({ tail } = this.wal.scanFrom(this.offset, (frames, end) => {
        for (const frame of frames) {
          applyRecord(this.state, frame.record);
          if (frame.record.t === 'snapshot') this.snapshotBytes = frame.size;
        }
        this.offset = end;
      }));
    } catch (err) {
      // The state is only part of the log now. Start again next time, and fail
      // the same way again, rather than carry on from a partial picture.
      this.generation = null;
      throw err;
    }

    if (tail) {
      // We hold the lock, so nobody is writing: this is the remains of a write
      // that never finished. Nothing was acknowledged from it. Cut it off so
      // that it cannot sit in front of what is written next.
      this.wal.truncate(this.offset);
      this.tornTailsDropped += 1;
      log.warn('removed incomplete tail', { offset: this.offset, reason: tail.reason, bytes: tail.bytes });
    }
  }

  /** Must be called inside withLock(). */
  append(records, options) {
    this.offset = this.wal.append(records, { ...options, at: this.offset });
    // Apply what a reader of the log will see, not the caller's objects.
    for (const record of records) applyRecord(this.state, JSON.parse(JSON.stringify(record)));
  }

  /** Must be called inside withLock(). */
  compact() {
    const bytesBefore = this.offset;
    const { snapshot, generation, size } = compactLog({
      wal: this.wal,
      ops: this.ops,
      state: this.state,
      generation: this.generation,
      now: this.clock.now(),
      config: this.config,
    });
    this.state = createState();
    applyRecord(this.state, snapshot);
    this.generation = generation;
    this.offset = size;
    this.snapshotBytes = size - HEADER_SIZE;
    log.info('compacted', { generation, bytesBefore, bytesAfter: size });
    return { generation, bytesBefore, bytesAfter: size, jobs: this.state.jobs.size };
  }

  /**
   * Compacts when the log has outgrown the threshold, and has grown by at least
   * the size of its snapshot since, so that a state bigger than the threshold is
   * not rewritten on every write. A failure here must not fail the operation
   * that triggered it, because that operation has committed.
   */
  maybeCompact() {
    const threshold = this.config.compactAfterBytes;
    if (!threshold) return;
    if (this.offset < threshold) return;
    if (this.offset - HEADER_SIZE < 2 * this.snapshotBytes) return;
    try {
      this.compact();
      this.lastCompactionError = null;
    } catch (err) {
      this.lastCompactionError = err;
      log.warn('compaction failed', { error: err.message });
    }
  }
  describe() {
    return {
      format: FORMAT_VERSION,
      generation: this.generation,
      logBytes: this.offset,
      tornTailsDropped: this.tornTailsDropped,
      lastCompactionError: this.lastCompactionError?.message ?? null,
    };
  }
}
