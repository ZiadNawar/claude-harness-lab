# Changelog

## 0.5.0

RFC 007: `complete()` returns a receipt; new `getResult()`, `completions()`, `reclaimWorker()`; the `release` record; worker pools reclaim dead workers at once; workers keep retrying to record a finished job.

Fixes (see docs/guarantees.md):

- A log with an unfinished write at its end no longer becomes unreadable after later writes: the tail is removed under the lock before anything is appended, and appends go to the end of the good data (G2, G3).
- Damage elsewhere raises `CorruptLogError` and the file is left alone; a failed read no longer carries on from half a state (G4).
- The whole log is read on open, not the first megabyte; records bigger than a read chunk work; records over the frame limit are refused before writing (G5).
- Claims, reaps and idempotency-key checks are decided under the lock, so processes can no longer take the same job, expire a job that was just heartbeated or committed, or both create a key (G6, G10).
- Tokens are checked on heartbeat, complete and fail; `requeueDead` no longer reissues tokens (G6, G8).
- Heartbeats are written to the log so other processes' reapers see them (G7).
- Retry due times come from the record, not the replaying process's clock (G9).
- Snapshots keep attempts, tokens, priority and idempotency keys, including keys of pruned jobs (G9, G10, G11).
- `complete` is synced before it returns (G1).
- Compaction: leftover temp files are replaced, the temp file is synced before the rename, a briefly held log is waited out, other processes notice a new generation however big the new file is, and automatic compaction no longer rewrites a large state on every write (G11 to G14).
- Log creation is durable before it takes its name (G2).
- `walq tail` no longer holds the log open.

## 0.4.2

- Throughput work for busy queues: less log growth and fewer syncs in the common paths.
- Lower memory use when a process catches up.

## 0.4.1

- `cancel()` and `requeueDead()`.
- Job priorities.
- `metrics()` and the `metrics` command.

## 0.4.0

- Smaller snapshots.
- Worker pools replace dead workers automatically.
- Failpoints for crash testing.

## 0.3.0

- Idempotency keys.
- Automatic compaction past `compactAfterBytes`.

## 0.2.0

- Multi-process access through a shared lock. Workers became child processes.

## 0.1.0

- First version: one process, one log.
