// Several processes on one queue directory, simulated with several Queue objects
// in this process and failpoint callbacks that run another queue's call at the
// exact moment a gap opens between one call's check and its lock.

import assert from 'node:assert/strict';
import { test } from 'node:test';
import { clearFailpoints, ManualClock, onFailpoint, openQueue, StaleLeaseError } from '../src/index.mjs';
import { tempDir } from './helpers/tmp.mjs';

const OPTIONS = { backoff: { baseMs: 100, factor: 2, maxMs: 10_000 } };

function setup(t, extra = {}) {
  const clock = new ManualClock(1_000);
  const dir = tempDir(t);
  t.after(clearFailpoints);
  const open = () => openQueue(dir, { clock, ...OPTIONS, ...extra });
  return { clock, dir, open, a: open(), b: open() };
}

test('two processes claiming at once never get the same attempt (G6)', (t) => {
  const { a, b } = setup(t);
  const { id } = a.enqueue('x', null);
  let stolen;
  onFailpoint('claim.before-lock', () => {
    clearFailpoints();
    stolen = b.claim('b');
  });
  const mine = a.claim('a');
  assert.equal(stolen.id, id);
  assert.equal(mine, null, 'a must not be given a job that b already holds');
  assert.equal(a.getJob(id).lease.worker, 'b');
  assert.equal(a.getJob(id).attempts, 1);
});

test('a heartbeat from one process keeps the lease alive for another one\'s reaper (G7)', (t) => {
  const { a, b, clock } = setup(t);
  a.enqueue('x', null);
  const job = a.claim('w', { leaseMs: 500 });
  clock.advance(400);
  a.heartbeat(job.id, job.token, { leaseMs: 500 });
  clock.advance(400);
  assert.deepEqual(b.reapExpired(), []);
  assert.equal(b.getJob(job.id).status, 'leased');
  clock.advance(100);
  assert.equal(b.reapExpired().length, 1);
});

test('a reaper that looked just before a heartbeat does not expire the job (G7)', (t) => {
  const { a, b, clock } = setup(t);
  a.enqueue('x', null);
  const job = a.claim('w', { leaseMs: 500 });
  clock.advance(500);
  onFailpoint('reap.before-lock', () => {
    clearFailpoints();
    a.heartbeat(job.id, job.token, { leaseMs: 500 });
  });
  assert.deepEqual(b.reapExpired(), []);
  assert.equal(a.getJob(job.id).status, 'leased');
  assert.equal(a.getJob(job.id).attempts, 1);
});

test('a reaper that looked just before a commit does not undo it', (t) => {
  const { a, b, clock } = setup(t);
  a.enqueue('x', null);
  const job = a.claim('w', { leaseMs: 500 });
  clock.advance(500);
  onFailpoint('reap.before-lock', () => {
    clearFailpoints();
    a.complete(job.id, job.token, 'done');
  });
  assert.deepEqual(b.reapExpired(), []);
  assert.equal(b.getJob(job.id).status, 'done');
});

test('a token from an old attempt has no power (G8)', (t) => {
  const { a, b, clock } = setup(t);
  const { id } = a.enqueue('x', null);
  const old = a.claim('slow', { leaseMs: 500 });
  clock.advance(500);
  b.reapExpired();
  clock.advance(100);
  const current = b.claim('fast');
  assert.equal(current.id, id);
  assert.notEqual(current.token, old.token);
  assert.throws(() => a.heartbeat(id, old.token), StaleLeaseError);
  assert.throws(() => a.complete(id, old.token, 'late'), StaleLeaseError);
  assert.throws(() => a.fail(id, old.token, 'late'), StaleLeaseError);
  assert.equal(a.getJob(id).lease.worker, 'fast');
  assert.equal(b.complete(id, current.token, 'ok').outcome, 'committed');
});

test('a token is never issued twice for a job, even through requeueDead (G6)', (t) => {
  const { a, open } = setup(t, { maxAttempts: 1 });
  const { id } = a.enqueue('x', null);
  const seen = [];
  for (let round = 0; round < 3; round += 1) {
    const job = a.claim('w');
    seen.push(job.token);
    a.fail(job.id, job.token, 'no');
    assert.equal(a.getJob(id).status, 'dead');
    a.requeueDead(id);
    if (round === 1) a.compact();
  }
  assert.equal(new Set(seen).size, 3, `tokens ${seen}`);
  assert.equal(open().getJob(id).fence, 3);
});

test('a key used by another process during the gap is found under the lock (G10)', (t) => {
  const { a, b } = setup(t);
  let other;
  onFailpoint('enqueue.before-lock', () => {
    clearFailpoints();
    other = b.enqueue('x', 'from b', { key: 'k' });
  });
  const mine = a.enqueue('x', 'from a', { key: 'k' });
  assert.equal(other.deduped, false);
  assert.equal(mine.deduped, true);
  assert.equal(mine.id, other.id);
  assert.equal(a.stats().total, 1);
});

test('a key is remembered after its job was pruned by compaction, through restarts (G10)', (t) => {
  const week = 7 * 24 * 3600 * 1000;
  const { a, open, clock } = setup(t, { retainCompletedMs: 1_000 });
  const first = a.enqueue('report', 'march', { key: 'r-march' });
  const job = a.claim('w');
  a.complete(job.id, job.token, { sent: 1 });
  clock.advance(2_000);
  a.compact();
  assert.equal(a.getJob(first.id), null, 'the job itself has been pruned');

  for (const queue of [a, open()]) {
    const again = queue.enqueue('report', 'march', { key: 'r-march' });
    assert.equal(again.deduped, true);
    assert.equal(again.id, first.id);
    assert.equal(again.status, 'done');
    assert.deepEqual(again.result, { sent: 1 });
    queue.compact();
  }
  assert.equal(open().enqueue('report', 'march', { key: 'r-march' }).deduped, true);
  clock.advance(week);
  const later = open().enqueue('report', 'march', { key: 'r-march' });
  assert.equal(later.deduped, false, 'after its time to live the key is free again');
});

test('a retry keeps its due time through restart and compaction (G9)', (t) => {
  const { a, open, clock } = setup(t);
  const { id } = a.enqueue('x', null, { maxAttempts: 9 });
  const job = a.claim('w');
  const { retryAt } = a.fail(job.id, job.token, 'boom');
  assert.equal(retryAt, 1_100);
  clock.advance(50);
  const restarted = open();
  assert.equal(restarted.getJob(id).availableAt, 1_100);
  clock.advance(10_000);
  assert.equal(open().getJob(id).availableAt, 1_100, 'a later replay must not move it');
  a.compact();
  assert.equal(open().getJob(id).availableAt, 1_100);
  assert.equal(open().claim('w2').id, id);
});

test('attempts, backoff growth and maxAttempts carry through compaction (G9, G11)', (t) => {
  const { a, open, clock } = setup(t, { backoff: { baseMs: 10, factor: 2, maxMs: 100_000 } });
  const { id } = a.enqueue('x', 'p', { maxAttempts: 5, priority: 3 });
  const delays = [];
  for (let attempt = 1; attempt <= 5; attempt += 1) {
    clock.advance(1_000_000);
    const job = a.claim('w');
    assert.equal(job.attempt, attempt);
    const out = a.fail(job.id, job.token, `fail ${attempt}`);
    if (out.status === 'ready') delays.push(out.retryAt - clock.now());
    a.compact();
    const other = open();
    assert.equal(other.getJob(id).attempts, attempt);
    assert.equal(other.getJob(id).priority, 3);
    assert.equal(other.getJob(id).fence, attempt);
  }
  assert.deepEqual(delays, [10, 20, 40, 80]);
  assert.equal(a.getJob(id).status, 'dead');
});

test('compaction changes nothing observable about a job (G11)', (t) => {
  const { a, open, clock } = setup(t);
  a.enqueue('x', { deep: [1, { two: 2 }] }, { priority: 2, key: 'k', maxAttempts: 7, delayMs: 300 });
  a.enqueue('x', 'second');
  const job = a.claim('w', { leaseMs: 5_000 });
  a.heartbeat(job.id, job.token, { leaseMs: 9_000 });
  clock.advance(300);
  const done = a.claim('w2');
  a.fail(done.id, done.token, 'oops');
  const before = a.listJobs();
  a.compact();
  assert.deepEqual(a.listJobs(), before);
  assert.deepEqual(open().listJobs(), before);
});

test('another process follows a compaction whose new log is bigger than the old one (G13)', (t) => {
  const { a, b } = setup(t);
  for (let i = 0; i < 3; i += 1) a.enqueue('x', i);
  assert.equal(b.stats().total, 3);
  const before = b.stats().logBytes;
  const report = a.compact();
  assert.ok(report.bytesAfter > before, `the snapshot (${report.bytesAfter}) should be bigger than the log (${before}) for this test`);
  a.enqueue('x', 'new');
  assert.equal(b.stats().total, 4);
  assert.equal(b.listJobs().length, 4);
  b.enqueue('x', 'from b');
  assert.equal(a.stats().total, 5);
});

test('another process follows a compaction that left a smaller log, and many of them', (t) => {
  const { a, b } = setup(t, { compactAfterBytes: 1_500 });
  for (let i = 0; i < 40; i += 1) {
    a.enqueue('x', { i });
    if (i % 3 === 0) b.enqueue('x', { b: i });
  }
  assert.ok(a.stats().generation > 2);
  assert.equal(a.stats().total, b.stats().total);
  assert.equal(b.stats().total, 40 + 14);
});

test('automatic compaction does not rewrite a big state on every write (G14)', (t) => {
  const { a } = setup(t, { compactAfterBytes: 2_000 });
  for (let i = 0; i < 60; i += 1) a.enqueue('x', { pad: 'p'.repeat(100), i });
  const generation = a.stats().generation;
  for (let i = 0; i < 30; i += 1) a.enqueue('x', 'one more');
  assert.ok(a.stats().generation - generation <= 3, `${a.stats().generation - generation} compactions for 30 small writes`);
});

test('a cancelled job loses its lease', (t) => {
  const { a } = setup(t);
  const { id } = a.enqueue('x', null);
  const job = a.claim('w');
  assert.equal(a.cancel(id).changed, true);
  assert.throws(() => a.complete(id, job.token, 'x'), StaleLeaseError);
});
