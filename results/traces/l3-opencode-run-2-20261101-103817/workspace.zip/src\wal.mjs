// The log file itself: a header, then checksummed frames, written only by the
// process holding the queue lock.

import path from 'node:path';
import { decodeHeader, encodeFrame, encodeHeader, HEADER_SIZE, scanFrames } from './frame.mjs';
import { hit, isArmed } from './failpoints.mjs';

// Bounds memory when a process has fallen far behind: the log is read and applied
// this much at a time. A frame bigger than this is read in one piece.
const SCAN_CHUNK = 1024 * 1024;

export class Wal {
  constructor(file, ops) {
    this.file = file;
    this.ops = ops;
  }

  exists() {
    return this.ops.exists(this.file);
  }

  /**
   * Creates an empty log. The header is made durable under a temporary name
   * first, so the log appears atomically, complete, or not at all.
   */
  create(generation = 1) {
    const staging = `${this.file}.init`;
    this.ops.create(staging);
    this.ops.writeAt(staging, encodeHeader(generation), 0);
    this.ops.sync(staging);
    this.ops.rename(staging, this.file);
    hit('wal.after-create', {});
    this.ops.syncDir(path.dirname(this.file));
  }

  readHeader() {
    return decodeHeader(this.ops.read(this.file, 0, HEADER_SIZE), this.file);
  }

  /**
   * Decodes everything from `offset` to the end of the file, a chunk at a time.
   * `visit(frames, end)` gets each batch of good frames and the offset after
   * them. Returns `{ end, tail }`, where `tail` describes an unfinished write
   * at the very end of the file, if there is one. Damage anywhere else throws
   * CorruptLogError and leaves the file alone.
   */
  scanFrom(offset, visit) {
    let pos = offset;
    let chunk = SCAN_CHUNK;
    for (;;) {
      const size = this.ops.size(this.file);
      if (pos >= size) return { end: pos, tail: null };
      const bytes = this.ops.read(this.file, pos, chunk);
      const final = pos + bytes.length >= size;
      const scan = scanFrames(bytes, pos, { final });
      if (scan.frames.length) visit(scan.frames, scan.end);
      pos = scan.end;
      if (final) return { end: pos, tail: scan.tail };
      if (scan.tail) chunk = Math.max(chunk, (scan.tail.needed ?? 0) + 1);
    }
  }

  truncate(length) {
    this.ops.truncate(this.file, length);
  }

  /**
   * Writes records at `at`, which must be the end of the good part of the log.
   * Returns the new end offset. If the write fails part way, the bytes are
   * taken back out so that an unacknowledged record cannot appear later.
   */
  append(records, { sync = true, at = this.ops.size(this.file) } = {}) {
    const type = records[0]?.t;
    const bytes = Buffer.concat(records.map(encodeFrame));
    try {
      hit('wal.before-append', { type });
      if (isArmed('wal.mid-append')) {
        const half = bytes.length >> 1;
        this.ops.writeAt(this.file, bytes.subarray(0, half), at);
        hit('wal.mid-append', { type });
        this.ops.writeAt(this.file, bytes.subarray(half), at + half);
      } else {
        this.ops.writeAt(this.file, bytes, at);
      }
      hit('wal.after-write', { type });
      if (sync) this.ops.sync(this.file);
    } catch (err) {
      try {
        this.ops.truncate(this.file, at);
      } catch {
        // The original failure is the one to report. Whatever is left past `at`
        // is an unfinished tail, which the next catch-up removes.
      }
      throw err;
    }
    hit('wal.after-fsync', { type });
    return at + bytes.length;
  }
}
