# Compaction

The log only grows, so from time to time it's replaced by a shorter one that says the same thing: a new header with the next generation, and one `snapshot` record.

## When

- `compact()` runs it on request.
- After any write, automatically, when the log has passed `compactAfterBytes` (see below).

A failed automatic compaction doesn't fail the call that triggered it, because that call has already committed. `stats().lastCompactionError` shows the last failure.

## How

Compaction runs under the queue lock, after catching up, so the state it writes is complete.

1. Build the snapshot from the current state, dropping finished jobs past `retainCompletedMs`.
2. Remove any `wal.log.compact` left by a compaction that died (we hold the lock, so it is nobody's), then write the header and snapshot to a fresh one and sync it.
3. Rename it over `wal.log`. Windows refuses while anyone has the log open, so a refused rename is tried a few more times over a fraction of a second. If it still fails the temp file is removed and the compaction fails; the log is untouched and the next compaction starts clean.
4. Rebuild this process's state from the snapshot.

The temp file is durable before the rename, so a power cut can never leave an empty log.

## What the snapshot holds

The jobs that are kept with all their fields (attempts, tokens, due times and so on), the counters the log needs to carry on, and the idempotency keys still within their time to live, including keys whose job was dropped. See [guarantees.md](guarantees.md), G10 and G11.

## Other processes

A process that was reading the old log finds a different generation in the header next time it catches up, and starts again from the new one, whatever the sizes of the two files.

## When it runs by itself

Past `compactAfterBytes`, and once the log has grown by at least the size of its snapshot, so that a live state larger than the threshold is not rewritten on every write.
