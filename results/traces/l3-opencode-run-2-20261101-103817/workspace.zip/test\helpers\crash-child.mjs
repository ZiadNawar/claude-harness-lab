// Runs one queue operation in a process that a failpoint is expected to kill.
//   node crash-child.mjs <dir> <op> [json args]
// Ops: enqueue {n, padding}, compact, claim, complete (claims and completes one job),
//      open (just opens the queue, creating it if need be).

import { openQueue } from '../../src/index.mjs';

const [dir, op, raw] = process.argv.slice(2);
const args = raw ? JSON.parse(raw) : {};
const queue = openQueue(dir, args.options ?? {});

if (op === 'enqueue') {
  for (let i = 0; i < (args.n ?? 1); i += 1) queue.enqueue('x', { i, pad: 'p'.repeat(args.padding ?? 0) }, args.jobOptions);
} else if (op === 'compact') {
  queue.compact();
} else if (op === 'claim') {
  queue.claim('crash-child');
} else if (op === 'complete') {
  const job = queue.claim('crash-child');
  queue.complete(job.id, job.token, { done: true });
}
queue.close();
