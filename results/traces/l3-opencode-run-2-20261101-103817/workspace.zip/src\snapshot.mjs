// A compacted log starts with one snapshot record holding the state it replaces.

import { isPastRetention } from './retention.mjs';

function serializeJob(job) {
  return { ...job };
}

/**
 * The idempotency keys a snapshot has to carry. A key outlives its job, so a key
 * whose job is being dropped keeps the job's outcome with it, and only keys past
 * their time to live are let go.
 */
function keepKeys(state, kept, now, config) {
  const keys = [];
  for (const [key, entry] of state.idem) {
    if (now - entry.at >= config.idempotencyTtlMs) continue;
    const item = { key, id: entry.id, at: entry.at };
    if (!kept.has(entry.id)) {
      const job = state.jobs.get(entry.id);
      item.status = job?.status ?? entry.status ?? 'done';
      item.result = job ? job.result ?? null : entry.result ?? null;
    }
    keys.push(item);
  }
  return keys;
}

/** Builds the snapshot record, dropping terminal jobs past their retention. */
export function buildSnapshot(state, now, config) {
  const kept = new Map();
  for (const job of state.jobs.values()) {
    if (!isPastRetention(job, now, config)) kept.set(job.id, job);
  }

  return {
    t: 'snapshot',
    at: now,
    seq: state.seq,
    completionSeq: state.completionSeq,
    jobs: [...kept.values()].map(serializeJob),
    idem: keepKeys(state, kept, now, config),
  };
}

export function loadSnapshot(state, rec) {
  state.seq = rec.seq;
  state.completionSeq = rec.completionSeq ?? 0;
  state.jobs = new Map();
  state.idem = new Map();
  for (const job of rec.jobs) {
    state.jobs.set(job.id, {
      ...job,
      priority: job.priority ?? 0,
      attempts: job.attempts ?? 0,
      fence: job.fence ?? job.lease?.fence ?? 0,
      completionSeq: job.completionSeq ?? null,
    });
    // A snapshot from before keys were stored separately: the newest job to use
    // a key owns it, as when the log was replayed record by record.
    if (!rec.idem && job.key) state.idem.set(job.key, { id: job.id, at: job.enqueuedAt });
  }
  for (const item of rec.idem ?? []) {
    state.idem.set(item.key, { id: item.id, at: item.at, status: item.status, result: item.result });
  }
}
