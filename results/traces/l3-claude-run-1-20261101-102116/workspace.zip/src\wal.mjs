// The log file itself: a header, then checksummed frames, written only by the
// process holding the queue lock.

import path from 'node:path';
import { CorruptLogError } from './errors.mjs';
import {
  decodeHeader,
  encodeFrame,
  encodeHeader,
  FRAME_OVERHEAD,
  HEADER_SIZE,
  isValidFrameAt,
  MAX_PAYLOAD,
  scanFrames,
} from './frame.mjs';
import { hit, isArmed } from './failpoints.mjs';

// Bounds memory when a process has fallen far behind: the log is applied one chunk
// at a time. A frame larger than a chunk is read whole, because every frame has to
// be readable whatever its size.
const SCAN_CHUNK = 1024 * 1024;

export class Wal {
  constructor(file, ops) {
    this.file = file;
    this.ops = ops;
  }

  exists() {
    return this.ops.exists(this.file);
  }

  /**
   * Creates an empty log. The header is made durable under a temporary name before
   * the name that matters appears, so a power cut leaves no log or a whole one,
   * never a log without its header.
   */
  create(generation = 1) {
    const staging = `${this.file}.init`;
    this.ops.create(staging);
    this.ops.writeAt(staging, encodeHeader(generation), 0);
    this.ops.sync(staging);
    this.ops.rename(staging, this.file);
    hit('wal.after-create', {});
    this.ops.sync(this.file);
    this.ops.syncDir(path.dirname(this.file));
  }

  readHeader() {
    return decodeHeader(this.ops.read(this.file, 0, HEADER_SIZE), this.file);
  }

  size() {
    return this.ops.size(this.file);
  }

  /**
   * Decodes everything from `offset` to the end of the file, a chunk at a time.
   * `onFrames(frames, end)` is called for each batch of good frames, `end` being the
   * offset just after them, so the caller's position is always consistent with what
   * it has applied. Returns `{ end, tail }`.
   *
   * `tail` is set when the file ends in bytes that are not a whole valid frame and
   * nothing valid follows them: a write that was cut off. Anything else that cannot
   * be decoded is damage to records that may have been acknowledged, and raises
   * CorruptLogError with the offset, after the good frames before it were delivered.
   */
  scanFrom(offset, onFrames) {
    const size = this.ops.size(this.file);
    let pos = offset;
    let want = SCAN_CHUNK;
    while (pos < size) {
      const bytes = this.ops.read(this.file, pos, want);
      const { frames, end, tail } = scanFrames(bytes, pos, { strict: false });
      if (frames.length) onFrames(frames, end);
      const progressed = end > pos;
      pos = end;
      if (!tail) continue;

      const readsToEnd = end + tail.bytes >= size;
      if (tail.reason === 'partial' && !readsToEnd) {
        // The chunk ended inside a frame, which is not damage. Read a window big
        // enough to hold it.
        if (!progressed) want = Math.min(want * 2, MAX_PAYLOAD + FRAME_OVERHEAD);
        continue;
      }
      if (this.#validFrameAfter(end, size)) {
        throw new CorruptLogError(`corrupt record at offset ${end} (${tail.reason})`, {
          offset: end,
          reason: tail.reason,
        });
      }
      return { end, tail: { offset: end, reason: tail.reason, bytes: size - end } };
    }
    return { end: pos, tail: null };
  }

  // Looks for a complete valid frame anywhere after `from`. Only runs when there is
  // damage, so it can afford to read the rest of the file.
  #validFrameAfter(from, size) {
    let pos = from + 1;
    while (pos < size) {
      const window = this.ops.read(this.file, pos, SCAN_CHUNK);
      if (window.length === 0) return false;
      // Frames that start in this window but reach past it are read in full.
      let found = false;
      let index = window.indexOf(0xad);
      while (index !== -1 && !found) {
        if (window[index + 1] === 0xfb || index + 1 === window.length) {
          found = this.#validFrameAt(pos + index, size);
        }
        index = window.indexOf(0xad, index + 1);
      }
      if (found) return true;
      pos += window.length;
    }
    return false;
  }

  #validFrameAt(at, size) {
    const head = this.ops.read(this.file, at, FRAME_OVERHEAD);
    if (head.length < FRAME_OVERHEAD) return false;
    const length = head.readUInt32LE(2);
    if (length > MAX_PAYLOAD || at + FRAME_OVERHEAD + length > size) return false;
    return isValidFrameAt(this.ops.read(this.file, at, FRAME_OVERHEAD + length), 0);
  }

  truncate(length) {
    this.ops.truncate(this.file, length);
  }

  /** Writes records at the end of the file. Returns the new end offset. */
  append(records, { sync = true } = {}) {
    const type = records[0]?.t;
    const bytes = Buffer.concat(records.map(encodeFrame));
    const at = this.ops.size(this.file);
    hit('wal.before-append', { type });
    if (isArmed('wal.mid-append')) {
      const half = bytes.length >> 1;
      this.ops.writeAt(this.file, bytes.subarray(0, half), at);
      hit('wal.mid-append', { type });
      this.ops.writeAt(this.file, bytes.subarray(half), at + half);
    } else {
      this.ops.writeAt(this.file, bytes, at);
    }
    hit('wal.after-write', { type });
    if (sync) {
      this.ops.sync(this.file);
      hit('wal.after-fsync', { type });
    }
    return at + bytes.length;
  }
}
