// G1-G5: what survives crashes and power loss, and what damage is reported.

import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { test } from 'node:test';
import { CorruptLogError, inspectLog, ManualClock, openQueue } from '../src/index.mjs';
import { crashAt, runChild } from './helpers/crash.mjs';
import { tempDir } from './helpers/tmp.mjs';

const clock = () => new ManualClock(1_000);

function seed(t, count = 3) {
  const dir = tempDir(t);
  const queue = openQueue(dir, { clock: clock() });
  for (let i = 0; i < count; i += 1) queue.enqueue('x', { i });
  queue.close();
  return { dir, log: path.join(dir, 'wal.log') };
}

const payloads = (dir) => openQueue(dir, { clock: clock() }).listJobs().map((j) => j.payload.i);

test('a write after a cut-off tail is not lost behind it (G3)', (t) => {
  const { dir, log } = seed(t);
  fs.truncateSync(log, fs.statSync(log).size - 7);
  const queue = openQueue(dir, { clock: clock() });
  assert.equal(queue.stats().tornTailsDropped, 1);
  queue.enqueue('x', { i: 99 });
  queue.close();
  // Before the fix this reopened with CorruptLogError, or lost the new job.
  assert.deepEqual(payloads(dir), [0, 1, 99]);
});

test('a torn tail is cut off on disk, so a second reader sees a clean log', (t) => {
  const { dir, log } = seed(t);
  fs.appendFileSync(log, Buffer.from([0xad, 0xfb, 5, 0, 0]));
  openQueue(dir, { clock: clock() }).close();
  assert.equal(inspectLog(dir).tail, null);
});

test('a tail of zeros, as a power cut can leave, opens and is replaced', (t) => {
  const { dir, log } = seed(t);
  fs.appendFileSync(log, Buffer.alloc(300));
  const queue = openQueue(dir, { clock: clock() });
  queue.enqueue('x', { i: 7 });
  queue.close();
  assert.deepEqual(payloads(dir), [0, 1, 2, 7]);
});

test('a last record with a bad checksum is a torn write, even if followed by garbage', (t) => {
  const { dir, log } = seed(t);
  const bytes = fs.readFileSync(log);
  bytes[bytes.length - 3] ^= 0xff;
  fs.writeFileSync(log, Buffer.concat([bytes, Buffer.alloc(40, 0x11)]));
  const queue = openQueue(dir, { clock: clock() });
  assert.equal(queue.stats().total, 2);
  queue.close();
});

test('damage in the middle of the log is reported with its offset and nothing is changed (G4)', (t) => {
  const { dir, log } = seed(t, 4);
  const view = inspectLog(dir);
  const victim = view.frames[1];
  const bytes = fs.readFileSync(log);
  bytes[victim.offset + 14] ^= 0xff; // inside the second record's payload
  fs.writeFileSync(log, bytes);
  const before = fs.readFileSync(log);
  assert.throws(
    () => openQueue(dir, { clock: clock() }),
    (err) => err instanceof CorruptLogError && err.offset === victim.offset,
  );
  assert.throws(() => inspectLog(dir), CorruptLogError);
  assert.ok(fs.readFileSync(log).equals(before), 'the file was left as it was found');
});

test('a damaged length field is damage when records follow it, not a cut-off tail (G4)', (t) => {
  const { dir, log } = seed(t, 4);
  const victim = inspectLog(dir).frames[1];
  const bytes = fs.readFileSync(log);
  bytes.writeUInt32LE(0x03000000, victim.offset + 2); // claims a 48 MiB record
  fs.writeFileSync(log, bytes);
  assert.throws(
    () => openQueue(dir, { clock: clock() }),
    (err) => err instanceof CorruptLogError && err.offset === victim.offset,
  );
});

test('garbage in the middle that was appended after is reported, not skipped (G4)', (t) => {
  const { dir, log } = seed(t, 2);
  const frames = inspectLog(dir).frames;
  const bytes = fs.readFileSync(log);
  const gap = Buffer.alloc(25, 0x22);
  const damaged = Buffer.concat([bytes.subarray(0, frames[1].offset), gap, bytes.subarray(frames[1].offset)]);
  fs.writeFileSync(log, damaged);
  assert.throws(
    () => openQueue(dir, { clock: clock() }),
    (err) => err instanceof CorruptLogError && err.offset === frames[1].offset,
  );
});

test('a log far bigger than one read chunk opens with every job in it (G5)', (t) => {
  const dir = tempDir(t);
  const queue = openQueue(dir, { clock: clock(), compactAfterBytes: 0 });
  const padding = 'p'.repeat(2_000);
  const total = 1_800; // about 3.5 MiB of log
  for (let start = 0; start < total; start += 300) {
    queue.enqueueMany(Array.from({ length: 300 }, (_, i) => ({ type: 'x', payload: { n: start + i, padding } })));
  }
  const job = queue.claim('w');
  queue.complete(job.id, job.token, 'done');
  queue.close();

  assert.ok(fs.statSync(path.join(dir, 'wal.log')).size > 3 * 1024 * 1024);
  const reopened = openQueue(dir, { clock: clock(), compactAfterBytes: 0 });
  assert.equal(reopened.stats().total, total);
  assert.equal(reopened.stats().done, 1);
  // New ids carry on from the full count, and a compaction keeps every job.
  assert.equal(reopened.enqueue('x', null).id, `j${total + 1}`);
  reopened.compact();
  assert.equal(reopened.stats().total, total + 1);
});

test('a single record larger than a read chunk is read back (G5)', (t) => {
  const dir = tempDir(t);
  const queue = openQueue(dir, { clock: clock(), compactAfterBytes: 0 });
  const { id } = queue.enqueue('x', { blob: 'b'.repeat(3 * 1024 * 1024) });
  queue.enqueue('x', 'after');
  queue.close();
  const reopened = openQueue(dir, { clock: clock(), compactAfterBytes: 0 });
  assert.equal(reopened.getJob(id).payload.blob.length, 3 * 1024 * 1024);
  assert.equal(reopened.stats().total, 2);
  reopened.compact();
  assert.equal(reopened.getJob(id).payload.blob.length, 3 * 1024 * 1024);
});

test('a record over the format limit is refused before anything is written (G5)', (t) => {
  const { dir, log } = seed(t, 1);
  const queue = openQueue(dir, { clock: clock() });
  const before = fs.statSync(log).size;
  assert.throws(() => queue.enqueue('x', { blob: 'b'.repeat(65 * 1024 * 1024) }), /limit/);
  assert.equal(fs.statSync(log).size, before);
  assert.equal(queue.stats().total, 1);
});

test('a caller cannot change the queue by changing what it passed in', (t) => {
  const dir = tempDir(t);
  const queue = openQueue(dir, { clock: clock() });
  const payload = { list: [1] };
  const { id } = queue.enqueue('x', payload);
  payload.list.push(2);
  assert.deepEqual(queue.getJob(id).payload, { list: [1] });
});

test('killed at every point of an append, under power loss, the log opens and holds what was acknowledged', (t) => {
  for (const point of ['wal.before-append', 'wal.mid-append', 'wal.after-write', 'wal.after-fsync']) {
    const dir = tempDir(t);
    runChild(dir, 'enqueue', { arg: 2 });
    const { fired } = crashAt(t, dir, 'enqueue', `${point}=kill`, { arg: 1 });
    assert.ok(fired, point);
    const jobs = payloads(dir);
    // The crashed call was never acknowledged, except at after-fsync, where it is durable.
    assert.deepEqual(jobs.slice(0, 2), [0, 1], point);
    assert.equal(jobs.length, point === 'wal.after-fsync' ? 3 : 2, point);
    // And the queue carries on.
    const queue = openQueue(dir, { clock: clock() });
    queue.enqueue('x', { i: 50 });
    queue.close();
    assert.equal(payloads(dir).at(-1), 50, point);
  }
});

test('a brand new queue killed while it is being created opens afterwards (G2)', (t) => {
  for (const point of ['wal.after-create']) {
    const dir = tempDir(t);
    const { fired } = crashAt(t, dir, 'open', `${point}=kill`);
    assert.ok(fired);
    const queue = openQueue(dir, { clock: clock() });
    queue.enqueue('x', 1);
    assert.equal(queue.stats().total, 1);
  }
});

test('killed at every point of a compaction, under power loss, nothing is lost and compaction works again (G2, G12)', (t) => {
  for (const point of ['compact.after-tmp-write', 'compact.before-rename', 'compact.after-rename']) {
    const dir = tempDir(t);
    runChild(dir, 'enqueue', { arg: 5 });
    const { fired } = crashAt(t, dir, 'compact', `${point}=kill`);
    assert.ok(fired, point);
    const queue = openQueue(dir, { clock: clock() });
    assert.equal(queue.stats().total, 5, point);
    assert.deepEqual(
      queue.listJobs().map((j) => j.payload.i),
      [0, 1, 2, 3, 4],
      point,
    );
    // Whatever the dead compaction left behind must not stop the next one.
    queue.compact();
    queue.enqueue('x', { i: 5 });
    queue.close();
    assert.equal(payloads(dir).length, 6, point);
  }
});
