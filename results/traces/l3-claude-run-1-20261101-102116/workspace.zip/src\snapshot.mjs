// A compacted log starts with one snapshot record holding the state it replaces.

import { isPastRetention } from './retention.mjs';

function serializeJob(job) {
  return {
    id: job.id,
    type: job.type,
    payload: job.payload,
    key: job.key,
    priority: job.priority,
    status: job.status,
    attempts: job.attempts,
    fence: job.fence,
    maxAttempts: job.maxAttempts,
    availableAt: job.availableAt,
    lease: job.lease,
    result: job.result,
    lastError: job.lastError,
    enqueuedAt: job.enqueuedAt,
    completedAt: job.completedAt,
    completionSeq: job.completionSeq,
    seq: job.seq,
  };
}

/**
 * The idempotency keys still inside their time to live. A key outlives its job, so
 * for a job that is being dropped the entry keeps what a repeat enqueue is told.
 */
function serializeKeys(state, kept, now, config) {
  const entries = [];
  for (const [key, entry] of state.idem) {
    if (now - entry.at >= config.idempotencyTtlMs) continue;
    const item = { key, id: entry.id, at: entry.at };
    if (!kept.has(entry.id)) {
      const job = state.jobs.get(entry.id);
      item.status = job?.status ?? entry.status ?? 'done';
      item.result = job ? job.result : entry.result ?? null;
    }
    entries.push(item);
  }
  return entries;
}

/** Builds the snapshot record, dropping terminal jobs past their retention. */
export function buildSnapshot(state, now, config) {
  const kept = new Set();
  const jobs = [];
  for (const job of state.jobs.values()) {
    if (isPastRetention(job, now, config)) continue;
    kept.add(job.id);
    jobs.push(serializeJob(job));
  }

  return {
    t: 'snapshot',
    at: now,
    seq: state.seq,
    completionSeq: state.completionSeq,
    jobs,
    idem: serializeKeys(state, kept, now, config),
  };
}

export function loadSnapshot(state, rec) {
  state.seq = rec.seq;
  state.completionSeq = rec.completionSeq ?? 0;
  state.jobs = new Map();
  state.idem = new Map();
  for (const job of rec.jobs) {
    state.jobs.set(job.id, {
      ...job,
      priority: job.priority ?? 0,
      attempts: job.attempts ?? 0,
      fence: job.fence ?? job.lease?.fence ?? 0,
      completionSeq: job.completionSeq ?? null,
    });
    // Older snapshots have no key list. The newest job to hold a key owns it.
    const held = job.key ? state.idem.get(job.key) : null;
    if (job.key && (!held || job.enqueuedAt >= held.at)) {
      state.idem.set(job.key, { id: job.id, at: job.enqueuedAt });
    }
  }
  for (const entry of rec.idem ?? []) {
    const { key, ...rest } = entry;
    state.idem.set(key, rest);
  }
}
