// RFC 007: exactly-once completion. Receipts, results, reclaiming a dead worker's
// leases, the crash table, and the worker and pool behaviour around it.

import assert from 'node:assert/strict';
import path from 'node:path';
import { test } from 'node:test';
import { fileURLToPath } from 'node:url';
import {
  clearFailpoints,
  JobRunner,
  LockTimeoutError,
  ManualClock,
  openQueue,
  StaleLeaseError,
  UnknownJobError,
  WorkerPool,
} from '../src/index.mjs';
import { normaliseHandlers } from '../src/worker/registry.mjs';
import { crashAt, runChild } from './helpers/crash.mjs';
import { defer, readLedger, tempDir, waitUntil } from './helpers/tmp.mjs';

const HANDLERS = fileURLToPath(new URL('./helpers/handlers.mjs', import.meta.url));

function setup(t, options = {}) {
  t.after(clearFailpoints);
  const clock = new ManualClock(50_000);
  const dir = tempDir(t);
  const open = () => openQueue(dir, { clock, backoff: { baseMs: 1_000, factor: 2, maxMs: 60_000 }, ...options });
  return { clock, dir, open, queue: open() };
}

function claimed(queue, worker = 'w', leaseMs = 10_000) {
  const { id } = queue.enqueue('x', null);
  const job = queue.claim(worker, { leaseMs });
  assert.equal(job.id, id);
  return job;
}

test('complete returns a receipt, and a repeat with the same token returns the same one', (t) => {
  const { queue, clock } = setup(t);
  const job = claimed(queue);
  const first = queue.complete(job.id, job.token, { sent: true });
  assert.deepEqual(first, {
    id: job.id,
    outcome: 'committed',
    token: job.token,
    result: { sent: true },
    completedAt: 50_000,
    completionSeq: 1,
  });

  clock.advance(5_000);
  const size = queue.stats().logBytes;
  const again = queue.complete(job.id, job.token, { different: 'result' });
  assert.deepEqual(again, { ...first, outcome: 'already-committed' });
  assert.equal(queue.stats().logBytes, size, 'nothing is written for a repeat');
});

test('a repeat is recognised after a restart and after a compaction', (t) => {
  const { queue, open } = setup(t);
  const job = claimed(queue);
  const first = queue.complete(job.id, job.token, [1, 2]);
  queue.compact();
  assert.deepEqual(open().complete(job.id, job.token, 'x'), { ...first, outcome: 'already-committed' });
  assert.deepEqual(queue.complete(job.id, job.token, 'x'), { ...first, outcome: 'already-committed' });
});

test('any other token, or a pruned job, is refused and nothing changes', (t) => {
  const { queue, clock } = setup(t, { retainCompletedMs: 1_000 });
  const job = claimed(queue);
  assert.throws(() => queue.complete(job.id, job.token + 1, 'x'), StaleLeaseError);
  queue.complete(job.id, job.token, 'real');
  assert.throws(() => queue.complete(job.id, job.token + 1, 'x'), StaleLeaseError);
  assert.throws(() => queue.complete(job.id, job.token - 1, 'x'), StaleLeaseError);
  assert.equal(queue.getJob(job.id).result, 'real');
  clock.advance(1_000);
  queue.compact();
  assert.throws(() => queue.complete(job.id, job.token, 'x'), UnknownJobError);
});

test('a lease past its deadline can still commit until someone acts on it', (t) => {
  const { queue, clock } = setup(t);
  const job = claimed(queue, 'w', 500);
  clock.advance(10_000);
  assert.equal(queue.complete(job.id, job.token, 'late but first').outcome, 'committed');

  const second = claimed(queue, 'w', 500);
  clock.advance(10_000);
  queue.reapExpired();
  assert.throws(() => queue.complete(second.id, second.token, 'too late'), StaleLeaseError);
});

test('getResult reports a finished job, any other job by status, and an unknown one as null', (t) => {
  const { queue, clock } = setup(t, { retainCompletedMs: 1_000 });
  const waiting = queue.enqueue('x', 1).id;
  const job = queue.claim('w');
  assert.deepEqual(queue.getResult(job.id), { id: job.id, status: 'leased' });
  assert.deepEqual(queue.getResult(waiting === job.id ? 'nope' : waiting), waiting === job.id ? null : { id: waiting, status: 'ready' });
  queue.complete(job.id, job.token, { v: 1 });
  assert.deepEqual(queue.getResult(job.id), {
    id: job.id,
    status: 'done',
    result: { v: 1 },
    token: job.token,
    attempts: 1,
    completedAt: 50_000,
    completionSeq: 1,
  });
  assert.equal(queue.getResult('j999'), null);
  clock.advance(1_000);
  queue.compact();
  assert.equal(queue.getResult(job.id), null);
});

test('completions lists commits in order, numbered across restarts, compaction and pruning', (t) => {
  const { queue, clock, open } = setup(t, { retainCompletedMs: 10_000 });
  const finish = (result) => {
    const job = claimed(queue);
    queue.complete(job.id, job.token, result);
    return job.id;
  };
  const a = finish('a');
  const b = finish('b');
  queue.compact();
  const c = finish('c');
  assert.deepEqual(
    queue.completions().map((e) => [e.seq, e.id, e.result]),
    [[1, a, 'a'], [2, b, 'b'], [3, c, 'c']],
  );
  assert.deepEqual(queue.completions({ after: 1, limit: 1 }).map((e) => e.seq), [2]);
  assert.deepEqual(queue.completions({ after: 3 }), []);

  clock.advance(10_001);
  queue.compact(); // a, b and c are pruned
  assert.deepEqual(queue.completions(), []);
  const reopened = open();
  const job = claimed(reopened);
  const receipt = reopened.complete(job.id, job.token, 'd');
  assert.equal(receipt.completionSeq, 4, 'numbering carries on past what was pruned');
  assert.deepEqual(open().completions({ after: 3 }).map((e) => [e.seq, e.id, e.token]), [[4, job.id, job.token]]);
});

test('reclaimWorker gives a worker\'s jobs back at once, and only that worker\'s', (t) => {
  const { queue, clock } = setup(t);
  const mine = claimed(queue, 'dead-one');
  const other = claimed(queue, 'alive');
  const committed = claimed(queue, 'dead-one');
  queue.complete(committed.id, committed.token, 'done already');
  const size = queue.stats().logBytes;

  const out = queue.reclaimWorker('dead-one', { reason: 'worker exited' });
  assert.deepEqual(out, [{ id: mine.id, status: 'ready' }]);
  assert.equal(queue.getJob(mine.id).lastError, 'worker exited');
  assert.equal(queue.getJob(mine.id).status, 'ready');
  assert.equal(queue.getJob(other.id).status, 'leased');
  assert.equal(queue.getJob(committed.id).status, 'done');
  assert.ok(queue.stats().logBytes > size);
  assert.deepEqual(queue.reclaimWorker('dead-one'), [], 'nothing left to reclaim, nothing written');

  assert.throws(() => queue.heartbeat(mine.id, mine.token), StaleLeaseError);
  assert.throws(() => queue.complete(mine.id, mine.token, 'x'), StaleLeaseError);
  const again = queue.claim('w2');
  assert.equal(again.id, mine.id, 'runnable straight away, no backoff');
  assert.equal(again.attempt, 2);
  assert.notEqual(again.token, mine.token);
});

test('a reclaimed job that is out of attempts goes dead', (t) => {
  const { queue } = setup(t);
  const { id } = queue.enqueue('x', null, { maxAttempts: 1 });
  queue.claim('w');
  assert.deepEqual(queue.reclaimWorker('w', { reason: 'gone' }), [{ id, status: 'dead' }]);
  assert.equal(queue.getJob(id).status, 'dead');
  assert.equal(queue.getJob(id).lastError, 'gone');
});

test('a reclaim is the same after a restart and after a compaction', (t) => {
  const { queue, open } = setup(t);
  const job = claimed(queue, 'w');
  queue.reclaimWorker('w');
  queue.compact();
  const view = open().getJob(job.id);
  assert.equal(view.status, 'ready');
  assert.equal(view.attempts, 1);
  assert.equal(view.fence, job.token);
});

// ---- the crash table, with real processes and the power-loss model ----

test('killed part way through writing complete, the job runs again', (t) => {
  for (const point of ['wal.before-append#complete', 'wal.mid-append#complete', 'wal.after-write#complete']) {
    const { dir, open } = setup(t);
    runChild(dir, 'enqueue', { arg: 1 });
    assert.ok(crashAt(t, dir, 'run', `${point}=kill`).fired, point);
    const queue = open();
    const job = queue.listJobs()[0];
    assert.equal(job.status, 'leased', point);
    queue.reclaimWorker('doomed');
    const again = queue.claim('w2');
    assert.equal(again.id, job.id, point);
    assert.equal(queue.complete(again.id, again.token, 'second time').outcome, 'committed', point);
  }
});

test('killed after complete is durable, the job does not run again', (t) => {
  for (const point of ['wal.after-fsync#complete']) {
    const { dir, open } = setup(t);
    runChild(dir, 'enqueue', { arg: 1 });
    assert.ok(crashAt(t, dir, 'run', `${point}=kill`).fired, point);
    const queue = open();
    const job = queue.listJobs()[0];
    assert.equal(job.status, 'done', point);
    assert.deepEqual(queue.reclaimWorker('doomed'), [], point);
    assert.equal(queue.claim('w2'), null, point);
    queue.compact();
    assert.equal(open().claim('w2'), null);
    assert.equal(queue.complete(job.id, job.fence, 'x').outcome, 'already-committed');
  }
});

test('killed while a compaction runs after the commit, the commit still holds', (t) => {
  for (const point of ['compact.after-tmp-write', 'compact.before-rename', 'compact.after-rename']) {
    const { dir } = setup(t);
    runChild(dir, 'enqueue', { arg: 2 });
    runChild(dir, 'run');
    assert.ok(crashAt(t, dir, 'compact', `${point}=kill`).fired, point);
    const queue = openQueue(dir); // the child used the real clock
    assert.equal(queue.stats().done, 1, point);
    assert.equal(queue.claim('w2').payload.i, 1, 'only the other job is left to run');
    assert.equal(queue.claim('w2'), null);
  }
});

test('a completion is durable when complete returns: power loss right after loses nothing (G1)', (t) => {
  const { dir, open } = setup(t);
  runChild(dir, 'enqueue', { arg: 1 });
  // job.after-complete is the worker's point just after complete() returned.
  runChild(dir, 'run');
  assert.equal(open().stats().done, 1);
});

// ---- the worker ----

function fakeQueue(overrides) {
  const calls = [];
  const queue = {
    config: { leaseMs: 1_000 },
    calls,
    heartbeats: 0,
    jobs: [{ id: 'j1', type: 'quick', payload: null, attempt: 1, token: 1 }, { id: 'j2', type: 'quick', payload: null, attempt: 1, token: 1 }],
    claim() {
      calls.push('claim');
      return this.jobs.shift() ?? null;
    },
    heartbeat() {
      this.heartbeats += 1;
    },
    complete(id) {
      calls.push(`complete ${id}`);
      return { id, outcome: 'committed' };
    },
    fail(id) {
      calls.push(`fail ${id}`);
      return { id, status: 'ready' };
    },
    ...overrides,
  };
  return queue;
}

function runnerFor(queue, handlers, events) {
  const runner = new JobRunner({
    queue,
    workerId: 'w',
    handlers: normaliseHandlers(handlers),
    leaseMs: 1_000,
    heartbeatMs: 15,
    pollMs: 5,
    emit: (event) => {
      events.push(event);
      if (events.filter((e) => e.kind === 'job-completed' || e.kind === 'job-fenced').length >= 2) runner.stop();
    },
  });
  return runner;
}

test('a worker keeps trying to record a finished job, heartbeating, and takes no other job meanwhile', async () => {
  let failures = 0;
  const queue = fakeQueue({
    complete(id) {
      this.calls.push(`complete ${id}`);
      if (id === 'j1' && (failures += 1) <= 4) throw new LockTimeoutError('queue.lock', 10);
      return { id, outcome: 'committed' };
    },
  });
  const events = [];
  await runnerFor(queue, { quick: async () => 'r' }, events).run();
  assert.deepEqual(queue.calls.filter((c) => c !== 'claim'), ['complete j1', 'complete j1', 'complete j1', 'complete j1', 'complete j1', 'complete j2']);
  // j2 was claimed only after j1 was recorded.
  assert.deepEqual(queue.calls.slice(0, 7), ['claim', ...Array(5).fill('complete j1'), 'claim']);
  assert.ok(queue.heartbeats >= 1, 'the lease was kept alive while it retried');
  assert.equal(events.filter((e) => e.kind === 'job-completed').length, 2);
});

test('a worker that learns it was fenced reports job-fenced and stops trying', async () => {
  const queue = fakeQueue({
    complete(id) {
      this.calls.push(`complete ${id}`);
      if (id === 'j1') throw new StaleLeaseError(id, 1, 2);
      return { id, outcome: 'committed' };
    },
  });
  const events = [];
  await runnerFor(queue, { quick: async () => 'r' }, events).run();
  assert.equal(queue.calls.filter((c) => c === 'complete j1').length, 1);
  assert.deepEqual(events.filter((e) => e.kind === 'job-fenced').map((e) => e.id), ['j1']);
});

test('disk trouble while recording is waited out, as a transient error', async () => {
  let failures = 0;
  const queue = fakeQueue({
    complete(id) {
      this.calls.push(`complete ${id}`);
      if (id === 'j1' && (failures += 1) <= 2) throw Object.assign(new Error('busy'), { code: 'EBUSY' });
      return { id, outcome: 'committed' };
    },
  });
  const events = [];
  await runnerFor(queue, { quick: async () => 'r' }, events).run();
  assert.equal(queue.calls.filter((c) => c === 'complete j1').length, 3);
});

test('a result that cannot be stored fails the attempt instead of retrying forever', async (t) => {
  const dir = tempDir(t);
  const queue = openQueue(dir);
  const { id } = queue.enqueue('x', null, { maxAttempts: 1 });
  const events = [];
  const runner = new JobRunner({
    queue,
    workerId: 'w',
    handlers: normaliseHandlers({ x: async () => ({ big: 10n }) }),
    leaseMs: 5_000,
    pollMs: 5,
    emit: (e) => {
      events.push(e);
      if (e.kind === 'job-failed') runner.stop();
    },
  });
  await runner.run();
  assert.equal(queue.getJob(id).status, 'dead');
  assert.match(queue.getJob(id).lastError, /BigInt/);
});

// ---- the pool, with real worker processes ----

function pool(t, dir, ledger, extra = {}) {
  const p = new WorkerPool({
    dir,
    handlers: HANDLERS,
    pollMs: 5,
    reapMs: 10_000, // far longer than the tests, so only reclaiming can return a job early
    ...extra,
    env: { WALQ_TEST_LEDGER: ledger, ...(extra.env ?? {}) },
  });
  defer(t, () => p.stop());
  return p;
}

const starts = (ledger, id) => readLedger(ledger).filter((e) => e.event === 'start' && e.id === id).length;

for (const point of ['job.before-handler', 'job.after-handler']) {
  test(`a worker killed at ${point} has its job run again without waiting for the lease`, { timeout: 30_000 }, async (t) => {
    const dir = tempDir(t);
    const markers = tempDir(t);
    const ledger = path.join(dir, 'runs.jsonl');
    const queue = openQueue(dir);
    const { id } = queue.enqueue('quick', { n: 1 });
    const p = pool(t, dir, ledger, {
      size: 1,
      leaseMs: 120_000,
      env: { WALQ_FAILPOINTS: `${point}=kill`, WALQ_FAILPOINT_DIR: markers },
    });
    const started = performance.now();
    p.start();
    await waitUntil(() => queue.getJob(id).status === 'done', { timeoutMs: 20_000 });
    assert.ok(performance.now() - started < 15_000, 'did not wait for a 120 s lease');
    assert.equal(queue.getJob(id).attempts, 2);
    assert.equal(starts(ledger, id), point === 'job.before-handler' ? 1 : 2);
  });
}

for (const point of ['wal.after-fsync#complete', 'job.after-complete']) {
  test(`a worker killed at ${point} does not run the job again`, { timeout: 30_000 }, async (t) => {
    const dir = tempDir(t);
    const markers = tempDir(t);
    const ledger = path.join(dir, 'runs.jsonl');
    const queue = openQueue(dir);
    const { id } = queue.enqueue('quick', { n: 1 });
    const p = pool(t, dir, ledger, {
      size: 1,
      leaseMs: 120_000,
      env: { WALQ_FAILPOINTS: `${point}=kill`, WALQ_FAILPOINT_DIR: markers },
    });
    const exited = new Promise((resolve) => p.once('exit', resolve));
    p.start();
    await exited;
    await waitUntil(() => queue.getJob(id).status === 'done');
    // Give a respawned worker the chance to (wrongly) run it again.
    await new Promise((resolve) => setTimeout(resolve, 600));
    assert.equal(queue.getJob(id).attempts, 1);
    assert.equal(starts(ledger, id), 1);
    assert.equal(queue.getResult(id).completionSeq, 1);
  });
}

test('one pool reclaiming its dead worker does not touch another pool\'s workers', { timeout: 30_000 }, async (t) => {
  const dir = tempDir(t);
  const markers = tempDir(t);
  const ledger = path.join(dir, 'runs.jsonl');
  const queue = openQueue(dir);
  const slow = queue.enqueue('slow', { ms: 2_000 }).id;
  const quick = queue.enqueue('quick', { n: 1 }).id;
  const b = pool(t, dir, ledger, { size: 1, leaseMs: 120_000, types: ['slow'] });
  const a = pool(t, dir, ledger, {
    size: 1,
    leaseMs: 120_000,
    types: ['quick'],
    env: { WALQ_FAILPOINTS: 'job.before-handler=kill', WALQ_FAILPOINT_DIR: markers },
  });
  b.start();
  await waitUntil(() => queue.getJob(slow).status === 'leased');
  a.start();
  await waitUntil(() => queue.getJob(quick).status === 'done', { timeoutMs: 20_000 });
  await waitUntil(() => queue.getJob(slow).status === 'done', { timeoutMs: 20_000 });
  assert.equal(queue.getJob(quick).attempts, 2);
  assert.equal(queue.getJob(slow).attempts, 1, 'the other pool\'s job was left alone');
  assert.equal(starts(ledger, slow), 1);
});

test('a pool reclaims after a worker dies, even if the queue was busy at that moment', { timeout: 30_000 }, async (t) => {
  const dir = tempDir(t);
  const markers = tempDir(t);
  const ledger = path.join(dir, 'runs.jsonl');
  const queue = openQueue(dir);
  const { id } = queue.enqueue('quick', { n: 1 });
  const p = pool(t, dir, ledger, {
    size: 1,
    leaseMs: 120_000,
    reapMs: 100,
    env: { WALQ_FAILPOINTS: 'job.before-handler=kill', WALQ_FAILPOINT_DIR: markers },
  });
  let failed = 0;
  p.start();
  const original = p.queue.reclaimWorker.bind(p.queue);
  p.queue.reclaimWorker = (...args) => {
    failed += 1;
    if (failed === 1) throw new LockTimeoutError('queue.lock', 1);
    return original(...args);
  };
  p.on('error-event', () => {});
  await waitUntil(() => queue.getJob(id).status === 'done', { timeoutMs: 20_000 });
  assert.ok(failed >= 2, 'the failed reclaim was retried');
});
