// Store: the replayed state plus the rules for reading and writing the log.
// Every read of shared state and every write happens inside withLock(), which
// first brings this process up to date with whatever other processes wrote.

import path from 'node:path';
import { compactLog } from './compactor.mjs';
import { QueueClosedError } from './errors.mjs';
import { FORMAT_VERSION, HEADER_SIZE } from './frame.mjs';
import { createFileOps, ensureDir } from './fsops.mjs';
import { acquireLock } from './lock.mjs';
import { createLogger } from './logger.mjs';
import { applyRecord, createState } from './state.mjs';
import { Wal } from './wal.mjs';

export const WAL_FILE = 'wal.log';
export const LOCK_FILE = 'queue.lock';

const log = createLogger('store');

export class Store {
  constructor(dir, config) {
    this.dir = dir;
    this.config = config;
    this.clock = config.clock;
    this.ops = createFileOps();
    this.wal = new Wal(path.join(dir, WAL_FILE), this.ops);
    this.lockPath = path.join(dir, LOCK_FILE);
    this.state = createState();
    this.generation = null;
    this.offset = HEADER_SIZE;
    this.snapshotBytes = 0;
    this.tornTailsDropped = 0;
    this.lastCompactionError = null;
    this.compactRetryAt = 0;
    this.closed = false;
    this.holdingLock = false;
  }

  open() {
    ensureDir(this.dir);
    this.#locked(() => {
      if (!this.wal.exists()) this.wal.create();
      this.catchUp();
    });
  }

  close() {
    this.closed = true;
  }

  #locked(fn) {
    if (this.holdingLock) throw new Error('queue lock is not reentrant');
    const release = acquireLock(this.lockPath, { timeoutMs: this.config.lockTimeoutMs });
    this.holdingLock = true;
    try {
      return fn();
    } finally {
      this.holdingLock = false;
      release();
    }
  }

  withLock(fn) {
    if (this.closed) throw new QueueClosedError();
    return this.#locked(() => {
      this.catchUp();
      return fn();
    });
  }

  /** Brings this.state up to date with the log without doing anything else. */
  refresh() {
    this.withLock(() => {});
  }

  catchUp() {
    const header = this.wal.readHeader();
    // A compaction by any process starts a new generation, and this process has to
    // read the new log from its start however long the old one and the new one are.
    // A log that is now shorter than what was read has been cut from outside.
    if (this.generation !== header.generation || this.wal.size() < this.offset) {
      this.state = createState();
      this.offset = HEADER_SIZE;
      this.snapshotBytes = 0;
      this.compactRetryAt = 0;
      this.generation = header.generation;
    }

    // The offset moves with the state, so if the scan stops on damage, a later
    // catch-up does not apply the same records twice.
    const { end, tail } = this.wal.scanFrom(this.offset, (frames, upTo) => {
      for (const frame of frames) {
        applyRecord(this.state, frame.record);
        if (frame.record.t === 'snapshot') this.snapshotBytes = frame.size;
      }
      this.offset = upTo;
    });
    this.offset = end;

    if (tail) {
      // We hold the lock, and writes happen under it, so what is left after the
      // last whole record is a write that was cut off and never acknowledged. It
      // has to go before anything else is appended behind it.
      this.wal.truncate(end);
      this.tornTailsDropped += 1;
      log.warn('dropped incomplete tail', { offset: end, reason: tail.reason, bytes: tail.bytes });
    }
  }

  /** Must be called inside withLock(). */
  append(records, options) {
    const before = this.offset;
    let end;
    try {
      end = this.wal.append(records, options);
    } catch (err) {
      // Not acknowledged, so it must not become a record later. Best effort: if
      // this fails too, the next catch-up finds the bytes as an incomplete tail.
      try {
        this.wal.truncate(before);
      } catch {
        // see above
      }
      throw err;
    }
    this.offset = end;
    // Apply what a reader of the log will see, not the caller's live objects.
    for (const record of records) applyRecord(this.state, JSON.parse(JSON.stringify(record)));
  }

  /** Must be called inside withLock(). */
  compact() {
    const bytesBefore = this.offset;
    const { snapshot, generation, size } = compactLog({
      wal: this.wal,
      ops: this.ops,
      state: this.state,
      generation: this.generation,
      now: this.clock.now(),
      config: this.config,
    });
    this.state = createState();
    applyRecord(this.state, JSON.parse(JSON.stringify(snapshot)));
    this.generation = generation;
    this.offset = size;
    this.snapshotBytes = size - HEADER_SIZE;
    log.info('compacted', { generation, bytesBefore, bytesAfter: size });
    return { generation, bytesBefore, bytesAfter: size, jobs: this.state.jobs.size };
  }

  /**
   * Compacts when the log has outgrown the threshold. A failure here must not
   * fail the operation that triggered it, because that operation has committed.
   */
  maybeCompact() {
    const threshold = this.config.compactAfterBytes;
    if (!threshold) return;
    if (this.offset < threshold) return;
    // Compacting costs about the size of the live state. Waiting until the log has
    // doubled since the last compaction keeps the cost per write small even when
    // the state alone is bigger than the threshold.
    if (this.offset < 2 * (HEADER_SIZE + this.snapshotBytes)) return;
    // After a failure, give the cause time to go away instead of trying on every write.
    if (this.offset < this.compactRetryAt) return;
    try {
      this.compact();
      this.lastCompactionError = null;
      this.compactRetryAt = 0;
    } catch (err) {
      this.lastCompactionError = err;
      this.compactRetryAt = this.offset + Math.max(1, Math.floor(threshold / 2));
      log.warn('compaction failed', { error: err.message });
    }
  }

  describe() {
    return {
      format: FORMAT_VERSION,
      generation: this.generation,
      logBytes: this.offset,
      tornTailsDropped: this.tornTailsDropped,
      lastCompactionError: this.lastCompactionError?.message ?? null,
    };
  }
}
