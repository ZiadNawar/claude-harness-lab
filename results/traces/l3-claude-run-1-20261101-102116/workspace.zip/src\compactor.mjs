// Replaces the log with a one-record log holding the current state. Runs under
// the queue lock. docs/compaction.md describes the protocol.

import path from 'node:path';
import { encodeFrame, encodeHeader } from './frame.mjs';
import { hit } from './failpoints.mjs';
import { buildSnapshot } from './snapshot.mjs';

export function compactionTempPath(walFile) {
  return `${walFile}.compact`;
}

/**
 * Writes and installs the next generation of the log. Returns the snapshot and
 * the size of the new file. If this throws, the old log is still in place.
 */
export function compactLog({ wal, ops, state, generation, now, config }) {
  const nextGeneration = generation + 1;
  const snapshot = buildSnapshot(state, now, config);
  const bytes = Buffer.concat([encodeHeader(nextGeneration), encodeFrame(snapshot)]);
  const tempPath = compactionTempPath(wal.file);

  try {
    // Only the holder of the queue lock compacts, so a temp file that is already
    // here was left by an attempt that died or failed. Clear it, or one such
    // attempt would block every later one. Exclusive create still guards against
    // anything else writing the same name.
    ops.unlink(tempPath);
    ops.create(tempPath, { exclusive: true });
    ops.writeAt(tempPath, bytes, 0);
    // The bytes must be durable before the name is: renaming an unsynced file over
    // the log and then losing power leaves an empty log.
    ops.sync(tempPath);
    hit('compact.after-tmp-write', { generation: nextGeneration });
    hit('compact.before-rename', { generation: nextGeneration });
    ops.rename(tempPath, wal.file);
    hit('compact.after-rename', { generation: nextGeneration });
    ops.syncDir(path.dirname(wal.file));
  } catch (err) {
    // If the rename did not happen the temp file is garbage; if it did, it is gone.
    try {
      ops.unlink(tempPath);
    } catch {
      // The next compaction clears it again.
    }
    err.message = `compaction failed: ${err.message}`;
    throw err;
  }

  return { snapshot, generation: nextGeneration, size: bytes.length };
}
