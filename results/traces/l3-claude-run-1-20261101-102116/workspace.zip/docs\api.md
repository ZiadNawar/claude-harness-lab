# API

Everything is exported from `src/index.mjs`. The names and shapes on this page are a contract with the services that use walq.

## openQueue(dir, options)

| Option | Default | Meaning |
|---|---|---|
| `leaseMs` | 30 000 | Default lease length |
| `lockTimeoutMs` | 10 000 | How long a call waits for the lock before `LockTimeoutError` |
| `compactAfterBytes` | 4 MiB | Compact automatically past this size. `0` turns it off |
| `retainCompletedMs` | 24 h | How long finished jobs stay in the log after they finish |
| `idempotencyTtlMs` | 7 d | How long a key is remembered, from when the job was enqueued |
| `maxAttempts` | 5 | Default attempts per job |
| `backoff` | `{ baseMs: 1000, factor: 2, maxMs: 60000, jitter: 0 }` | Retry schedule |
| `clock` | system clock | Anything with `now()`. Tests use `ManualClock` |

## Queue

**`enqueue(type, payload, { key, delayMs, maxAttempts, priority })`** returns `{ id, status, deduped }`. With a remembered `key` it also returns the existing job's `result` and `deduped: true`, and creates nothing.

**`enqueueMany([{ type, payload, options }])`** adds a batch under one lock and one sync. A crash can leave a prefix of the batch behind.

**`claim(worker, { leaseMs, types })`** returns `{ id, type, payload, attempt, token, leaseUntil }` or `null`. Among due jobs, higher `priority` goes first, then the job due longest, then the oldest. `token` identifies this attempt.

**`heartbeat(id, token, { leaseMs })`** returns `{ leaseUntil }`. Throws `StaleLeaseError` if the lease is no longer yours. The extension is written to the log, so every process sees it, including whichever one runs the reaper.

**`complete(id, token, result)`** commits the result and returns a receipt `{ id, outcome, token, result, completedAt, completionSeq }`. The commit is the moment the record is durable, and that happens before the call returns. `outcome` is `'committed'` the first time. A repeat with the token that committed, even after a restart or a compaction, returns `outcome: 'already-committed'` with the stored `result`, `completedAt` and `completionSeq`, ignores the result passed in, and writes nothing. Any other token throws `StaleLeaseError` and changes nothing. A job that has been pruned throws `UnknownJobError`. A lease past its deadline can still commit, as long as no reaper, reclaim or cancel has acted on it. See [rfc-007](rfc-007-exactly-once-completion.md).

**`getResult(id)`** returns `{ id, status: 'done', result, token, attempts, completedAt, completionSeq }` for a finished job, `{ id, status }` for any other job, and `null` for a job that never existed or has been pruned. Results are kept for `retainCompletedMs`.

**`completions({ after = 0, limit })`** returns the retained commits in commit order, `[{ seq, id, token, result, completedAt }]`, with `seq > after`. Numbers start at 1 and go up by one per commit, across restarts and compactions, including after older entries were pruned. Readers keep their own position. Jobs that finished before this existed have no number and are not listed.

**`reclaimWorker(workerId, { reason })`** gives up every lease held by a worker known to be dead, at once, and returns `[{ id, status }]`. Each job is `ready` and runnable straight away (no backoff), with `reason` as its `lastError`, or `dead` if it is out of attempts. The attempt counts. Jobs the worker already committed are not touched. The old token is stale from then on. Only call this for a worker that cannot still be running. `WorkerPool` makes its worker ids unique (`w<n>.<pool id>`), so one pool never reclaims another's.

**`fail(id, token, error)`** returns `{ id, status, retryAt }`. The job goes back to `ready` with a backoff, or to `dead` when attempts run out.

**`reapExpired()`** returns jobs whose lease had run out to the queue, and returns `[{ id, status, retryAt }]`.

**`cancel(id, { reason })`** stops a job that is `ready` or `leased`. Returns `{ id, status, changed }`. A worker holding the job loses its lease.

**`requeueDead(id)`** gives a dead job a new set of attempts, runnable now. Returns `{ id, status }`. Throws `InvalidTransitionError` if the job is not dead.

**`getJob(id)`** returns a copy of the job or `null`. **`listJobs()`** returns copies of all jobs in the log. **`stats()`** returns counts by status, plus `total`, `generation`, `logBytes`, `tornTailsDropped` (cut-off writes this process found and removed) and `lastCompactionError`. **`metrics()`** is described in [operations.md](operations.md).

**`compact()`** rewrites the log now and returns `{ generation, bytesBefore, bytesAfter, jobs }`. If it throws, the queue is still usable and nothing is lost.

**`close()`** marks this instance closed.

## Job fields

`id`, `type`, `payload`, `key`, `priority`, `status` (`ready`, `leased`, `done`, `dead`, `cancelled`), `attempts`, `fence` (the current token), `maxAttempts`, `availableAt`, `lease` (`{ worker, fence, until }` or null), `result`, `lastError`, `enqueuedAt`, `completedAt`, `seq`.

## WorkerPool

```js
new WorkerPool({ dir, handlers, size, leaseMs, heartbeatMs, pollMs, reapMs, types, env, queue, maxRespawns })
```

`handlers` is the path of a handlers module. `queue` is the options object for `openQueue` in the workers and the pool, so it must be JSON-serialisable. `env` adds environment variables for the workers. `types` limits which job types the pool's workers take.

- `start()` starts the workers.
- `drain({ timeoutMs })` resolves when no job is `ready` or `leased`, and rejects when that takes too long.
- `stop()` stops the workers and waits for them to go.

A worker that has run a handler keeps trying to record the outcome until it is recorded or the worker learns it was fenced (`job-fenced`). It keeps heartbeating meanwhile and takes no other job. A `worker-error` message is sent for each failed try. A result that cannot be stored at all (not JSON, over the size limit) fails the attempt instead.

The pool is an `EventEmitter`. `message` carries worker events (`kind` is one of `ready`, `job-started`, `job-completed`, `job-failed`, `job-fenced`, `worker-error`), `exit` fires when a worker exits (by then the pool has reclaimed that worker's leases and is starting a replacement), and `stderr` and `error-event` report problems.

## Errors

`WalqError` is the base class. `CorruptLogError` has an `offset`. It means damage to records that may have been acknowledged, and the file is left untouched. Also `StaleLeaseError`, `UnknownJobError`, `LockTimeoutError`, `InvalidTransitionError`, `ConfigError`, `QueueClosedError`.

## Other exports

`computeBackoff(attempts, policy, salt)`, `ManualClock`, `SystemClock`, `JobRunner`, `inspectLog(dir)`, `describeRecord(record)`, `onFailpoint`, `clearFailpoints`, `hit`.
