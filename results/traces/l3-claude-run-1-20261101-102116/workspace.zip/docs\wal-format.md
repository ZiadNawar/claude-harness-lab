# Log format

The format is a compatibility contract. Logs already on production hosts must stay readable, so changes must be additive.

## File

`wal.log` is a header followed by frames. All integers are little-endian.

### Header (20 bytes)

| Offset | Size | Field |
|---|---|---|
| 0 | 4 | Magic, ASCII `WALQ` |
| 4 | 2 | Format version, currently 1 |
| 6 | 2 | Flags, zero |
| 8 | 4 | Generation |
| 12 | 4 | Reserved, zero |
| 16 | 4 | CRC-32 of bytes 0 to 15 |

A new log starts at generation 1. Each compaction adds one.

### Frame (10 bytes + payload)

| Offset | Size | Field |
|---|---|---|
| 0 | 2 | Magic, bytes `AD FB` |
| 2 | 4 | Payload length |
| 6 | 4 | CRC-32 over the length field and then the payload |
| 10 | n | Payload: one record, as UTF-8 JSON |

The payload limit is 64 MiB. Writers refuse a record over it before writing anything, and readers read frames of any size up to it. Valid UTF-8 cannot contain the byte `FB`.

### Damage and cut-off writes

A write that was cut off (a crash, a power cut) can leave bytes at the end of the file that are not a whole valid frame: a short frame, a frame with a bad checksum, or zeros. The rule readers and writers follow is the same:

- If **no valid frame follows** the first bad byte, it is a cut-off write that was never acknowledged. Readers ignore it. The next process to take the queue lock cuts it off the file before appending, so nothing is ever written behind it.
- If **a valid frame follows**, the bad bytes sit inside records that may have been acknowledged. That is damage: `CorruptLogError` with the offset, and the file is left as it was found.

## Records

Every record has `t`, its type, and `at`, the writer's clock when it was written (a snapshot's `at` is when it was built).

| `t` | Fields | Effect |
|---|---|---|
| `enqueue` | `id, type, payload, key, priority, maxAttempts, availableAt, at` | A new job, `ready` |
| `claim` | `id, worker, fence, leaseUntil, at` | Job `leased`, attempts + 1, token = `fence` |
| `heartbeat` | `id, fence, leaseUntil, at` | Lease deadline moves. Written (and synced) by every `heartbeat()` call |
| `complete` | `id, fence, result, at` | Job `done` |
| `fail` | `id, fence, error, delayMs, at` | Job `ready` again, after a delay |
| `expire` | `id, fence, error, delayMs, at` | Same, because the lease ran out |
| `dead` | `id, fence, error, at` | Job `dead` |
| `cancel` | `id, fence, error, at` | Job `cancelled` |
| `release` | `id, fence, error, at` | Same as `expire` but runnable at `at`, with no delay: the worker holding the lease is known to be dead (RFC 007) |
| `requeue` | `id, at` | Dead job `ready` again, attempts back to 0. The fence is kept |
| `snapshot` | `at, seq, jobs, ...` | Replaces all state. Always the first record of a compacted log |

A record that acts on an attempt (`heartbeat`, `complete`, `fail`, `expire`, `release`, `dead`) counts only if the job is `leased` and `fence` is its current fence; `claim` only if the job is `ready`; `requeue` only if it is `dead`. Anything else is a late or repeated record and replay ignores it. A retry's due time is the record's `at` plus `delayMs`: replay never reads the clock.

A reader ignores record types it doesn't know. A snapshot holds, for each kept job, every job field (`priority`, `attempts`, `fence`, `completionSeq` included), the counters `seq` and `completionSeq`, and `idem`: the idempotency keys still inside their time to live, as `{ key, id, at }`, plus `status` and `result` for a key whose job has been dropped. Older logs may lack newer fields: `priority` counts as 0, and an older snapshot may lack `attempts`, `fence` and `idem`.

Job ids are `j<n>`, where `n` is the count of jobs ever enqueued, and are never reused.
