// Runs one action against the queue in argv[2], for crash tests. Arm a failpoint
// (and WALQ_SIMULATE_POWER_LOSS=1) in the environment to have it die part way.
//
//   open          open the queue (creates it if needed)
//   enqueue N     enqueue N jobs, one call each
//   compact       compact once
//   run           claim one job as worker "doomed", then complete it
//   claim         claim one job as worker "doomed" and stop

import { openQueue } from '../../src/index.mjs';

const [dir, action, arg] = process.argv.slice(2);
const options = process.env.WALQ_TEST_OPTIONS ? JSON.parse(process.env.WALQ_TEST_OPTIONS) : {};
const queue = openQueue(dir, options);

if (action === 'enqueue') {
  for (let i = 0; i < Number(arg ?? 1); i += 1) queue.enqueue('x', { i });
} else if (action === 'compact') {
  queue.compact();
} else if (action === 'run' || action === 'claim') {
  const job = queue.claim('doomed');
  if (job && action === 'run') queue.complete(job.id, job.token, { done: job.id });
}
queue.close();
