// JobRunner: the loop a worker process runs. Claim a job, run its handler with a
// heartbeat going, then record the outcome.

import { sleep } from '../clock.mjs';
import { LockTimeoutError, StaleLeaseError, UnknownJobError, WalqError } from '../errors.mjs';
import { hit } from '../failpoints.mjs';
import { JOB_COMPLETED, JOB_FAILED, JOB_FENCED, JOB_STARTED, WORKER_ERROR } from './protocol.mjs';
import { runWithTimeout } from './registry.mjs';

const RETRY_FIRST_MS = 10;
const RETRY_MAX_MS = 500;

// Trouble that is about the moment, not the request: the queue is busy, or the disk
// refused for now (EBUSY, EPERM and the like). Asking again can work. A call that
// fails for any other reason will fail the same way every time.
function isTransient(err) {
  if (err instanceof LockTimeoutError) return true;
  return !(err instanceof WalqError) && typeof err?.code === 'string' && /^E[A-Z0-9]+$/.test(err.code);
}

export class JobRunner {
  constructor({ queue, workerId, handlers, leaseMs, heartbeatMs, pollMs = 20, types = null, emit = () => {} }) {
    this.queue = queue;
    this.workerId = workerId;
    this.handlers = handlers;
    this.leaseMs = leaseMs ?? queue.config.leaseMs;
    this.heartbeatMs = heartbeatMs ?? Math.max(10, Math.floor(this.leaseMs / 3));
    this.pollMs = pollMs;
    this.types = types;
    this.emit = emit;
    this.stopping = false;
  }

  stop() {
    this.stopping = true;
  }

  async run() {
    while (!this.stopping) {
      const job = this.#claimNext();
      if (job) await this.execute(job);
      else await sleep(this.pollMs);
    }
  }

  #claimNext() {
    try {
      return this.queue.claim(this.workerId, { leaseMs: this.leaseMs, types: this.types });
    } catch (err) {
      if (!(err instanceof WalqError) && !isTransient(err)) throw err;
      this.emit({ kind: WORKER_ERROR, error: err.message });
      return null;
    }
  }

  async execute(job) {
    const { id, token } = job;
    hit('job.before-handler', { id });
    this.emit({ kind: JOB_STARTED, id, attempt: job.attempt, token });

    const abort = new AbortController();
    // Keeps going until the outcome is recorded, however long that takes: a lease
    // that runs out while we are still trying to commit would hand the job to
    // someone else.
    const beat = setInterval(() => {
      try {
        this.queue.heartbeat(id, token, { leaseMs: this.leaseMs });
      } catch (err) {
        if (err instanceof StaleLeaseError) {
          clearInterval(beat);
          abort.abort();
        } else {
          this.emit({ kind: WORKER_ERROR, error: err.message });
        }
      }
    }, this.heartbeatMs);

    try {
      let result;
      try {
        const handler = this.handlers.get(job.type);
        if (!handler) throw new Error(`no handler for job type ${job.type}`);
        result = await runWithTimeout(
          handler,
          job.payload,
          { id, attempt: job.attempt, token, workerId: this.workerId, signal: abort.signal },
          abort,
        );
      } catch (err) {
        await this.#recordFailure(id, token, err);
        return;
      }

      hit('job.after-handler', { id });
      const committed = await this.#record(id, () => this.queue.complete(id, token, result));
      if (committed.state === 'recorded') {
        this.emit({ kind: JOB_COMPLETED, id });
        hit('job.after-complete', { id });
      } else if (committed.state === 'fenced') {
        this.emit({ kind: JOB_FENCED, id });
      } else {
        // The result itself cannot be stored (it is not JSON, say). Retrying the
        // commit cannot help, so the attempt fails and says why.
        await this.#recordFailure(id, token, committed.error);
      }
    } finally {
      clearInterval(beat);
    }
  }

  async #recordFailure(id, token, cause) {
    const failed = await this.#record(id, () => this.queue.fail(id, token, cause));
    if (failed.state === 'recorded') this.emit({ kind: JOB_FAILED, id, error: cause?.message });
    else if (failed.state === 'fenced') this.emit({ kind: JOB_FENCED, id });
    else this.emit({ kind: WORKER_ERROR, id, error: failed.error.message });
  }

  // Records an outcome and does not give up on it. Waiting out a busy queue or a
  // disk that hiccups is the only way to end the attempt properly; the worker takes
  // no other job meanwhile. It stops only when the call went through, when it learns
  // the lease is gone (an expected end for this attempt, not an error), or when the
  // call can never succeed.
  async #record(id, call) {
    let wait = RETRY_FIRST_MS;
    for (;;) {
      try {
        return { state: 'recorded', value: call() };
      } catch (err) {
        if (err instanceof StaleLeaseError || err instanceof UnknownJobError) return { state: 'fenced' };
        if (!isTransient(err)) return { state: 'rejected', error: err };
        this.emit({ kind: WORKER_ERROR, id, error: err.message });
        await sleep(wait);
        wait = Math.min(wait * 2, RETRY_MAX_MS);
      }
    }
  }
}
