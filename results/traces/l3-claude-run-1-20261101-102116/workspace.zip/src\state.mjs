// The queue's state is a pure fold over the log. Replaying the same records must
// give the same state in every process, at any time. Nothing here reads the clock:
// every time in the state comes from a record.

import { loadSnapshot } from './snapshot.mjs';

export function createState() {
  return { jobs: new Map(), idem: new Map(), seq: 0, completionSeq: 0 };
}

function requeue(job, availableAt, error) {
  job.status = 'ready';
  job.availableAt = availableAt;
  job.lease = null;
  job.lastError = error ?? job.lastError;
}

// A record that acts on an attempt only counts while that attempt is the job's
// current one. Anything else is a late or repeated record, such as a reaper that
// worked from out-of-date state, and replaying it must not undo what came after.
function holdsLease(job, rec) {
  return job.status === 'leased' && job.fence === rec.fence;
}

export function applyRecord(state, rec) {
  if (rec.t === 'snapshot') {
    loadSnapshot(state, rec);
    return;
  }
  if (rec.t === 'enqueue') {
    state.seq += 1;
    state.jobs.set(rec.id, {
      id: rec.id,
      type: rec.type,
      payload: rec.payload,
      key: rec.key ?? null,
      priority: rec.priority ?? 0,
      status: 'ready',
      attempts: 0,
      fence: 0,
      maxAttempts: rec.maxAttempts,
      availableAt: rec.availableAt,
      lease: null,
      result: null,
      lastError: null,
      enqueuedAt: rec.at,
      completedAt: null,
      completionSeq: null,
      seq: state.seq,
    });
    if (rec.key) state.idem.set(rec.key, { id: rec.id, at: rec.at });
    return;
  }

  const job = state.jobs.get(rec.id);
  if (!job) return;

  switch (rec.t) {
    case 'claim':
      if (job.status !== 'ready') break;
      job.status = 'leased';
      job.attempts += 1;
      job.fence = rec.fence;
      job.lease = { worker: rec.worker, fence: rec.fence, until: rec.leaseUntil };
      break;
    case 'heartbeat':
      if (holdsLease(job, rec)) job.lease.until = rec.leaseUntil;
      break;
    case 'complete':
      if (!holdsLease(job, rec)) break;
      state.completionSeq += 1;
      job.status = 'done';
      job.lease = null;
      job.result = rec.result ?? null;
      job.completedAt = rec.at;
      job.completionSeq = state.completionSeq;
      break;
    case 'fail':
    case 'expire':
      if (!holdsLease(job, rec)) break;
      requeue(job, rec.at + rec.delayMs, rec.error);
      break;
    case 'release':
      if (!holdsLease(job, rec)) break;
      requeue(job, rec.at, rec.error);
      break;
    case 'dead':
      if (!holdsLease(job, rec)) break;
      job.status = 'dead';
      job.lease = null;
      job.lastError = rec.error ?? job.lastError;
      job.completedAt = rec.at;
      break;
    case 'cancel':
      if (job.status !== 'ready' && job.status !== 'leased') break;
      job.status = 'cancelled';
      job.lease = null;
      job.lastError = rec.error ?? job.lastError;
      job.completedAt = rec.at;
      break;
    case 'requeue':
      if (job.status !== 'dead') break;
      // The fence stays: a token is never issued twice for a job.
      job.attempts = 0;
      job.completedAt = null;
      requeue(job, rec.at, job.lastError);
      break;
    default:
      // Unknown record types come from a newer writer; ignoring them keeps old
      // tools able to read the rest of the log.
      break;
  }
}
