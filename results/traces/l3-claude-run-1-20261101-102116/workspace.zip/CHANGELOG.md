# Changelog

## 0.5.0

Fixes for the data-loss and duplicate-run bugs found after the power-loss incident, and RFC 007.

- A log with a cut-off tail reopens, and the tail is removed before anything is appended behind it (before, new records landed after the garbage and the next open failed). A bad checksum or zeros at the end count as cut-off; damage with valid records after it is still `CorruptLogError`.
- Catching up reads the whole log, a chunk at a time. Before, a process read at most 1 MiB, so a big log restarted with most of its jobs missing, and a record over 1 MiB could not be read at all.
- Processes follow a compaction by generation, not by file size.
- Compaction syncs the new log before it takes the name (a power cut could leave an empty log), clears a stale temp file (one dead compaction used to block all later ones with EEXIST), and removes its temp file when it fails.
- Snapshots keep `attempts`, `fence`, `priority` and the idempotency keys. Before, compaction reset attempt counts (a failing job never reached `maxAttempts`), reset tokens and forgot keys of pruned jobs.
- Retry due times come from the record, not from when it was replayed.
- Heartbeats are written to the log. Before, they were kept in the worker, so the reaper took live workers' jobs.
- Claiming, reaping and keyed enqueue decide under the lock. Before, two processes could claim one job, or create two jobs for one key.
- A token must be the current attempt's, and a requeue keeps the fence, so tokens are not reused.
- `complete` is synced before it returns.
- Auto-compaction waits for the log to double since the last one, and backs off after a failure.
- Records over the 64 MiB limit are refused before writing. `cancelled` jobs are pruned like the other finished ones.
- `walq tail` no longer holds the log open between polls.
- RFC 007: `complete` returns a receipt, `getResult`, `completions`, `reclaimWorker`, the `release` record, pools reclaim when a worker exits, and workers keep retrying to record a finished job.
- Worker ids from a pool are now `w<n>.<pool id>`.

## 0.4.2

- Throughput work for busy queues: less log growth and fewer syncs in the common paths.
- Lower memory use when a process catches up.

## 0.4.1

- `cancel()` and `requeueDead()`.
- Job priorities.
- `metrics()` and the `metrics` command.

## 0.4.0

- Smaller snapshots.
- Worker pools replace dead workers automatically.
- Failpoints for crash testing.

## 0.3.0

- Idempotency keys.
- Automatic compaction past `compactAfterBytes`.

## 0.2.0

- Multi-process access through a shared lock. Workers became child processes.

## 0.1.0

- First version: one process, one log.
