// G6-G14: several processes on one log, leases, retries, keys and compaction.
// Two Queue instances over one directory stand in for two processes: each has its
// own state and offset, and they share only the log and the lock.

import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { test } from 'node:test';
import { clearFailpoints, ManualClock, onFailpoint, openQueue, StaleLeaseError } from '../src/index.mjs';
import { tempDir } from './helpers/tmp.mjs';

const BACKOFF = { baseMs: 100, factor: 2, maxMs: 10_000 };

function pair(t, options = {}) {
  t.after(clearFailpoints);
  const clock = new ManualClock(10_000);
  const dir = tempDir(t);
  const open = () => openQueue(dir, { clock, backoff: BACKOFF, ...options });
  return { clock, dir, a: open(), b: open(), open };
}

test('two processes racing to claim one job: only one gets it (G6)', (t) => {
  const { a, b } = pair(t);
  a.enqueue('x', 1);
  let rival = null;
  // The moment between "a job is due" and "take the lock" is where another process gets in.
  onFailpoint('claim.before-lock', () => {
    clearFailpoints();
    rival = b.claim('rival');
  });
  const mine = a.claim('me');
  assert.ok(rival, 'the rival got the job');
  assert.equal(mine, null, 'the slower claimer must not take it again');
  assert.equal(a.getJob(rival.id).fence, 1);
  assert.equal(a.getJob(rival.id).attempts, 1);
});

test('a claim that lost the race takes the next job instead', (t) => {
  const { a, b } = pair(t);
  const first = a.enqueue('x', 1).id;
  const second = a.enqueue('x', 2).id;
  onFailpoint('claim.before-lock', () => {
    clearFailpoints();
    assert.equal(b.claim('rival').id, first);
  });
  assert.equal(a.claim('me').id, second);
});

test('a heartbeat is seen by the process that reaps leases (G7)', (t) => {
  const { a, b, clock } = pair(t);
  a.enqueue('x', 1);
  const job = a.claim('w', { leaseMs: 500 });
  for (let i = 0; i < 6; i += 1) {
    clock.advance(400);
    a.heartbeat(job.id, job.token, { leaseMs: 500 });
    assert.deepEqual(b.reapExpired(), [], 'a live worker keeps its job');
  }
  clock.advance(500);
  assert.equal(b.reapExpired().length, 1);
  assert.throws(() => a.heartbeat(job.id, job.token), StaleLeaseError);
});

test('a reaper working from out-of-date state does not reap a job that was committed or extended (G7)', (t) => {
  const { a, b, clock } = pair(t);
  a.enqueue('x', 1);
  a.enqueue('x', 2);
  const slow = a.claim('w', { leaseMs: 500 });
  const done = a.claim('w', { leaseMs: 500 });
  clock.advance(600);
  onFailpoint('reap.before-lock', () => {
    clearFailpoints();
    a.complete(done.id, done.token, 'ok');
    a.heartbeat(slow.id, slow.token, { leaseMs: 500 });
  });
  assert.deepEqual(b.reapExpired(), []);
  assert.equal(a.getJob(done.id).status, 'done');
  assert.equal(a.getJob(slow.id).status, 'leased');
});

test('an old token cannot touch a job that someone else holds now (G8)', (t) => {
  const { a, b, clock } = pair(t);
  const { id } = a.enqueue('x', 1);
  const old = a.claim('w1', { leaseMs: 500 });
  clock.advance(500);
  b.reapExpired();
  clock.advance(100);
  const current = b.claim('w2');
  assert.equal(current.id, id);
  assert.notEqual(current.token, old.token);
  assert.throws(() => a.heartbeat(id, old.token), StaleLeaseError);
  assert.throws(() => a.fail(id, old.token, 'late'), StaleLeaseError);
  assert.throws(() => a.complete(id, old.token, 'late'), StaleLeaseError);
  assert.equal(a.getJob(id).status, 'leased');
  assert.equal(a.getJob(id).lease.worker, 'w2');
});

test('a token is never issued twice for a job, even across requeueDead (G6)', (t) => {
  const { a, clock } = pair(t, { backoff: { baseMs: 0 } });
  const { id } = a.enqueue('x', 1, { maxAttempts: 1 });
  const seen = [];
  for (let round = 0; round < 3; round += 1) {
    const job = a.claim('w');
    seen.push(job.token);
    a.fail(job.id, job.token, 'no');
    assert.equal(a.getJob(id).status, 'dead');
    a.requeueDead(id);
    clock.advance(1);
  }
  assert.equal(new Set(seen).size, 3, `tokens ${seen}`);
});

test('a retry keeps the due time it was given when it failed, through restarts and compaction (G9)', (t) => {
  const { a, clock, open } = pair(t);
  const { id } = a.enqueue('x', 1);
  const job = a.claim('w');
  const { retryAt } = a.fail(job.id, job.token, 'boom');
  assert.equal(retryAt, 10_100);

  clock.advance(5_000);
  const other = open();
  assert.equal(other.getJob(id).availableAt, 10_100, 'a restarted process sees the same time');
  a.compact();
  assert.equal(open().getJob(id).availableAt, 10_100);
  assert.equal(other.claim('w').id, id, 'and the job is due, not pushed out to the restart');
});

test('attempts, backoff and maxAttempts survive compaction and restart (G9, G11)', (t) => {
  const { a, clock, open } = pair(t, { backoff: { baseMs: 100, factor: 2, maxMs: 100_000 } });
  const { id } = a.enqueue('x', 1, { maxAttempts: 4 });
  const delays = [];
  let queue = a;
  for (let attempt = 1; attempt <= 3; attempt += 1) {
    const job = queue.claim('w');
    assert.equal(job.attempt, attempt);
    const out = queue.fail(job.id, job.token, `fail ${attempt}`);
    delays.push(out.retryAt - clock.now());
    queue.compact();
    queue = open();
    clock.advance(out.retryAt - clock.now());
  }
  assert.deepEqual(delays, [100, 200, 400]);
  const last = queue.claim('w');
  assert.equal(queue.fail(last.id, last.token, 'last').status, 'dead');
  assert.equal(queue.getJob(id).attempts, 4);
});

test('compaction changes nothing observable but retention (G11)', (t) => {
  const { a, clock } = pair(t, { backoff: { baseMs: 100 } });
  a.enqueue('hi', { n: 1 }, { priority: 5, key: 'k1', maxAttempts: 7 });
  a.enqueue('lo', { n: 2 });
  a.enqueue('later', { n: 3 }, { delayMs: 5_000 });
  const leased = a.claim('w', { leaseMs: 900 });
  const failed = a.claim('w');
  a.fail(failed.id, failed.token, 'oops');
  clock.advance(1);
  const before = a.listJobs();
  a.compact();
  assert.deepEqual(a.listJobs(), before);
  assert.equal(a.getJob(leased.id).lease.fence, leased.token);
});

test('a key is remembered after its job is pruned, across compactions and restarts (G10)', (t) => {
  const { a, clock, open } = pair(t, { retainCompletedMs: 1_000 });
  const first = a.enqueue('report', { month: 'sep' }, { key: 'report-sep' });
  const job = a.claim('w');
  a.complete(job.id, job.token, { sent: true });

  clock.advance(2_000);
  a.compact(); // the job is dropped here
  assert.equal(a.getJob(first.id), null);

  for (let round = 0; round < 3; round += 1) {
    const again = open().enqueue('report', { month: 'sep' }, { key: 'report-sep' });
    assert.equal(again.deduped, true, `round ${round}`);
    assert.equal(again.id, first.id);
    assert.equal(again.status, 'done');
    assert.deepEqual(again.result, { sent: true });
    a.compact();
    clock.advance(24 * 60 * 60 * 1000);
  }
  assert.equal(a.stats().total, 0, 'nothing was created');

  // Past its time to live (7 days from enqueue) the key is free again.
  clock.advance(8 * 24 * 60 * 60 * 1000);
  a.compact();
  assert.equal(open().enqueue('report', null, { key: 'report-sep' }).deduped, false);
});

test('two processes racing on one key create one job (G10)', (t) => {
  const { a, b } = pair(t);
  let rival;
  onFailpoint('enqueue.before-lock', () => {
    clearFailpoints();
    rival = b.enqueue('x', 'rival', { key: 'only-one' });
  });
  const mine = a.enqueue('x', 'mine', { key: 'only-one' });
  assert.equal(rival.deduped, false);
  assert.equal(mine.deduped, true);
  assert.equal(mine.id, rival.id);
  assert.equal(a.stats().total, 1);
});

test('a process follows a compaction that made the log bigger than it was (G13)', (t) => {
  const { a, b } = pair(t);
  a.enqueue('x', 1);
  b.stats(); // b has read the log as it is now
  const oldSize = fs.statSync(path.join(b.dir, 'wal.log')).size;
  // The snapshot of one small job is larger than its single record.
  a.compact();
  const newSize = fs.statSync(path.join(b.dir, 'wal.log')).size;
  assert.ok(newSize >= oldSize, `precondition: ${newSize} should not be smaller than ${oldSize}`);
  assert.equal(b.stats().total, 1);
  assert.equal(b.enqueue('x', 2).id, 'j2');
  assert.equal(a.stats().total, 2);
});

test('every process follows a compaction by another, repeatedly (G13)', (t) => {
  const { a, b } = pair(t);
  for (let round = 0; round < 5; round += 1) {
    a.enqueue('x', round);
    a.compact();
    const job = b.claim('w');
    assert.ok(job, `round ${round}`);
    b.complete(job.id, job.token, round);
    b.compact();
  }
  assert.equal(a.stats().done, 5);
  assert.equal(a.stats().total, 5);
});

test('a temp file left by a dead compaction does not block the next one (G12)', (t) => {
  const { a, dir } = pair(t);
  a.enqueue('x', 1);
  fs.writeFileSync(path.join(dir, 'wal.log.compact'), 'left over from a crash');
  a.compact();
  assert.equal(a.stats().generation, 2);
  assert.equal(fs.existsSync(path.join(dir, 'wal.log.compact')), false);
});

test('a compaction that fails leaves no temp file and the next one succeeds (G12)', (t) => {
  const { a, dir } = pair(t);
  a.enqueue('x', 1);
  onFailpoint('compact.before-rename', () => {
    throw Object.assign(new Error('operation not permitted'), { code: 'EPERM' });
  });
  assert.throws(() => a.compact(), /EPERM|not permitted/);
  clearFailpoints();
  assert.equal(fs.existsSync(path.join(dir, 'wal.log.compact')), false);
  assert.equal(a.stats().total, 1);
  a.enqueue('x', 2);
  a.compact();
  assert.equal(a.stats().total, 2);
  assert.equal(a.stats().generation, 2);
});

test('automatic compaction stays cheap when the live state is bigger than the threshold (G14)', (t) => {
  const dir = tempDir(t);
  const queue = openQueue(dir, { clock: new ManualClock(0), compactAfterBytes: 4_000 });
  const filler = 'f'.repeat(500);
  // Live state of about 20 KB, five times the threshold.
  queue.enqueueMany(Array.from({ length: 40 }, (_, n) => ({ type: 'x', payload: { n, filler } })));
  assert.ok(queue.stats().logBytes > 4_000);
  const start = queue.stats().generation;
  for (let i = 0; i < 100; i += 1) queue.enqueue('x', { i });
  const compactions = queue.stats().generation - start;
  assert.ok(compactions <= 3, `${compactions} compactions for 100 small writes`);
  assert.equal(queue.stats().total, 140);
});

test('a failing automatic compaction is reported and is not retried on every write', (t) => {
  const dir = tempDir(t);
  const queue = openQueue(dir, { clock: new ManualClock(0), compactAfterBytes: 1_500 });
  t.after(clearFailpoints);
  let attempts = 0;
  onFailpoint('compact.before-rename', () => {
    attempts += 1;
    throw new Error('blocked');
  });
  for (let i = 0; i < 60; i += 1) queue.enqueue('x', { i, pad: 'p'.repeat(30) });
  assert.match(queue.stats().lastCompactionError, /blocked/);
  assert.ok(attempts < 20, `${attempts} attempts`);
  clearFailpoints();
  for (let i = 0; i < 60; i += 1) queue.enqueue('x', { i, pad: 'p'.repeat(30) });
  assert.equal(queue.stats().lastCompactionError, null);
  assert.equal(queue.stats().total, 120);
});

test('cancelled jobs are pruned like other finished jobs', (t) => {
  const clock = new ManualClock(0);
  const queue = openQueue(tempDir(t), { clock, retainCompletedMs: 1_000 });
  const { id } = queue.enqueue('x', 1);
  queue.cancel(id);
  clock.advance(1_000);
  queue.compact();
  assert.equal(queue.getJob(id), null);
});
