#!/usr/bin/env node
// Operator tool.
//
//   node src/cli.mjs inspect <dir>        print every record in the log
//   node src/cli.mjs stats <dir>          print job counts
//   node src/cli.mjs compact <dir>        compact now
//   node src/cli.mjs tail <dir>           follow the log, keeping it open
//   node src/cli.mjs metrics <dir>        print operational numbers
//   node src/cli.mjs requeue <dir> <id>   give a dead job a fresh set of attempts
//   node src/cli.mjs cancel <dir> <id>    stop a job that has not finished

import fs from 'node:fs';
import path from 'node:path';
import { decodeHeader, HEADER_SIZE, scanFrames } from './frame.mjs';
import { describeRecord, inspectLog } from './inspect.mjs';
import { openQueue } from './queue.mjs';
import { WAL_FILE } from './store.mjs';

function usage() {
  console.error('usage: cli.mjs <inspect|stats|compact|tail|metrics|requeue|cancel> <dir> [id]');
  process.exitCode = 2;
}

function inspect(dir) {
  const view = inspectLog(dir);
  console.log(`${view.file}: generation ${view.header.generation}, ${view.size} bytes`);
  for (const frame of view.frames) console.log(`${frame.offset}\t${describeRecord(frame.record)}`);
  if (view.tail) console.log(`${view.tail.offset}\tincomplete tail (${view.tail.reason}, ${view.tail.bytes} bytes)`);
}

function stats(dir) {
  const queue = openQueue(dir);
  console.log(JSON.stringify(queue.stats(), null, 2));
  queue.close();
}

function compact(dir) {
  const queue = openQueue(dir);
  console.log(JSON.stringify(queue.compact()));
  queue.close();
}

function metrics(dir) {
  const queue = openQueue(dir);
  console.log(JSON.stringify(queue.metrics(), null, 2));
  queue.close();
}

function requeue(dir, id) {
  const queue = openQueue(dir);
  console.log(JSON.stringify(queue.requeueDead(id)));
  queue.close();
}

function cancel(dir, id) {
  const queue = openQueue(dir);
  console.log(JSON.stringify(queue.cancel(id)));
  queue.close();
}

// Follows the log without keeping it open between polls: a handle held for as long
// as tail runs gets in the way of compaction, which has to replace the file. It
// follows a compaction into the new generation.
function tail(dir) {
  const file = path.join(dir, WAL_FILE);
  let generation = null;
  let offset = HEADER_SIZE;
  const timer = setInterval(() => {
    let bytes;
    try {
      const fd = fs.openSync(file, 'r');
      try {
        const head = Buffer.alloc(HEADER_SIZE);
        fs.readSync(fd, head, 0, HEADER_SIZE, 0);
        const header = decodeHeader(head, file);
        if (header.generation !== generation) {
          if (generation !== null) console.log(`-- log replaced, generation ${header.generation}`);
          generation = header.generation;
          offset = HEADER_SIZE;
        }
        const size = fs.fstatSync(fd).size;
        if (size < offset) offset = HEADER_SIZE;
        if (size <= offset) return;
        bytes = Buffer.alloc(size - offset);
        fs.readSync(fd, bytes, 0, bytes.length, offset);
      } finally {
        fs.closeSync(fd);
      }
    } catch (err) {
      // Between two polls the file can be mid-replacement; try again next time.
      if (err.code === 'ENOENT' || err.code === 'EBUSY' || err.code === 'EPERM') return;
      throw err;
    }
    const { frames, end } = scanFrames(bytes, offset, { strict: false });
    for (const frame of frames) console.log(describeRecord(frame.record));
    offset = end;
  }, 200);
  process.on('SIGINT', () => {
    clearInterval(timer);
  });
}

const [command, dir, id] = process.argv.slice(2);
const commands = { inspect, stats, compact, tail, metrics, requeue, cancel };
if (!commands[command] || !dir) usage();
else commands[command](dir, id);
