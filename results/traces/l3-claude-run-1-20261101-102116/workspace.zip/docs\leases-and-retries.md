# Leases and retries

## Leases

`claim()` gives a job to a worker until `leaseUntil`, and hands back a `token`. The token goes on every later call about that attempt. A lease has expired once the clock reaches its deadline.

A worker running a long job calls `heartbeat()`. `JobRunner` does this on a timer, every `leaseMs / 3` by default. Each heartbeat is a `heartbeat` record in the log, because the process that reaps expired leases is usually not the one holding them; a heartbeat kept only in the worker would let the reaper take a live worker's job. The worker keeps heartbeating until its outcome is recorded.

Anyone can call `reapExpired()`. It returns expired jobs to the queue with a backoff, or sends them to `dead` when attempts have run out. An expired lease counts as a used attempt.

When a pool sees one of its workers exit, it calls `reclaimWorker()` instead of waiting for the lease: the worker's jobs go back to `ready` at once, with a `release` record and no backoff, or to `dead` if attempts have run out. The attempt still counts.

Every decision to reap or reclaim is made under the queue lock from state that was just read, so a job that was committed or extended a moment earlier is never touched.

## Tokens

The token is the job's `fence`, which goes up by one with each claim. It never goes down, not even for `requeueDead()`, so a token is never issued twice for a job. A call with a token that isn't the current attempt's throws `StaleLeaseError`: that includes a job that is leased again to someone else.

## Backoff

After an attempt fails, the job is due again after:

```
delay = min(maxMs, baseMs * factor ^ (attempts - 1))
```

The due time is fixed when the failure is recorded (`at` + delay, in the record). Restarts and compactions do not move it. `attempts` and `fence` are kept in snapshots, so backoff keeps growing and `maxAttempts` holds across compactions.

With `jitter` above zero, the delay is reduced by up to that fraction. The reduction is derived from the job id and the attempt number, so that it's reproducible.

## Attempts

`attempts` counts claims. When an attempt ends in failure or expiry with `attempts >= maxAttempts`, the job goes `dead`. `requeueDead()` sets attempts back to zero and makes the job due now.

## Clocks

All processes are on one host and read the same system clock, so clock skew between processes isn't handled.
