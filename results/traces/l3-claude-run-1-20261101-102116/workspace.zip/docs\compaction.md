# Compaction

The log only grows, so from time to time it's replaced by a shorter one that says the same thing: a new header with the next generation, and one `snapshot` record.

## When

- `compact()` runs it on request.
- After any write, automatically, when the log has passed `compactAfterBytes` **and** has at least doubled since the last compaction (the snapshot is the log's starting size). Compacting costs about the size of the live state, so this keeps the cost per write small even when the live state alone is bigger than `compactAfterBytes`.

A failed automatic compaction doesn't fail the call that triggered it, because that call has already committed. `stats().lastCompactionError` shows the last failure. After a failure the next automatic attempt waits until the log has grown by half of `compactAfterBytes`, rather than retrying on every write.

## How

Compaction runs under the queue lock, after catching up, so the state it writes is complete.

1. Build the snapshot from the current state, dropping finished jobs past `retainCompletedMs`.
2. Remove any `wal.log.compact` that is already there (the lock holder is the only compactor, so it is left from an attempt that died), then write the header and snapshot to a new one.
3. Sync `wal.log.compact`. The bytes must be durable before the name is, or a power cut after the rename leaves an empty log.
4. Rename it over `wal.log`, and sync the directory.
5. Rebuild this process's state from the snapshot.

If any step fails, `wal.log.compact` is removed and the old log is untouched. On Windows the rename fails with `EPERM` or `EBUSY` while another program (a backup, a scanner) has the log open without sharing delete; the compaction then fails, is reported, and works the next time the file is free.

## What the snapshot holds

The jobs that are kept with every field (attempts, fence, priority and the rest), the counters the log needs to carry on (`seq`, `completionSeq`), and the idempotency keys still inside their time to live, which outlive the jobs they point at. See [guarantees.md](guarantees.md), G10 and G11. `done`, `dead` and `cancelled` jobs are dropped once past `retainCompletedMs`.

## Other processes

A process that was reading the old log finds a different file next time it catches up, and has to start again from the new one. It notices by the generation in the header, not by the file's size, because the new log can be bigger than the part of the old one that process had read.
