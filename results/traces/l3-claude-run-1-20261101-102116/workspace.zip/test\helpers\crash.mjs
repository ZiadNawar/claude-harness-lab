// Helpers for tests that kill a process at a failpoint and look at what is left.

import { spawnSync } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { tempDir } from './tmp.mjs';

const CHILD = fileURLToPath(new URL('./crash-child.mjs', import.meta.url));

/**
 * Runs `action` in a child process with `failpoints` armed and the power-loss model
 * on. Returns whether the failpoint fired (the marker file appeared).
 */
export function crashAt(t, dir, action, failpoints, { arg, options, powerLoss = true } = {}) {
  const markers = tempDir(t);
  const result = spawnSync(process.execPath, [CHILD, dir, action, String(arg ?? '')], {
    env: {
      ...process.env,
      WALQ_FAILPOINTS: failpoints,
      WALQ_FAILPOINT_DIR: markers,
      ...(powerLoss ? { WALQ_SIMULATE_POWER_LOSS: '1' } : {}),
      ...(options ? { WALQ_TEST_OPTIONS: JSON.stringify(options) } : {}),
    },
    encoding: 'utf8',
  });
  const name = failpoints.split(',')[0].split('=')[0].replace('#', '.');
  return { fired: fs.existsSync(path.join(markers, `${name}.hit`)), stderr: result.stderr, status: result.status };
}

/** Runs an action to the end with nothing armed. */
export function runChild(dir, action, { arg, options, powerLoss = true } = {}) {
  const result = spawnSync(process.execPath, [CHILD, dir, action, String(arg ?? '')], {
    env: {
      ...process.env,
      ...(powerLoss ? { WALQ_SIMULATE_POWER_LOSS: '1' } : {}),
      ...(options ? { WALQ_TEST_OPTIONS: JSON.stringify(options) } : {}),
    },
    encoding: 'utf8',
  });
  if (result.status !== 0) throw new Error(`child ${action} failed: ${result.stderr}`);
}
