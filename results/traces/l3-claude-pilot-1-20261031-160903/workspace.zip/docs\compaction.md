# Compaction

The log only grows, so from time to time it's replaced by a shorter one that says the same thing: a new header with the next generation, and one `snapshot` record.

## When

- `compact()` runs it on request.
- After any write, automatically, when the log has passed `compactAfterBytes`.

Automatic compaction waits until the log is at least twice the size of the snapshot it started from, as well as past `compactAfterBytes`. When the live state is itself larger than `compactAfterBytes`, that keeps the rewriting to a constant amount of work per byte written, instead of one rewrite per write.

A failed automatic compaction doesn't fail the call that triggered it, because that call has already committed. `stats().lastCompactionError` shows the last failure.

## How

Compaction runs under the queue lock, after catching up, so the state it writes is complete.

1. Build the snapshot from the current state, dropping finished jobs past `retainCompletedMs`, and idempotency keys past their time to live.
2. Remove any `wal.log.compact` left by an earlier compaction that died, then write the header and snapshot to a new one.
3. Sync it. It must be durable before it has the log's name, or a power cut can leave an empty log.
4. Rename it over `wal.log`.
5. Sync the log and its folder, and rebuild this process's state from the snapshot.

If any step fails, `wal.log` is untouched, the temp file is removed, and the next compaction starts clean. Windows will not replace a file that another program holds open: the compaction fails with `EPERM` and succeeds once the file is free. walq's own tools open the log only for the moment they read it.

## What the snapshot holds

The jobs that are kept, and the counters the log needs to carry on. See [guarantees.md](guarantees.md), G10 and G11.

## Other processes

A process that was reading the old log finds a different file next time it catches up, and has to start again from the new one. It recognises the new file by the generation in its header, not by its size, which can be larger or smaller than the old log.
