# API

Everything is exported from `src/index.mjs`. The names and shapes on this page are a contract with the services that use walq.

## openQueue(dir, options)

| Option | Default | Meaning |
|---|---|---|
| `leaseMs` | 30 000 | Default lease length |
| `lockTimeoutMs` | 10 000 | How long a call waits for the lock before `LockTimeoutError` |
| `compactAfterBytes` | 4 MiB | Compact automatically past this size. `0` turns it off |
| `retainCompletedMs` | 24 h | How long finished jobs stay in the log after they finish |
| `idempotencyTtlMs` | 7 d | How long a key is remembered, from when the job was enqueued |
| `maxAttempts` | 5 | Default attempts per job |
| `backoff` | `{ baseMs: 1000, factor: 2, maxMs: 60000, jitter: 0 }` | Retry schedule |
| `clock` | system clock | Anything with `now()`. Tests use `ManualClock` |

## Queue

**`enqueue(type, payload, { key, delayMs, maxAttempts, priority })`** returns `{ id, status, deduped }`. With a remembered `key` it also returns the existing job's `result` and `deduped: true`, and creates nothing.

**`enqueueMany([{ type, payload, options }])`** adds a batch under one lock and one sync. A crash can leave a prefix of the batch behind.

**`claim(worker, { leaseMs, types })`** returns `{ id, type, payload, attempt, token, leaseUntil }` or `null`. Among due jobs, higher `priority` goes first, then the job due longest, then the oldest. `token` identifies this attempt.

**`heartbeat(id, token, { leaseMs })`** returns `{ leaseUntil }`. Throws `StaleLeaseError` if the lease is no longer yours. The new deadline is written to the log, so every process, including whichever one runs the reaper, sees it.

**`complete(id, token, result)`** commits the result and returns a receipt `{ id, outcome, token, result, completedAt, completionSeq }`. `outcome` is `'committed'` the first time. A repeat with the token that committed, even after a restart or a compaction, returns the stored receipt with `outcome: 'already-committed'` and writes nothing. Any other token throws `StaleLeaseError`; a pruned job throws `UnknownJobError`. A lease past its deadline can still commit until a reaper, a reclaim, a cancel or a new claim has acted on it. See [rfc-007-exactly-once-completion.md](rfc-007-exactly-once-completion.md).

**`fail(id, token, error)`** returns `{ id, status, retryAt }`. The job goes back to `ready` with a backoff, or to `dead` when attempts run out.

**`reapExpired()`** returns jobs whose lease had run out to the queue, and returns `[{ id, status, retryAt }]`.

**`reclaimWorker(workerId, { reason })`** gives up every lease held by a worker that is known to be dead, at once, and returns `[{ id, status }]`. Jobs come back `ready` with no backoff, or `dead` if their attempts have run out; the attempt counts and `reason` becomes `lastError`. Jobs the worker already committed are not touched.

**`getResult(id)`** returns `{ id, status: 'done', result, token, attempts, completedAt, completionSeq }` for a finished job, `{ id, status }` for any other job, and `null` for a job that is not known (never existed, or pruned). **`completions({ after = 0, limit })`** returns the retained commits in commit order, `[{ seq, id, token, result, completedAt }]`, with `seq > after`. Numbers start at 1 and carry on across restarts and compaction.

**`cancel(id, { reason })`** stops a job that is `ready` or `leased`. Returns `{ id, status, changed }`. A worker holding the job loses its lease.

**`requeueDead(id)`** gives a dead job a new set of attempts, runnable now. Returns `{ id, status }`. Throws `InvalidTransitionError` if the job is not dead.

**`getJob(id)`** returns a copy of the job or `null`. **`listJobs()`** returns copies of all jobs in the log. **`stats()`** returns counts by status, plus `total`, `generation`, `logBytes`, `tornTailsDropped` and `lastCompactionError`. **`metrics()`** is described in [operations.md](operations.md).

**`compact()`** rewrites the log now and returns `{ generation, bytesBefore, bytesAfter, jobs }`. If it throws, the queue is still usable and nothing is lost.

**`close()`** marks this instance closed.

## Job fields

`id`, `type`, `payload`, `key`, `priority`, `status` (`ready`, `leased`, `done`, `dead`, `cancelled`), `attempts`, `fence` (the current token; it only goes up and is never reused for a job), `maxAttempts`, `availableAt`, `lease` (`{ worker, fence, until }` or null), `result`, `lastError`, `enqueuedAt`, `completedAt`, `completionSeq`, `seq`.

## WorkerPool

```js
new WorkerPool({ dir, handlers, size, leaseMs, heartbeatMs, pollMs, reapMs, types, env, queue, maxRespawns })
```

`handlers` is the path of a handlers module. `queue` is the options object for `openQueue` in the workers and the pool, so it must be JSON-serialisable. `env` adds environment variables for the workers. `types` limits which job types the pool's workers take.

- `start()` starts the workers. Worker ids are unique to the pool (`<pool>-w<n>`), so pools sharing a queue directory never touch each other's jobs.
- `drain({ timeoutMs })` resolves when no job is `ready` or `leased`, and rejects when that takes too long.
- `stop()` stops the workers and waits for them to go.

When a worker exits, the pool calls `reclaimWorker()` for it straight away, so its jobs do not wait for their leases, and then starts a replacement. A worker that has run a handler keeps trying to record the outcome until it is recorded or the job turns out to belong to someone else (`job-fenced`), and takes no other job meanwhile.

The pool is an `EventEmitter`. `message` carries worker events (`kind` is one of `ready`, `job-started`, `job-completed`, `job-failed`, `job-fenced`, `worker-error`), `exit` fires when a worker exits, and `stderr` and `error-event` report problems.

## Errors

`WalqError` is the base class. `CorruptLogError` has an `offset`. Also `StaleLeaseError`, `UnknownJobError`, `LockTimeoutError`, `InvalidTransitionError`, `ConfigError`, `QueueClosedError`.

## Other exports

`computeBackoff(attempts, policy, salt)`, `ManualClock`, `SystemClock`, `JobRunner`, `inspectLog(dir)`, `describeRecord(record)`, `onFailpoint`, `clearFailpoints`, `hit`.
