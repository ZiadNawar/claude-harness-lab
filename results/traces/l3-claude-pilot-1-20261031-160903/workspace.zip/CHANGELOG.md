# Changelog

## 0.5.0

Crash and concurrency fixes, and RFC 007.

- Recovery: an incomplete tail is cut off before the next write, so a crash during an append no longer makes a later start fail. The header of a new log and the temp file of a compaction are synced before they take their names.
- Records and logs of any size up to the format limit work. A catch-up reads the whole log, not its first megabyte.
- Claims, the reaper and idempotency keys decide under the lock. Tokens are checked, and never reused.
- Heartbeats and completions are written and synced, so a live worker keeps its job and a completion survives a power cut.
- Retry due times, attempts, fences, priorities and idempotency keys survive restarts and compaction.
- Compaction clears a stale temp file, tells processes apart by generation, and rewrites in proportion to what is written. `walq tail` no longer holds the log open.
- RFC 007: `complete()` returns a receipt; `getResult()`, `completions()` and `reclaimWorker()`; the `release` record; pools reclaim a worker that exits; workers keep trying to record a finished job.

## 0.4.2

- Throughput work for busy queues: less log growth and fewer syncs in the common paths.
- Lower memory use when a process catches up.

## 0.4.1

- `cancel()` and `requeueDead()`.
- Job priorities.
- `metrics()` and the `metrics` command.

## 0.4.0

- Smaller snapshots.
- Worker pools replace dead workers automatically.
- Failpoints for crash testing.

## 0.3.0

- Idempotency keys.
- Automatic compaction past `compactAfterBytes`.

## 0.2.0

- Multi-process access through a shared lock. Workers became child processes.

## 0.1.0

- First version: one process, one log.
