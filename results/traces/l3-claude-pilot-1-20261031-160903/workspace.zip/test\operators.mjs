// Operators' tools run next to a live queue (docs/guarantees.md, G12). On Windows an
// open handle stops a file from being replaced, so a tool that keeps the log open
// would make every compaction fail for as long as it runs.

import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { test } from 'node:test';
import { fileURLToPath } from 'node:url';
import { openQueue } from '../src/index.mjs';
import { defer, tempDir, waitUntil } from './helpers/tmp.mjs';

const CLI = fileURLToPath(new URL('../src/cli.mjs', import.meta.url));

function startTail(t, dir) {
  const child = spawn(process.execPath, [CLI, 'tail', dir], { stdio: ['ignore', 'pipe', 'pipe'] });
  const lines = [];
  let pending = '';
  child.stdout.on('data', (chunk) => {
    pending += chunk;
    const parts = pending.split('\n');
    pending = parts.pop();
    lines.push(...parts.map((l) => l.trim()).filter(Boolean));
  });
  child.stderr.resume();
  defer(t, () => child.kill());
  return { child, lines };
}

test('a running `walq tail` does not stop compaction, and keeps following across it', async (t) => {
  const dir = tempDir(t);
  const queue = openQueue(dir, { compactAfterBytes: 0 });
  queue.enqueue('x', 'first');
  const { lines } = startTail(t, dir);
  await waitUntil(() => lines.some((l) => l.startsWith('enqueue j1')));

  for (let round = 0; round < 6; round += 1) {
    queue.enqueue('x', round);
    queue.compact();
    await new Promise((resolve) => setTimeout(resolve, 250));
  }
  queue.enqueue('x', 'last');
  assert.equal(queue.stats().generation, 7);
  await waitUntil(() => lines.some((l) => l.startsWith('enqueue j8')), { timeoutMs: 5_000 });
});
