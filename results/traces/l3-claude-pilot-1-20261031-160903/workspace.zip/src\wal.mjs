// The log file itself: a header, then checksummed frames, written only by the
// process holding the queue lock.

import path from 'node:path';
import { decodeHeader, encodeFrame, encodeHeader, HEADER_SIZE, scanFrames } from './frame.mjs';
import { hit, isArmed } from './failpoints.mjs';

// How much of the log is decoded at a time, so that a process far behind does not
// hold the whole file in memory. A frame larger than this is read whole.
const SCAN_CHUNK = 1024 * 1024;

export class Wal {
  constructor(file, ops) {
    this.file = file;
    this.ops = ops;
  }

  exists() {
    return this.ops.exists(this.file);
  }

  /** Creates an empty log. The header appears atomically or not at all. */
  create(generation = 1) {
    const staging = `${this.file}.init`;
    this.ops.create(staging);
    this.ops.writeAt(staging, encodeHeader(generation), 0);
    // The header must be durable before the file has its real name, or a power
    // cut can leave a log that exists and is empty.
    this.ops.sync(staging);
    this.ops.rename(staging, this.file);
    hit('wal.after-create', {});
    this.ops.sync(this.file);
    this.ops.syncDir(path.dirname(this.file));
  }

  readHeader() {
    return decodeHeader(this.ops.read(this.file, 0, HEADER_SIZE), this.file);
  }

  /**
   * Decodes everything from `offset` to the end of the file, a chunk at a time.
   * `visit(frames)` gets each batch in order, so the caller need not hold them all.
   * Returns where the good frames end and the incomplete `tail`, if any.
   */
  scanFrom(offset, visit) {
    let pos = offset;
    let want = SCAN_CHUNK;
    for (;;) {
      const bytes = this.ops.read(this.file, pos, want);
      const { frames, end, tail } = scanFrames(bytes, pos);
      if (frames.length) visit(frames);
      pos = end;
      // Fewer bytes than asked for means the end of the file was in this read.
      const reachedEnd = bytes.length < want;
      if (reachedEnd) return { end, tail };
      // One byte more than the tail needs, so that reaching the end shows as a short read.
      want = tail ? Math.max(SCAN_CHUNK, tail.needed + 1) : SCAN_CHUNK;
    }
  }

  truncate(length) {
    this.ops.truncate(this.file, length);
  }

  /** Writes records at `at`, which must be the end of the good log. Returns the new end offset. */
  append(records, at, { sync = true } = {}) {
    const type = records[0]?.t;
    const bytes = Buffer.concat(records.map(encodeFrame));
    hit('wal.before-append', { type });
    if (isArmed('wal.mid-append')) {
      const half = bytes.length >> 1;
      this.ops.writeAt(this.file, bytes.subarray(0, half), at);
      hit('wal.mid-append', { type });
      this.ops.writeAt(this.file, bytes.subarray(half), at + half);
    } else {
      this.ops.writeAt(this.file, bytes, at);
    }
    hit('wal.after-write', { type });
    if (sync) this.ops.sync(this.file);
    hit('wal.after-fsync', { type });
    return at + bytes.length;
  }
}
