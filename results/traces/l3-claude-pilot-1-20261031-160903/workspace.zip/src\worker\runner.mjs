// JobRunner: the loop a worker process runs. Claim a job, run its handler with a
// heartbeat going, then record the outcome.

import { sleep } from '../clock.mjs';
import { StaleLeaseError, UnknownJobError, WalqError } from '../errors.mjs';
import { hit } from '../failpoints.mjs';
import { JOB_COMPLETED, JOB_FAILED, JOB_FENCED, JOB_STARTED, WORKER_ERROR } from './protocol.mjs';
import { runWithTimeout } from './registry.mjs';

// Errors that come from the outcome itself rather than from the state of the queue
// or the disk: repeating the call cannot change them.
function isPermanent(err) {
  return err instanceof TypeError || err instanceof RangeError || err?.permanent === true;
}

export class JobRunner {
  constructor({ queue, workerId, handlers, leaseMs, heartbeatMs, pollMs = 20, types = null, emit = () => {} }) {
    this.queue = queue;
    this.workerId = workerId;
    this.handlers = handlers;
    this.leaseMs = leaseMs ?? queue.config.leaseMs;
    this.heartbeatMs = heartbeatMs ?? Math.max(10, Math.floor(this.leaseMs / 3));
    this.pollMs = pollMs;
    this.types = types;
    this.emit = emit;
    this.stopping = false;
  }

  stop() {
    this.stopping = true;
  }

  async run() {
    while (!this.stopping) {
      const job = this.#claimNext();
      if (job) await this.execute(job);
      else await sleep(this.pollMs);
    }
  }

  #claimNext() {
    try {
      return this.queue.claim(this.workerId, { leaseMs: this.leaseMs, types: this.types });
    } catch (err) {
      if (!(err instanceof WalqError)) throw err;
      this.emit({ kind: WORKER_ERROR, error: err.message });
      return null;
    }
  }

  async execute(job) {
    const { id, token } = job;
    hit('job.before-handler', { id });
    this.emit({ kind: JOB_STARTED, id, attempt: job.attempt, token });

    const abort = new AbortController();
    let fenced = false;
    // The heartbeat runs until the outcome is recorded. A lease that lapses while
    // the queue is busy would let a finished job be taken from its worker.
    const beat = setInterval(() => {
      try {
        this.queue.heartbeat(id, token, { leaseMs: this.leaseMs });
      } catch (err) {
        if (err instanceof StaleLeaseError || err instanceof UnknownJobError) {
          fenced = true;
          clearInterval(beat);
          abort.abort();
        } else {
          this.emit({ kind: WORKER_ERROR, error: err.message });
        }
      }
    }, this.heartbeatMs);

    try {
      let result;
      let failure = null;
      try {
        const handler = this.handlers.get(job.type);
        if (!handler) throw new Error(`no handler for job type ${job.type}`);
        result = await runWithTimeout(
          handler,
          job.payload,
          { id, attempt: job.attempt, token, workerId: this.workerId, signal: abort.signal },
          abort,
        );
      } catch (err) {
        failure = err;
      }

      if (fenced) {
        // The job belongs to someone else now. Whatever this attempt produced is discarded.
        this.emit({ kind: JOB_FENCED, id });
        return;
      }

      if (!failure) {
        hit('job.after-handler', { id });
        const done = await this.#record(() => this.queue.complete(id, token, result));
        if (done.fenced || !done.rejected) {
          this.emit(done.fenced ? { kind: JOB_FENCED, id } : { kind: JOB_COMPLETED, id, outcome: done.value.outcome });
          hit('job.after-complete', { id });
          return;
        }
        // The result itself cannot be recorded (it does not serialise, or it is too
        // large), so this attempt counts as a failure.
        failure = done.rejected;
      }

      const failed = await this.#record(() => this.queue.fail(id, token, failure));
      this.emit({ kind: failed.fenced ? JOB_FENCED : JOB_FAILED, id, error: failure?.message });
    } finally {
      clearInterval(beat);
    }
  }

  /**
   * Records an outcome and does not give up. The handler has already run, so its
   * outcome is worth more than anything else this worker could be doing. When the
   * queue is busy or the disk fails, wait and try again until the outcome is
   * recorded or the job turns out to belong to someone else. Repeating is safe: a
   * call that did reach the log answers a second time with the same outcome.
   */
  async #record(call) {
    let wait = 10;
    for (;;) {
      try {
        return { value: call() };
      } catch (err) {
        // A fenced worker has lost the job. That is an expected end for this
        // attempt, not an error.
        if (err instanceof StaleLeaseError || err instanceof UnknownJobError) return { fenced: true };
        if (isPermanent(err)) return { rejected: err };
        this.emit({ kind: WORKER_ERROR, error: err.message });
      }
      await sleep(wait);
      wait = Math.min(wait * 2, 1_000);
    }
  }
}
