// Properties from docs/guarantees.md that only show up with several processes on
// one log, across restarts, or across compaction. Two Queue instances on one folder
// behave as two processes: each has its own state and takes the same lock.

import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { test } from 'node:test';
import { clearFailpoints, ManualClock, onFailpoint, openQueue, StaleLeaseError } from '../src/index.mjs';
import { encodeFrame } from '../src/frame.mjs';
import { tempDir } from './helpers/tmp.mjs';

const BACKOFF = { baseMs: 1_000, factor: 2, maxMs: 60_000 };

function pair(t, options = {}) {
  const clock = new ManualClock(1_000_000);
  const dir = tempDir(t);
  const settings = { clock, backoff: BACKOFF, ...options };
  t.after(clearFailpoints);
  return { clock, dir, a: openQueue(dir, settings), b: openQueue(dir, settings), settings };
}

/** Runs `action` once, the first time `name` is reached. */
function once(name, action) {
  let fired = false;
  onFailpoint(name, () => {
    if (fired) return;
    fired = true;
    action();
  });
}

test('G6: two workers racing for one job cannot both get it', (t) => {
  const { a, b } = pair(t);
  a.enqueue('x', 1);
  let theirs;
  once('claim.before-lock', () => {
    theirs = b.claim('b');
  });
  const mine = a.claim('a');
  assert.ok(theirs, 'the other process took it');
  assert.equal(mine, null, 'this one must notice and take nothing');
});

test('G6: racing claims on two jobs get different jobs and tokens', (t) => {
  const { a, b } = pair(t);
  a.enqueue('x', 1);
  a.enqueue('x', 2);
  let theirs;
  once('claim.before-lock', () => {
    theirs = b.claim('b');
  });
  const mine = a.claim('a');
  assert.notEqual(mine.id, theirs.id);
});

test('G6: a token is never issued twice for a job, even across requeue and compaction', (t) => {
  const { clock, a } = pair(t, { maxAttempts: 1 });
  const { id } = a.enqueue('x', 1);
  const tokens = [];
  for (let round = 0; round < 4; round += 1) {
    const job = a.claim('w');
    tokens.push(job.token);
    a.fail(job.id, job.token, 'no');
    assert.equal(a.getJob(id).status, 'dead');
    if (round % 2) a.compact();
    a.requeueDead(id);
    clock.advance(1);
  }
  assert.equal(new Set(tokens).size, tokens.length, `tokens ${tokens}`);
});

test('G8: an old token cannot touch the job', (t) => {
  const { clock, a } = pair(t);
  const { id } = a.enqueue('x', 1);
  const first = a.claim('w1');
  a.fail(first.id, first.token, 'no');
  clock.advance(5_000);
  const second = a.claim('w2');
  assert.equal(second.id, id);
  assert.throws(() => a.heartbeat(id, first.token), StaleLeaseError);
  assert.throws(() => a.complete(id, first.token, 'late'), StaleLeaseError);
  assert.throws(() => a.fail(id, first.token, 'late'), StaleLeaseError);
  assert.equal(a.getJob(id).status, 'leased');
  a.complete(id, second.token, 'fine');
});

test('G7: a heartbeat is seen by the process that runs the reaper', (t) => {
  const { clock, a, b } = pair(t);
  a.enqueue('x', 1);
  const job = a.claim('w', { leaseMs: 500 });
  clock.advance(400);
  a.heartbeat(job.id, job.token, { leaseMs: 500 });
  clock.advance(400);
  assert.deepEqual(b.reapExpired(), []);
  assert.equal(b.getJob(job.id).status, 'leased');
});

test('G7: a reaper that waited for the lock does not reap a lease renewed meanwhile', (t) => {
  const { clock, a, b } = pair(t);
  a.enqueue('x', 1);
  const job = a.claim('w', { leaseMs: 500 });
  clock.advance(500);
  once('reap.before-lock', () => a.heartbeat(job.id, job.token, { leaseMs: 500 }));
  assert.deepEqual(b.reapExpired(), []);
  assert.equal(a.getJob(job.id).status, 'leased');
});

test('G10: a key racing between two processes creates one job', (t) => {
  const { a, b } = pair(t);
  let theirs;
  once('enqueue.before-lock', () => {
    theirs = b.enqueue('x', 'b', { key: 'same' });
  });
  const mine = a.enqueue('x', 'a', { key: 'same' });
  assert.equal(theirs.deduped, false);
  assert.equal(mine.deduped, true);
  assert.equal(mine.id, theirs.id);
  assert.equal(a.stats().total, 1);
});

test('G10: a key is remembered after its job has been pruned and the log compacted', (t) => {
  const day = 24 * 60 * 60 * 1000;
  const { clock, dir, a, settings } = pair(t);
  const first = a.enqueue('report', 1, { key: 'report-2026-09' });
  const job = a.claim('w');
  a.complete(job.id, job.token, { sent: true });

  clock.advance(3 * day);
  a.compact();
  assert.equal(a.getJob(first.id), null, 'the job itself is gone');

  for (const queue of [a, openQueue(dir, settings)]) {
    const again = queue.enqueue('report', 2, { key: 'report-2026-09' });
    assert.equal(again.deduped, true);
    assert.equal(again.id, first.id);
    assert.equal(again.status, 'done');
    assert.deepEqual(again.result, { sent: true });
  }
  a.compact();
  a.compact();
  assert.equal(a.enqueue('report', 3, { key: 'report-2026-09' }).deduped, true);

  clock.advance(5 * day);
  assert.equal(a.enqueue('report', 4, { key: 'report-2026-09' }).deduped, false, 'past its time to live');
});

test('G9: a retry keeps its due time across a restart', (t) => {
  const { clock, dir, a, settings } = pair(t);
  const { id } = a.enqueue('x', 1);
  const job = a.claim('w');
  const { retryAt } = a.fail(job.id, job.token, 'no');
  assert.equal(retryAt, clock.now() + 1_000);
  a.close();

  clock.advance(500_000);
  const reopened = openQueue(dir, settings);
  assert.equal(reopened.getJob(id).availableAt, retryAt);
  assert.equal(reopened.claim('w').id, id, 'long overdue, so due now');
  reopened.close();

  // Reopened while the retry is still in the future, it is still not due.
  clock.set(retryAt - 1);
  const early = openQueue(dir, settings);
  assert.equal(early.getJob(id).availableAt, retryAt);
});

test('G9: every process sees the same due time', (t) => {
  const { clock, a, b } = pair(t);
  const { id } = a.enqueue('x', 1);
  const job = a.claim('w');
  a.fail(job.id, job.token, 'no');
  clock.advance(300);
  assert.equal(a.getJob(id).availableAt, b.getJob(id).availableAt);
  assert.equal(b.claim('b'), null);
});

test('G9: attempts and backoff carry through compaction, so maxAttempts holds', (t) => {
  const { clock, a } = pair(t, { maxAttempts: 4 });
  const { id } = a.enqueue('x', 1);
  const delays = [];
  for (let attempt = 1; attempt <= 4; attempt += 1) {
    clock.advance(100_000);
    const job = a.claim('w');
    assert.equal(job.attempt, attempt);
    const outcome = a.fail(job.id, job.token, 'no');
    if (outcome.status === 'ready') delays.push(outcome.retryAt - clock.now());
    a.compact();
  }
  assert.equal(a.getJob(id).status, 'dead');
  assert.deepEqual(delays, [1_000, 2_000, 4_000]);
});

test('G11: compaction changes no job field', (t) => {
  const { clock, a } = pair(t);
  a.enqueue('x', { n: 1 }, { priority: 5, maxAttempts: 7, key: 'k1' });
  a.enqueue('x', { n: 2 });
  const leased = a.claim('w', { leaseMs: 90_000 });
  const retried = a.claim('w');
  a.fail(retried.id, retried.token, 'oops');
  const done = a.enqueue('x', 3);
  const finished = a.claim('w2');
  assert.equal(finished.id, done.id);
  a.complete(finished.id, finished.token, 'r');
  a.enqueue('x', 4, { delayMs: 5_000 });
  a.cancel(a.enqueue('x', 5).id);
  clock.advance(10);

  const before = a.listJobs();
  assert.equal(leased.attempt, 1);
  a.compact();
  assert.deepEqual(a.listJobs(), before);
  a.close();
  assert.deepEqual(openQueue(a.dir, { clock, backoff: BACKOFF }).listJobs(), before);
});

test('G13: a process whose offset lies inside a larger new log follows the compaction', (t) => {
  const { a, b } = pair(t);
  for (let i = 0; i < 3; i += 1) a.enqueue('x', i);
  b.stats();
  const behind = b.store.offset;
  a.compact();
  assert.ok(a.store.offset > behind, 'the new log must be longer than where the other process stopped');
  assert.equal(b.stats().total, 3);
  assert.equal(b.enqueue('x', 'next').id, 'j4');
  assert.equal(a.stats().total, 4);
});

test('G13: a process far ahead of a smaller new log follows it too', (t) => {
  const { a, b } = pair(t, { compactAfterBytes: 0 });
  for (let i = 0; i < 50; i += 1) {
    const { id } = a.enqueue('x', i);
    const job = a.claim('w');
    a.complete(job.id, job.token, id);
  }
  b.stats();
  a.compact();
  assert.equal(b.stats().done, 50);
  a.enqueue('x', 'after');
  assert.equal(b.stats().ready, 1);
});

test('G5: a record far larger than one read chunk', (t) => {
  const { dir, a, b, settings } = pair(t, { compactAfterBytes: 0 });
  const big = 'x'.repeat(5 * 1024 * 1024);
  const { id } = a.enqueue('x', { big });
  a.enqueue('x', 'small after it');
  assert.equal(b.getJob(id).payload.big.length, big.length, 'another process catches up over it');
  a.close();
  const reopened = openQueue(dir, settings);
  assert.equal(reopened.stats().total, 2);
  assert.equal(reopened.stats().tornTailsDropped, 0);
  reopened.compact();
  assert.equal(reopened.getJob(id).payload.big.length, big.length);
});

test('G5: a record over the format limit is refused and harms nothing', (t) => {
  const { a } = pair(t, { compactAfterBytes: 0 });
  a.enqueue('x', 'before');
  const size = fs.statSync(path.join(a.dir, 'wal.log')).size;
  assert.throws(() => a.enqueue('x', 'y'.repeat(65 * 1024 * 1024)), /limit/);
  assert.equal(fs.statSync(path.join(a.dir, 'wal.log')).size, size);
  a.enqueue('x', 'after');
  assert.equal(a.stats().total, 2);
});

test('G5: a log of many megabytes reopens whole, and ids are not reused', (t) => {
  const { dir, a, settings } = pair(t, { compactAfterBytes: 0 });
  const total = 6_000;
  const items = Array.from({ length: total }, (_, n) => ({ type: 'x', payload: { n, pad: 'p'.repeat(300) } }));
  for (let at = 0; at < total; at += 500) a.enqueueMany(items.slice(at, at + 500));
  assert.ok(fs.statSync(path.join(dir, 'wal.log')).size > 2 * 1024 * 1024);
  a.close();
  const reopened = openQueue(dir, settings);
  assert.equal(reopened.stats().total, total);
  assert.equal(reopened.enqueue('x', 'one more').id, `j${total + 1}`);
  assert.equal(reopened.stats().total, total + 1);
});

test('G14: when the live state is larger than the threshold, writes do not each compact', (t) => {
  const { a } = pair(t, { compactAfterBytes: 2_000 });
  for (let i = 0; i < 60; i += 1) a.enqueue('x', { i, pad: 'p'.repeat(100) });
  const generation = a.stats().generation;
  for (let i = 0; i < 40; i += 1) a.enqueue('x', 'y');
  assert.ok(a.stats().generation - generation <= 3, `generation went from ${generation} to ${a.stats().generation}`);
  assert.equal(a.stats().total, 100);
});

test('G3: an incomplete tail is cut off before the next write goes after it', (t) => {
  const { dir, a, settings } = pair(t);
  a.enqueue('x', 1);
  a.close();
  const log = path.join(dir, 'wal.log');
  // The first half of a frame, as a cut-off write leaves it.
  const cut = encodeFrame({ t: 'enqueue', id: 'j2', type: 'x', payload: 'q'.repeat(60), maxAttempts: 5, availableAt: 0, at: 0 });
  fs.appendFileSync(log, cut.subarray(0, cut.length >> 1));
  const queue = openQueue(dir, settings);
  assert.equal(queue.stats().tornTailsDropped, 1);
  queue.enqueue('x', 2);
  queue.close();
  const again = openQueue(dir, settings);
  assert.equal(again.stats().total, 2);
  assert.equal(again.stats().tornTailsDropped, 0);
});
