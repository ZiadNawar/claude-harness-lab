// RFC 007: exactly-once completion.

import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { test } from 'node:test';
import { fileURLToPath } from 'node:url';
import {
  inspectLog,
  JobRunner,
  LockTimeoutError,
  ManualClock,
  openQueue,
  StaleLeaseError,
  UnknownJobError,
  WorkerPool,
} from '../src/index.mjs';
import { encodeFrame } from '../src/frame.mjs';
import { normaliseHandlers } from '../src/worker/registry.mjs';
import { defer, readLedger, tempDir, waitUntil } from './helpers/tmp.mjs';

const HANDLERS = fileURLToPath(new URL('./helpers/handlers.mjs', import.meta.url));

function setup(t, options = {}) {
  const clock = new ManualClock(1_000_000);
  const dir = tempDir(t);
  const settings = { clock, backoff: { baseMs: 100, factor: 2, maxMs: 1_000 }, ...options };
  return { clock, dir, settings, queue: openQueue(dir, settings) };
}

const records = (dir) => inspectLog(dir).frames.map((f) => f.record);

test('complete returns a receipt, and a repeat returns the same one without writing', (t) => {
  const { queue, dir, settings } = setup(t);
  const { id } = queue.enqueue('x', 1);
  const job = queue.claim('w');
  const first = queue.complete(job.id, job.token, { ok: 1 });
  assert.equal(first.outcome, 'committed');
  assert.deepEqual(Object.keys(first).sort(), ['completedAt', 'completionSeq', 'id', 'outcome', 'result', 'token']);
  assert.equal(first.completionSeq, 1);
  assert.equal(first.token, job.token);
  assert.deepEqual(first.result, { ok: 1 });

  const size = fs.statSync(path.join(dir, 'wal.log')).size;
  const again = queue.complete(id, job.token, { ok: 'ignored' });
  assert.equal(again.outcome, 'already-committed');
  assert.deepEqual({ ...again, outcome: 'committed' }, first);
  assert.equal(fs.statSync(path.join(dir, 'wal.log')).size, size);

  queue.compact();
  queue.close();
  const reopened = openQueue(dir, settings);
  assert.deepEqual(reopened.complete(id, job.token, 'ignored'), { ...first, outcome: 'already-committed' });
});

test('complete with another token is stale, and a pruned job is unknown', (t) => {
  const { queue, clock } = setup(t, { retainCompletedMs: 1_000 });
  const { id } = queue.enqueue('x', 1);
  const job = queue.claim('w');
  assert.throws(() => queue.complete(id, job.token + 1, 'no'), StaleLeaseError);
  assert.equal(queue.getJob(id).status, 'leased');
  queue.complete(id, job.token, 'yes');
  assert.throws(() => queue.complete(id, job.token + 1, 'no'), StaleLeaseError);
  clock.advance(1_000);
  queue.compact();
  assert.throws(() => queue.complete(id, job.token, 'no'), UnknownJobError);
});

test('a lease past its deadline can still commit until someone acts on it', (t) => {
  const { queue, clock } = setup(t);
  const { id } = queue.enqueue('x', 1);
  const job = queue.claim('w', { leaseMs: 500 });
  clock.advance(10_000);
  assert.equal(queue.complete(id, job.token, 'late but first').outcome, 'committed');

  const second = queue.enqueue('x', 2);
  const other = queue.claim('w', { leaseMs: 500 });
  clock.advance(10_000);
  queue.reapExpired();
  assert.throws(() => queue.complete(second.id, other.token, 'too late'), StaleLeaseError);
});

test('getResult', (t) => {
  const { queue, clock } = setup(t, { retainCompletedMs: 1_000 });
  const { id } = queue.enqueue('x', 1);
  assert.deepEqual(queue.getResult(id), { id, status: 'ready' });
  assert.equal(queue.getResult('j999'), null);
  const job = queue.claim('w');
  assert.deepEqual(queue.getResult(id), { id, status: 'leased' });
  const receipt = queue.complete(id, job.token, { v: 1 });
  assert.deepEqual(queue.getResult(id), {
    id,
    status: 'done',
    result: { v: 1 },
    token: job.token,
    attempts: 1,
    completedAt: receipt.completedAt,
    completionSeq: 1,
  });
  clock.advance(1_000);
  queue.compact();
  assert.equal(queue.getResult(id), null);
});

test('completions are numbered in commit order and survive restart, compaction and pruning', (t) => {
  const { queue, clock, dir, settings } = setup(t, { retainCompletedMs: 5_000 });
  const ids = [];
  for (let i = 0; i < 5; i += 1) ids.push(queue.enqueue('x', i).id);
  const claimed = ids.map(() => queue.claim('w'));
  // Commit in a different order from the order of claiming.
  for (const i of [2, 0, 4]) queue.complete(claimed[i].id, claimed[i].token, i);
  let all = queue.completions();
  assert.deepEqual(all.map((c) => [c.seq, c.id]), [[1, claimed[2].id], [2, claimed[0].id], [3, claimed[4].id]]);
  assert.deepEqual(all[0], {
    seq: 1,
    id: claimed[2].id,
    token: claimed[2].token,
    result: 2,
    completedAt: all[0].completedAt,
  });
  assert.deepEqual(queue.completions({ after: 1, limit: 1 }).map((c) => c.seq), [2]);

  clock.advance(10_000);
  queue.compact();
  assert.deepEqual(queue.completions(), [], 'pruned once past retention');
  for (const i of [1, 3]) queue.complete(claimed[i].id, claimed[i].token, i);
  all = queue.completions();
  assert.deepEqual(all.map((c) => c.seq), [4, 5], 'numbering carries on after pruning');
  queue.close();
  const reopened = openQueue(dir, settings);
  assert.deepEqual(reopened.completions().map((c) => c.seq), [4, 5]);
  assert.deepEqual(reopened.completions({ after: 4 }).map((c) => c.seq), [5]);
});

test('reclaimWorker releases a dead worker at once and counts the attempt', (t) => {
  const { queue, dir, clock } = setup(t);
  const a = queue.enqueue('x', 'a').id;
  const b = queue.enqueue('x', 'b').id;
  const c = queue.enqueue('x', 'c').id;
  const d = queue.enqueue('x', 'd').id;
  const ja = queue.claim('dead', { leaseMs: 60_000 });
  const jb = queue.claim('dead', { leaseMs: 60_000 });
  const jc = queue.claim('alive', { leaseMs: 60_000 });
  queue.complete(jb.id, jb.token, 'finished before dying');

  const reclaimed = queue.reclaimWorker('dead', { reason: 'it died' });
  assert.deepEqual(reclaimed, [{ id: a, status: 'ready' }]);
  const job = queue.getJob(a);
  assert.equal(job.status, 'ready');
  assert.equal(job.lastError, 'it died');
  assert.equal(job.attempts, 1);
  assert.equal(job.lease, null);
  assert.equal(queue.getJob(b).status, 'done');
  assert.equal(queue.getJob(c).status, 'leased', 'another worker is not touched');
  assert.equal(queue.getJob(jc.id).lease.worker, 'alive');
  assert.throws(() => queue.complete(a, ja.token, 'zombie'), StaleLeaseError);

  const release = records(dir).filter((r) => r.t === 'release');
  assert.equal(release.length, 1);
  assert.deepEqual(Object.keys(release[0]).sort(), ['at', 'error', 'fence', 'id', 't']);
  assert.equal(records(dir).filter((r) => r.id === b && r.t !== 'enqueue').length, 2, 'claim and complete only');

  assert.deepEqual(queue.reclaimWorker('dead'), [], 'nothing left to give up');
  const again = queue.claim('next');
  assert.equal(again.id, a, 'runnable straight away, no backoff');
  assert.equal(again.attempt, 2);
  assert.equal(again.token, ja.token + 1);
  assert.equal(d, queue.getJob(d).id);
  clock.advance(0);
});

test('reclaimWorker sends a job whose attempts ran out to dead', (t) => {
  const { queue, dir } = setup(t);
  const { id } = queue.enqueue('x', 1, { maxAttempts: 1 });
  queue.claim('dead');
  assert.deepEqual(queue.reclaimWorker('dead', { reason: 'gone' }), [{ id, status: 'dead' }]);
  assert.equal(queue.getJob(id).status, 'dead');
  assert.equal(queue.getJob(id).lastError, 'gone');
  assert.ok(records(dir).some((r) => r.t === 'dead' && r.id === id));
});

test('a log with release records replays the same in another process, and after compaction', (t) => {
  const { queue, dir, settings } = setup(t);
  queue.enqueue('x', 1);
  queue.claim('dead');
  queue.reclaimWorker('dead');
  const other = openQueue(dir, settings);
  assert.deepEqual(other.listJobs(), queue.listJobs());
  queue.compact();
  assert.deepEqual(openQueue(dir, settings).listJobs(), queue.listJobs());
});

test('old logs keep working: unknown records are ignored and old snapshots load', (t) => {
  const { dir, settings } = setup(t);
  // A snapshot as 0.4.x wrote it (no attempts, fence, priority or idem), then a
  // record type from some future writer.
  const old = {
    t: 'snapshot',
    at: 5,
    seq: 2,
    jobs: [
      { id: 'j1', type: 'x', payload: 1, key: 'k', status: 'done', maxAttempts: 5, availableAt: 0, lease: null, result: 'r', lastError: null, enqueuedAt: 1_000_000, completedAt: 1_000_001, seq: 1 },
      { id: 'j2', type: 'x', payload: 2, key: null, status: 'ready', maxAttempts: 5, availableAt: 0, lease: null, result: null, lastError: null, enqueuedAt: 1, completedAt: null, seq: 2 },
    ],
  };
  const file = path.join(dir, 'wal.log');
  const body = Buffer.concat([old, { t: 'future-record', id: 'j2', x: 1 }].map(encodeFrame));
  fs.writeFileSync(file, Buffer.concat([fs.readFileSync(file).subarray(0, 20), body]));

  const queue = openQueue(dir, settings);
  assert.equal(queue.getJob('j1').status, 'done');
  assert.equal(queue.getJob('j1').completionSeq, null);
  assert.deepEqual(queue.completions(), []);
  assert.equal(queue.enqueue('x', 3, { key: 'k' }).deduped, true);
  const job = queue.claim('w');
  assert.equal(job.id, 'j2');
  assert.equal(job.token, 1);
  assert.equal(queue.complete(job.id, job.token, 'ok').completionSeq, 1, 'numbering starts after the old ones');
});

// ---- workers --------------------------------------------------------------

function runnerWith(queue, handlers, extra = {}) {
  const events = [];
  const runner = new JobRunner({
    queue,
    workerId: 'w',
    handlers: normaliseHandlers(handlers),
    leaseMs: 60_000,
    heartbeatMs: 10_000,
    pollMs: 1,
    emit: (event) => events.push(event),
    ...extra,
  });
  return { runner, events };
}

test('a worker keeps trying to record a finished job until it is recorded', async (t) => {
  const { queue } = setup(t);
  const { id } = queue.enqueue('x', 1);
  const job = queue.claim('w');
  // The first complete() reaches the log but throws afterwards, the next two fail
  // outright, as a busy queue or a disk hiccup would.
  const real = queue.complete.bind(queue);
  let calls = 0;
  queue.complete = (...args) => {
    calls += 1;
    if (calls <= 2) throw new LockTimeoutError('queue.lock', 1);
    if (calls === 3) {
      real(...args);
      throw Object.assign(new Error('EIO after the write'), { code: 'EIO' });
    }
    return real(...args);
  };
  const { runner, events } = runnerWith(queue, { x: async () => 'result' });
  await runner.execute(job);
  assert.equal(calls, 4);
  assert.equal(queue.getJob(id).status, 'done');
  assert.equal(queue.completions().length, 1, 'recorded once');
  assert.ok(events.some((e) => e.kind === 'job-completed' && e.outcome === 'already-committed'));
  assert.ok(!events.some((e) => e.kind === 'job-fenced'));
});

test('a worker that was fenced stops and discards its result', async (t) => {
  const { queue, clock } = setup(t);
  const { id } = queue.enqueue('x', 1);
  const job = queue.claim('w', { leaseMs: 500 });
  const { runner, events } = runnerWith(queue, {
    x: async () => {
      clock.advance(10_000);
      queue.reapExpired();
      return 'too late';
    },
  });
  await runner.execute(job);
  assert.ok(events.some((e) => e.kind === 'job-fenced'));
  assert.ok(!events.some((e) => e.kind === 'job-completed'));
  assert.equal(queue.getJob(id).status, 'ready');
  assert.equal(queue.getJob(id).result, null);
});

test('a result that cannot be recorded fails the attempt instead of hanging the worker', async (t) => {
  const { queue } = setup(t);
  const { id } = queue.enqueue('x', 1);
  const job = queue.claim('w');
  const { runner, events } = runnerWith(queue, { x: async () => ({ n: 10n }) });
  await runner.execute(job);
  assert.ok(events.some((e) => e.kind === 'job-failed'));
  assert.equal(queue.getJob(id).status, 'ready');
  assert.match(queue.getJob(id).lastError, /BigInt/);
});

test('a worker does not start another job while it still holds a finished one', async (t) => {
  const { queue } = setup(t);
  queue.enqueue('x', 1);
  queue.enqueue('x', 2);
  const real = queue.complete.bind(queue);
  let failures = 3;
  const order = [];
  queue.complete = (...args) => {
    if (failures > 0) {
      failures -= 1;
      throw new LockTimeoutError('queue.lock', 1);
    }
    order.push(`complete ${args[0]}`);
    return real(...args);
  };
  const realClaim = queue.claim.bind(queue);
  queue.claim = (...args) => {
    const job = realClaim(...args);
    if (job) order.push(`claim ${job.id}`);
    return job;
  };
  const { runner } = runnerWith(queue, { x: async () => 'ok' });
  const running = runner.run();
  await waitUntil(() => queue.stats().done === 2);
  runner.stop();
  await running;
  assert.deepEqual(order, ['claim j1', 'complete j1', 'claim j2', 'complete j2']);
});

// ---- pools ------------------------------------------------------------------

function pool(t, dir, options = {}) {
  const ledger = path.join(dir, 'runs.jsonl');
  const p = new WorkerPool({
    dir,
    handlers: HANDLERS,
    pollMs: 5,
    ...options,
    env: { WALQ_TEST_LEDGER: ledger, ...(options.env ?? {}) },
  });
  defer(t, () => p.stop());
  return { pool: p, ledger };
}

test('a pool reclaims a killed worker at once instead of waiting for the lease', { timeout: 30_000 }, async (t) => {
  const dir = tempDir(t);
  const markers = tempDir(t);
  const queue = openQueue(dir);
  const { id } = queue.enqueue('quick', { n: 1 });
  const started = performance.now();
  const { pool: p, ledger } = pool(t, dir, {
    size: 1,
    leaseMs: 60_000,
    env: { WALQ_FAILPOINTS: 'job.before-handler=kill', WALQ_FAILPOINT_DIR: markers },
  });
  p.start();
  await p.drain({ timeoutMs: 20_000 });
  assert.ok(performance.now() - started < 15_000, 'did not wait for a 60 second lease');
  const job = queue.getJob(id);
  assert.equal(job.status, 'done');
  assert.equal(job.attempts, 2);
  assert.equal(readLedger(ledger).filter((e) => e.event === 'start').length, 1);
  assert.ok(records(dir).some((r) => r.t === 'release' && r.id === id));
});

test('a worker killed after complete is durable does not run again', { timeout: 30_000 }, async (t) => {
  const dir = tempDir(t);
  const markers = tempDir(t);
  const queue = openQueue(dir);
  const { id } = queue.enqueue('quick', { n: 1 });
  const { pool: p, ledger } = pool(t, dir, {
    size: 1,
    leaseMs: 400,
    env: { WALQ_FAILPOINTS: 'wal.after-fsync#complete=kill', WALQ_FAILPOINT_DIR: markers },
  });
  const exited = new Promise((resolve) => p.once('exit', resolve));
  p.start();
  await exited;
  await waitUntil(() => queue.getJob(id)?.status === 'done');
  await new Promise((resolve) => setTimeout(resolve, 800));
  assert.equal(queue.getJob(id).attempts, 1);
  assert.equal(readLedger(ledger).filter((e) => e.event === 'start').length, 1);
  assert.equal(queue.completions().length, 1);
});

test('a pool only reclaims its own workers when pools share a queue', { timeout: 30_000 }, async (t) => {
  const dir = tempDir(t);
  const markers = tempDir(t);
  const queue = openQueue(dir);
  const longJob = queue.enqueue('slow', { ms: 4_000 }).id;
  const { pool: calm } = pool(t, dir, { size: 1, leaseMs: 60_000, heartbeatMs: 200, types: ['slow'] });
  calm.start();
  await waitUntil(() => queue.getJob(longJob).status === 'leased');

  // A second pool whose workers die repeatedly, with the same worker numbering.
  queue.enqueue('quick', 1);
  const { pool: doomed } = pool(t, dir, {
    size: 1,
    leaseMs: 60_000,
    types: ['quick'],
    env: { WALQ_FAILPOINTS: 'job.before-handler=kill', WALQ_FAILPOINT_DIR: markers },
  });
  doomed.start();
  await doomed.drain({ timeoutMs: 20_000 }).catch(() => {});
  await waitUntil(() => queue.getJob(longJob).status === 'done', { timeoutMs: 20_000 });
  assert.equal(queue.getJob(longJob).attempts, 1, 'the other pool\'s job was never taken from its worker');
});
