// A child that does one thing to the queue in argv[2] and is expected to be killed
// by a failpoint on the way. argv[3] picks what it does.

import { openQueue } from '../../src/index.mjs';

const [, , dir, action] = process.argv;
const queue = openQueue(dir, { backoff: { baseMs: 0 } });

switch (action) {
  case 'complete': {
    const job = queue.claim('child');
    queue.complete(job.id, job.token, { by: 'child' });
    break;
  }
  case 'claim':
    queue.claim('child');
    break;
  case 'compact':
    queue.compact();
    break;
  case 'enqueue':
    queue.enqueue('from-child', { pid: process.pid });
    break;
  case 'open':
    break;
  default:
    throw new Error(`unknown action ${action}`);
}
queue.close();
