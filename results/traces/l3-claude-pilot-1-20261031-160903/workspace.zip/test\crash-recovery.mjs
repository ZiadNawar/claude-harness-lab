// Crashes and power cuts at every step of a write, checked against
// docs/guarantees.md. Each case runs a child that a failpoint kills, then looks at
// what the next process finds.

import assert from 'node:assert/strict';
import { fork } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import { test } from 'node:test';
import { fileURLToPath } from 'node:url';
import { CorruptLogError, ManualClock, openQueue } from '../src/index.mjs';
import { defer, tempDir } from './helpers/tmp.mjs';

const CHILD = fileURLToPath(new URL('./helpers/crash-child.mjs', import.meta.url));

function exitOf(child) {
  return new Promise((resolve) => child.on('exit', (code, signal) => resolve({ code, signal })));
}

/** Runs the child with a failpoint armed. Returns whether the failpoint fired. */
async function crash(t, dir, action, rules, { power = false } = {}) {
  const markers = tempDir(t);
  const env = { ...process.env, WALQ_FAILPOINTS: rules, WALQ_FAILPOINT_DIR: markers };
  if (power) env.WALQ_SIMULATE_POWER_LOSS = '1';
  const child = fork(CHILD, [dir, action], { env, silent: true });
  defer(t, () => child.kill());
  await exitOf(child);
  const name = rules.split('=')[0].replace('#', '.');
  return fs.existsSync(path.join(markers, `${name}.hit`));
}

const later = () => new ManualClock(Date.now() + 3_600_000);

for (const power of [false, true]) {
  const model = power ? 'power loss' : 'kill';

  // The crash table of RFC 007, point by point.
  for (const point of ['wal.before-append', 'wal.mid-append', 'wal.after-write', 'wal.after-fsync']) {
    test(`complete cut off at ${point} (${model})`, async (t) => {
      const dir = tempDir(t);
      const seeded = openQueue(dir);
      const { id } = seeded.enqueue('x', 1);
      seeded.close();

      assert.ok(await crash(t, dir, 'complete', `${point}#complete=kill`, { power }), 'failpoint fired');

      const queue = openQueue(dir, { clock: later(), backoff: { baseMs: 0 } });
      const committed = point === 'wal.after-fsync' || (point === 'wal.after-write' && !power);
      if (committed) {
        assert.equal(queue.getJob(id).status, 'done');
        assert.deepEqual(queue.reapExpired(), []);
        assert.equal(queue.claim('again'), null, 'a commit never leads to a rerun');
      } else {
        assert.equal(queue.getJob(id).status, 'leased');
        assert.equal(queue.reapExpired().length, 1);
        const again = queue.claim('again');
        assert.equal(again.id, id, 'an uncommitted job runs again');
        assert.equal(again.attempt, 2);
        queue.complete(again.id, again.token, 'ok');
      }

      // Nothing written afterwards may be affected by what was cut off (G3).
      queue.enqueue('x', 'after');
      queue.close();
      const reopened = openQueue(dir, { clock: later() });
      assert.equal(reopened.getJob(id).status, 'done');
      assert.equal(reopened.stats().total, 2);
    });
  }

  test(`enqueue cut off mid-append does not harm later writes (${model})`, async (t) => {
    const dir = tempDir(t);
    openQueue(dir).close();
    assert.ok(await crash(t, dir, 'enqueue', 'wal.mid-append=kill', { power }));
    for (let round = 0; round < 3; round += 1) {
      const queue = openQueue(dir);
      queue.enqueue('x', round);
      queue.close();
    }
    const queue = openQueue(dir);
    assert.deepEqual(queue.listJobs().map((j) => j.payload).filter((p) => typeof p === 'number'), [0, 1, 2]);
  });

  for (const point of ['compact.after-tmp-write', 'compact.before-rename', 'compact.after-rename']) {
    test(`compaction killed at ${point} loses nothing and can run again (${model})`, async (t) => {
      const dir = tempDir(t);
      const clock = new ManualClock(10_000);
      const seeded = openQueue(dir, { clock });
      for (let i = 0; i < 6; i += 1) seeded.enqueue('x', { i }, { key: `k${i}` });
      const job = seeded.claim('w');
      seeded.fail(job.id, job.token, 'oops');
      const before = seeded.listJobs();
      seeded.close();

      assert.ok(await crash(t, dir, 'compact', `${point}=kill`, { power }));

      const queue = openQueue(dir, { clock });
      assert.deepEqual(queue.listJobs(), before);
      queue.compact();
      assert.deepEqual(queue.listJobs(), before);
      queue.enqueue('x', 'more');
      queue.close();
      assert.equal(openQueue(dir, { clock }).stats().total, 7);
    });
  }
}

test('a log whose creation is cut off by a power loss still opens', async (t) => {
  const dir = tempDir(t);
  assert.ok(await crash(t, dir, 'open', 'wal.after-create=kill', { power: true }));
  const queue = openQueue(dir);
  queue.enqueue('x', 1);
  assert.equal(queue.stats().total, 1);
});

test('a compaction that keeps failing does not poison the next one', (t) => {
  const dir = tempDir(t);
  const queue = openQueue(dir);
  queue.enqueue('x', 1);
  // What a crashed compaction leaves behind.
  fs.writeFileSync(path.join(dir, 'wal.log.compact'), 'half a log');
  queue.compact();
  assert.equal(queue.stats().generation, 2);
  assert.ok(!fs.existsSync(path.join(dir, 'wal.log.compact')));
});

test('a failed compaction cleans up its temp file', (t) => {
  const dir = tempDir(t);
  const queue = openQueue(dir);
  queue.enqueue('x', 1);
  // Make the rename fail: a directory cannot be replaced by a file.
  const log = path.join(dir, 'wal.log');
  const keep = fs.readFileSync(log);
  const original = queue.store.ops.rename;
  queue.store.ops.rename = () => {
    const err = new Error('EPERM: operation not permitted, rename');
    err.code = 'EPERM';
    throw err;
  };
  assert.throws(() => queue.compact(), /compaction failed/);
  queue.store.ops.rename = original;
  assert.ok(!fs.existsSync(path.join(dir, 'wal.log.compact')));
  assert.deepEqual(fs.readFileSync(log), keep);
  queue.enqueue('x', 2);
  queue.compact();
  assert.equal(queue.stats().total, 2);
});

test('damage inside the log is reported with its offset and the file is left alone', (t) => {
  const dir = tempDir(t);
  const clock = new ManualClock(0);
  const queue = openQueue(dir, { clock });
  for (let i = 0; i < 5; i += 1) queue.enqueue('x', `payload ${i}`);
  queue.close();
  const log = path.join(dir, 'wal.log');
  const bytes = fs.readFileSync(log);
  bytes[bytes.length >> 1] ^= 0x55;
  fs.writeFileSync(log, bytes);
  assert.throws(
    () => openQueue(dir, { clock }),
    (err) => err instanceof CorruptLogError && Number.isInteger(err.offset),
  );
  assert.deepEqual(fs.readFileSync(log), bytes);
});

test('a log with trailing damage after good frames is reported, not trimmed', (t) => {
  const dir = tempDir(t);
  const queue = openQueue(dir);
  queue.enqueue('x', 1);
  queue.enqueue('x', 2);
  queue.close();
  const log = path.join(dir, 'wal.log');
  const bytes = fs.readFileSync(log);
  // Damage the first record's payload: the second record, which follows it, was acknowledged.
  bytes[40] ^= 0xff;
  fs.writeFileSync(log, bytes);
  assert.throws(() => openQueue(dir), CorruptLogError);
  assert.deepEqual(fs.readFileSync(log), bytes);
});
