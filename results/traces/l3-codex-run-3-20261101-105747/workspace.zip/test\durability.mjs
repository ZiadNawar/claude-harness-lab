import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { test } from 'node:test';
import { clearFailpoints, CorruptLogError, ManualClock, onFailpoint, openQueue } from '../src/index.mjs';
import { copyDir, crashAt, powerLoss } from './helpers/crash.mjs';
import { tempDir } from './helpers/tmp.mjs';

const BACKOFF = { baseMs: 100, factor: 2, maxMs: 10_000 };

function setup(t, extra = {}) {
  const clock = new ManualClock(1_000);
  const dir = tempDir(t);
  return { clock, dir, options: { clock, backoff: BACKOFF, ...extra }, log: path.join(dir, 'wal.log') };
}

test('a torn tail is removed, and later writes are not hidden behind it', (t) => {
  const { dir, options, log } = setup(t);
  const queue = openQueue(dir, options);
  queue.enqueue('x', 'first');
  queue.close();
  fs.appendFileSync(log, Buffer.from([0xad, 0xfb, 0x40, 0, 0, 0, 1, 2]));

  const again = openQueue(dir, options);
  assert.equal(again.stats().tornTailsDropped, 1);
  again.enqueue('x', 'second');
  again.close();

  const reopened = openQueue(dir, options);
  assert.deepEqual(reopened.listJobs().map((job) => job.payload), ['first', 'second']);
});

test('damage with acknowledged records after it is reported and left alone', (t) => {
  const { dir, options, log } = setup(t);
  const queue = openQueue(dir, options);
  for (const name of ['a', 'b', 'c']) queue.enqueue('x', name);
  queue.close();
  const bytes = fs.readFileSync(log);
  bytes[40] ^= 0xff;
  fs.writeFileSync(log, bytes);
  assert.throws(() => openQueue(dir, options), (err) => err instanceof CorruptLogError && Number.isInteger(err.offset));
  assert.ok(fs.readFileSync(log).equals(bytes));
});

test('damage to the last acknowledged record of a log that was cut is still a torn tail', (t) => {
  const { dir, options, log } = setup(t);
  const queue = openQueue(dir, options);
  queue.enqueue('x', 'a');
  queue.enqueue('x', 'b');
  queue.close();
  fs.truncateSync(log, fs.statSync(log).size - 3);
  assert.equal(openQueue(dir, options).stats().total, 1);
});

test('a log far bigger than one read chunk, with records bigger than it, loads whole', (t) => {
  const { dir, options } = setup(t, { compactAfterBytes: 0 });
  const queue = openQueue(dir, options);
  const jobs = Array.from({ length: 300 }, (_, n) => ({ type: 'x', payload: { n, pad: 'p'.repeat(20_000) } }));
  queue.enqueueMany(jobs);
  queue.enqueue('x', { huge: 'h'.repeat(3 * 1024 * 1024) });
  queue.enqueue('x', 'last');
  queue.close();
  assert.ok(fs.statSync(path.join(dir, 'wal.log')).size > 8 * 1024 * 1024);

  const reopened = openQueue(dir, options);
  assert.equal(reopened.stats().total, 302);
  assert.equal(reopened.stats().tornTailsDropped, 0);
  reopened.compact();
  assert.equal(reopened.stats().total, 302);
  reopened.close();
  assert.equal(openQueue(dir, options).stats().total, 302);
});

test('a state too big for one frame compacts into several and reloads', (t) => {
  const { dir, options } = setup(t, { compactAfterBytes: 0 });
  const queue = openQueue(dir, options);
  for (let n = 0; n < 12; n += 1) queue.enqueue('x', { n, pad: 'p'.repeat(1024 * 1024) }, { key: `k${n}` });
  queue.compact();
  queue.close();
  const reopened = openQueue(dir, options);
  assert.equal(reopened.stats().total, 12);
  assert.equal(reopened.enqueue('x', null, { key: 'k5' }).deduped, true);
});

test('a retry keeps its due time and attempt count across restart and compaction', (t) => {
  const { dir, clock, options } = setup(t);
  const queue = openQueue(dir, options);
  const { id } = queue.enqueue('x', null, { maxAttempts: 3, priority: 4 });
  const first = queue.claim('w');
  const { retryAt } = queue.fail(id, first.token, 'boom');
  assert.equal(queue.getJob(id).availableAt, retryAt);
  queue.compact();
  queue.close();

  clock.advance(60_000);
  const reopened = openQueue(dir, options);
  const job = reopened.getJob(id);
  assert.equal(job.availableAt, retryAt);
  assert.equal(job.attempts, 1);
  assert.equal(job.priority, 4);
  assert.equal(job.fence, 1);
  assert.equal(job.maxAttempts, 3);

  for (let attempt = 2; attempt <= 3; attempt += 1) {
    const next = reopened.claim('w');
    assert.equal(next.attempt, attempt);
    const result = reopened.fail(id, next.token, 'boom');
    reopened.compact();
    clock.advance(60_000);
    assert.equal(result.status, attempt === 3 ? 'dead' : 'ready');
  }
  assert.equal(reopened.claim('w'), null);
});

test('an expired lease keeps its schedule when the log is replayed later', (t) => {
  const { dir, clock, options } = setup(t);
  const queue = openQueue(dir, options);
  const { id } = queue.enqueue('x', null);
  queue.claim('w', { leaseMs: 500 });
  clock.advance(500);
  const [reaped] = queue.reapExpired();
  queue.close();
  clock.advance(1_000_000);
  assert.equal(openQueue(dir, options).getJob(id).availableAt, reaped.retryAt);
});

test('a key is remembered after compaction for its whole time to live, without the job', (t) => {
  const { dir, clock, options } = setup(t, { retainCompletedMs: 1_000, idempotencyTtlMs: 100_000 });
  const queue = openQueue(dir, options);
  const { id } = queue.enqueue('report', null, { key: 'monthly' });
  const job = queue.claim('w');
  queue.complete(job.id, job.token, { sent: true });
  clock.advance(5_000);
  queue.compact();
  assert.equal(queue.getJob(id), null);
  queue.close();

  const reopened = openQueue(dir, options);
  const again = reopened.enqueue('report', null, { key: 'monthly' });
  assert.deepEqual(again, { id, status: 'done', result: { sent: true }, deduped: true });
  clock.advance(100_000);
  reopened.compact();
  assert.equal(reopened.enqueue('report', null, { key: 'monthly' }).deduped, false);
});

test('two processes racing on a key create one job', (t) => {
  t.after(clearFailpoints);
  const { dir, options } = setup(t);
  const one = openQueue(dir, options);
  const two = openQueue(dir, options);
  let second;
  onFailpoint('enqueue.before-lock', () => {
    clearFailpoints();
    second = two.enqueue('x', 2, { key: 'k' });
  });
  const first = one.enqueue('x', 1, { key: 'k' });
  assert.equal(second.deduped, false);
  assert.equal(first.deduped, true);
  assert.equal(one.stats().total, 1);
});

test('a job claimed by another process in the gap is not claimed twice', (t) => {
  t.after(clearFailpoints);
  const { dir, options } = setup(t);
  const one = openQueue(dir, options);
  const two = openQueue(dir, options);
  one.enqueue('x', null);
  let stolen;
  onFailpoint('claim.before-lock', () => {
    clearFailpoints();
    stolen = two.claim('b');
  });
  assert.equal(one.claim('a'), null);
  assert.ok(stolen);
  assert.equal(one.stats().leased, 1);
});
test('a heartbeat from one process keeps the lease against another process reaper', (t) => {
  const { dir, clock, options } = setup(t);
  const worker = openQueue(dir, options);
  const reaper = openQueue(dir, options);
  worker.enqueue('x', null);
  const job = worker.claim('w', { leaseMs: 500 });
  clock.advance(400);
  worker.heartbeat(job.id, job.token, { leaseMs: 500 });
  clock.advance(400);
  assert.deepEqual(reaper.reapExpired(), []);
  worker.complete(job.id, job.token, 'ok');
});

test('tokens are never issued twice for a job, even across requeue', (t) => {
  const { dir, options } = setup(t);
  const queue = openQueue(dir, options);
  const { id } = queue.enqueue('x', null, { maxAttempts: 1 });
  const first = queue.claim('w');
  queue.fail(id, first.token, 'dead now');
  queue.requeueDead(id);
  queue.compact();
  const second = queue.claim('w');
  assert.ok(second.token > first.token);
  assert.throws(() => queue.complete(id, first.token, 'late'), { name: 'StaleLeaseError' });
});

test('compaction works with a reader holding the log open, and again afterwards', (t) => {
  const { dir, options, log } = setup(t);
  const queue = openQueue(dir, options);
  queue.enqueue('x', 1);
  const reader = fs.openSync(log, 'r');
  try {
    queue.compact();
    queue.enqueue('x', 2);
    queue.compact();
  } finally {
    fs.closeSync(reader);
  }
  queue.compact();
  queue.close();
  assert.deepEqual(fs.readdirSync(dir).sort(), ['queue.lock', 'wal.log']);
  assert.equal(openQueue(dir, options).stats().total, 2);
});

test('a temp file left by a dead compaction does not block the next one', (t) => {
  const { dir, options, log } = setup(t);
  const queue = openQueue(dir, options);
  queue.enqueue('x', 1);
  fs.writeFileSync(`${log}.compact`, 'garbage');
  queue.compact();
  queue.compact();
  assert.equal(queue.stats().total, 1);
  assert.ok(!fs.existsSync(`${log}.compact`));
});

test('a compaction killed between moving the log aside and in leaves a queue that opens', (t) => {
  const { dir, options, log } = setup(t);
  const queue = openQueue(dir, options);
  queue.enqueue('x', 1);
  fs.renameSync(log, `${log}.old.2`);
  fs.writeFileSync(`${log}.compact`, 'partial');
  queue.close();
  assert.equal(openQueue(dir, options).stats().total, 1);
  assert.deepEqual(fs.readdirSync(dir).sort(), ['queue.lock', 'wal.log']);
});

test('another process follows a compaction even when the new log is no smaller', (t) => {
  const { dir, options } = setup(t, { compactAfterBytes: 0 });
  const one = openQueue(dir, options);
  const two = openQueue(dir, options);
  one.enqueue('x', 1);
  one.compact();
  two.store.refresh();
  one.compact();
  one.enqueue('x', 2);
  one.compact();
  assert.equal(two.stats().total, 2);
  assert.equal(two.stats().generation, one.stats().generation);
});

test('automatic compaction does not rewrite a large live state on every write', (t) => {
  const { dir, options } = setup(t, { compactAfterBytes: 5_000 });
  const queue = openQueue(dir, options);
  for (let n = 0; n < 60; n += 1) queue.enqueue('x', { n, pad: 'p'.repeat(200) });
  const generation = queue.stats().generation;
  for (let n = 0; n < 40; n += 1) queue.enqueue('x', 'more');
  assert.ok(queue.stats().generation - generation <= 3, `generation rose by ${queue.stats().generation - generation}`);
});

test('a power cut at any point of the first create or of a compaction leaves a queue that opens', (t) => {
  powerLoss(t);
  const points = ['wal.after-create', 'compact.after-tmp-write', 'compact.before-rename', 'compact.after-rename'];
  for (const point of points) {
    const { dir, options } = setup(t);
    let queue;
    const image =
      point === 'wal.after-create'
        ? crashAt(t, dir, point, () => openQueue(dir, options))
        : crashAt(t, dir, point, () => {
            queue = openQueue(dir, options);
            queue.enqueue('x', 1);
            queue.compact();
          });
    const opened = openQueue(image, options);
    if (point !== 'wal.after-create') assert.equal(opened.stats().total, 1, point);
    opened.enqueue('x', 2);
    opened.close();
  }
});

test('a power cut leaves nothing of an unacknowledged append, and everything acknowledged', (t) => {
  powerLoss(t);
  for (const point of ['wal.before-append', 'wal.mid-append', 'wal.after-write']) {
    const { dir, options } = setup(t);
    const queue = openQueue(dir, options);
    queue.enqueue('x', 'acked');
    const image = crashAt(t, dir, point, () => queue.enqueue('x', 'lost'), { type: 'enqueue' });
    const opened = openQueue(image, options);
    assert.deepEqual(opened.listJobs().map((job) => job.payload), ['acked'], point);
    opened.enqueue('x', 'after');
    opened.close();
    assert.deepEqual(openQueue(image, options).listJobs().map((job) => job.payload), ['acked', 'after'], point);
  }
});

test('a failed append leaves nothing behind in the log', (t) => {
  const { dir, options, log } = setup(t);
  const queue = openQueue(dir, options);
  queue.enqueue('x', 1);
  const before = fs.statSync(log).size;
  queue.store.wal.ops.sync = () => {
    throw new Error('disk hiccup');
  };
  assert.throws(() => queue.enqueue('x', 2), /disk hiccup/);
  assert.equal(fs.statSync(log).size, before);
  assert.equal(copyAndCount(t, dir, options), 1);
});

function copyAndCount(t, dir, options) {
  const copy = tempDir(t);
  copyDir(dir, copy);
  return openQueue(copy, options).stats().total;
}