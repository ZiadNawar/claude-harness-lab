// Replaces the log with a one-record log holding the current state. Runs under
// the queue lock. docs/compaction.md describes the protocol.

import path from 'node:path';
import { encodeFrame, encodeHeader } from './frame.mjs';
import { hit } from './failpoints.mjs';
import { createLogger } from './logger.mjs';
import { buildSnapshotRecords } from './snapshot.mjs';

const log = createLogger('compactor');

// What a platform says when another process has the file open and that stops us
// replacing it.
const IN_USE = new Set(['EPERM', 'EACCES', 'EBUSY']);

export function compactionTempPath(walFile) {
  return `${walFile}.compact`;
}

export function compactionBackupPath(walFile, generation) {
  return `${walFile}.old.${generation}`;
}

function backupsOf(ops, walFile) {
  const prefix = `${path.basename(walFile)}.old.`;
  return ops
    .list(path.dirname(walFile))
    .filter((name) => name.startsWith(prefix))
    .map((name) => ({ file: path.join(path.dirname(walFile), name), generation: Number(name.slice(prefix.length)) }))
    .filter((backup) => Number.isInteger(backup.generation))
    .sort((left, right) => right.generation - left.generation);
}

/**
 * Puts `temp` in place of `file`. A rename over a file that another process has
 * open is refused on Windows, but the open file can be renamed away, so then the
 * old log is moved aside, the new one moved in, and the old one removed. Between
 * those two renames there is no wal.log; settleCompaction() puts the old log back
 * if a process dies there. The backup name carries the generation, because a name
 * whose file is still open somewhere cannot be reused.
 */
function install(ops, temp, file, backup) {
  try {
    ops.rename(temp, file);
    return;
  } catch (err) {
    if (!IN_USE.has(err.code)) throw err;
  }
  ops.rename(file, backup);
  try {
    ops.rename(temp, file);
  } catch (err) {
    ops.rename(backup, file);
    throw err;
  }
}

/**
 * Makes the directory consistent after a compaction that was cut short. Must run
 * under the lock. Returns true if it had to restore the log.
 */
export function settleCompaction({ wal, ops }) {
  const backups = backupsOf(ops, wal.file);
  let restored = false;
  if (!ops.exists(wal.file) && backups.length) {
    ops.rename(backups[0].file, wal.file);
    ops.syncDir(path.dirname(wal.file));
    restored = true;
    log.warn('restored the log from an interrupted compaction', { file: wal.file });
  }
  for (const leftover of [compactionTempPath(wal.file), ...backupsOf(ops, wal.file).map((backup) => backup.file)]) {
    try {
      ops.unlink(leftover);
    } catch (err) {
      log.warn('could not remove a leftover compaction file', { file: leftover, error: err.message });
    }
  }
  return restored;
}
/**
 * Writes and installs the next generation of the log. Returns the snapshot records and
 * the size of the new file. If this throws, the old log is still in place.
 */
export function compactLog({ wal, ops, state, generation, now, config }) {
  const nextGeneration = generation + 1;
  const snapshots = buildSnapshotRecords(state, now, config);
  const bytes = Buffer.concat([encodeHeader(nextGeneration), ...snapshots.map(encodeFrame)]);
  const tempPath = compactionTempPath(wal.file);
  const backup = compactionBackupPath(wal.file, generation);

  for (const old of backupsOf(ops, wal.file)) {
    try {
      ops.unlink(old.file);
    } catch (err) {
      log.warn('could not remove an earlier log', { file: old.file, error: err.message });
    }
  }

  try {
    // The lock is held, so nobody else is compacting and a temp file that is
    // already here is the remains of an earlier attempt.
    ops.create(tempPath);
    ops.writeAt(tempPath, bytes, 0);
    hit('compact.after-tmp-write', { generation: nextGeneration });
    ops.sync(tempPath);
    hit('compact.before-rename', { generation: nextGeneration });
    install(ops, tempPath, wal.file, backup);
    hit('compact.after-rename', { generation: nextGeneration });
    ops.sync(wal.file);
    ops.syncDir(path.dirname(wal.file));
  } catch (err) {
    err.message = `compaction failed: ${err.message}`;
    throw err;
  }

  try {
    ops.unlink(backup);
  } catch (err) {
    log.warn('could not remove the previous log', { file: backup, error: err.message });
  }
  return { snapshots, generation: nextGeneration, size: bytes.length };
}