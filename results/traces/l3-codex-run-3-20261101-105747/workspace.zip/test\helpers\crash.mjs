// In-process crash model. Under WALQ_SIMULATE_POWER_LOSS=1 only synced bytes are on
// disk, so copying the queue directory at a failpoint gives exactly what a machine
// that lost power at that instant would have left.

import fs from 'node:fs';
import path from 'node:path';
import { clearFailpoints, onFailpoint } from '../../src/index.mjs';
import { defer, tempDir } from './tmp.mjs';

export function powerLoss(t) {
  const before = process.env.WALQ_SIMULATE_POWER_LOSS;
  process.env.WALQ_SIMULATE_POWER_LOSS = '1';
  defer(t, () => {
    if (before === undefined) delete process.env.WALQ_SIMULATE_POWER_LOSS;
    else process.env.WALQ_SIMULATE_POWER_LOSS = before;
    clearFailpoints();
  });
}

export function copyDir(from, to) {
  fs.mkdirSync(to, { recursive: true });
  for (const name of fs.readdirSync(from)) {
    if (name === 'queue.lock') continue;
    fs.copyFileSync(path.join(from, name), path.join(to, name));
  }
}

/** Runs `action`, and returns the directory as it was the nth time `point` was reached. */
export function crashAt(t, dir, point, action, { nth = 1, type = null } = {}) {
  let seen = 0;
  let image = null;
  onFailpoint(point, (ctx) => {
    if (type && ctx.type !== type) return;
    seen += 1;
    if (seen === nth && !image) {
      image = tempDir(t);
      copyDir(dir, image);
    }
  });
  try {
    action();
  } finally {
    clearFailpoints();
  }
  if (!image) throw new Error(`failpoint ${point} was not reached`);
  return image;
}