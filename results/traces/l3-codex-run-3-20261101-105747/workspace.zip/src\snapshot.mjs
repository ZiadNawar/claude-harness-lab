// A compacted log starts with one snapshot record holding the state it replaces.

import { isPastRetention } from './retention.mjs';

function serializeJob(job) {
  return { ...job, lease: job.lease ? { ...job.lease } : null };
}

/**
 * Builds the snapshot record, dropping terminal jobs past their retention.
 * `idem` keeps every key that is still within its time to live, with the outcome
 * of the job behind it when that job is no longer in the snapshot.
 */
export function buildSnapshot(state, now, config) {
  const kept = [];
  for (const job of state.jobs.values()) {
    if (!isPastRetention(job, now, config)) kept.push(job);
  }

  const idem = [];
  for (const [key, entry] of state.idem) {
    if (now - entry.at >= config.idempotencyTtlMs) continue;
    const job = state.jobs.get(entry.id);
    const outcome = job
      ? { status: job.status, result: job.result ?? null }
      : { status: entry.status ?? 'done', result: entry.result ?? null };
    idem.push({ key, id: entry.id, at: entry.at, ...outcome });
  }

  return {
    t: 'snapshot',
    at: now,
    seq: state.seq,
    completionSeq: state.completionSeq,
    jobs: kept.map(serializeJob),
    idem,
  };
}

// Well under the frame limit, so that a state of any size fits in the log.
const PART_BYTES = 8 * 1024 * 1024;

/**
 * The records that make up a snapshot: the `snapshot` itself, and, when the state
 * is too big for one frame, `snapshot-more` records that add to it. They are
 * written together into one new file, so a log holds all of them or none.
 */
export function buildSnapshotRecords(state, now, config) {
  const whole = buildSnapshot(state, now, config);
  const head = { ...whole, jobs: [], idem: [] };
  const records = [head];
  let current = head;
  let size = 0;
  const add = (field, item) => {
    const itemBytes = Buffer.byteLength(JSON.stringify(item));
    if (size > 0 && size + itemBytes > PART_BYTES) {
      current = { t: 'snapshot-more', at: now, jobs: [], idem: [] };
      records.push(current);
      size = 0;
    }
    current[field].push(item);
    size += itemBytes;
  };
  for (const job of whole.jobs) add('jobs', job);
  for (const entry of whole.idem) add('idem', entry);
  return records;
}

export function loadSnapshotMore(state, rec) {
  addJobs(state, rec.jobs ?? []);
  for (const entry of rec.idem ?? []) {
    state.idem.set(entry.key, { id: entry.id, at: entry.at, status: entry.status, result: entry.result });
  }
}

function addJobs(state, jobs) {
  for (const job of jobs) {
    state.jobs.set(job.id, {
      ...job,
      priority: job.priority ?? 0,
      attempts: job.attempts ?? 0,
      fence: job.fence ?? job.lease?.fence ?? 0,
      completionSeq: job.completionSeq ?? null,
    });
  }
}

export function loadSnapshot(state, rec) {
  state.seq = rec.seq;
  state.completionSeq = rec.completionSeq ?? 0;
  state.jobs = new Map();
  state.idem = new Map();
  addJobs(state, rec.jobs);
  if (rec.idem) {
    for (const entry of rec.idem) {
      state.idem.set(entry.key, { id: entry.id, at: entry.at, status: entry.status, result: entry.result });
    }
  } else {
    for (const job of state.jobs.values()) {
      if (job.key) state.idem.set(job.key, { id: job.id, at: job.enqueuedAt });
    }
  }
}