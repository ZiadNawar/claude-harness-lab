import assert from 'node:assert/strict';
import { test } from 'node:test';
import { clearFailpoints, ManualClock, onFailpoint, openQueue, StaleLeaseError, UnknownJobError } from '../src/index.mjs';
import { JobRunner } from '../src/worker/runner.mjs';
import { crashAt, powerLoss } from './helpers/crash.mjs';
import { tempDir } from './helpers/tmp.mjs';

function setup(t, extra = {}) {
  const clock = new ManualClock(1_000);
  const dir = tempDir(t);
  const options = { clock, backoff: { baseMs: 100, factor: 2, maxMs: 1_000 }, ...extra };
  return { clock, dir, options, queue: openQueue(dir, options) };
}

test('complete returns a receipt, and a repeat with the same token is already-committed', (t) => {
  const { queue, dir, options, clock } = setup(t, { retainCompletedMs: 10_000 });
  const { id } = queue.enqueue('x', null);
  const job = queue.claim('w');
  const first = queue.complete(id, job.token, { n: 1 });
  assert.deepEqual(first, { id, outcome: 'committed', token: job.token, result: { n: 1 }, completedAt: 1_000, completionSeq: 1 });
  const size = queue.stats().logBytes;
  clock.advance(5);
  const again = queue.complete(id, job.token, { n: 2 });
  assert.deepEqual(again, { ...first, outcome: 'already-committed' });
  assert.equal(queue.stats().logBytes, size);

  queue.compact();
  queue.close();
  const reopened = openQueue(dir, options);
  assert.deepEqual(reopened.complete(id, job.token, 'ignored'), { ...first, outcome: 'already-committed' });
  assert.throws(() => reopened.complete(id, job.token + 1, 'x'), StaleLeaseError);
});

test('a pruned job raises UnknownJobError on complete and null on getResult', (t) => {
  const { queue, clock } = setup(t, { retainCompletedMs: 1_000 });
  const { id } = queue.enqueue('x', null);
  const job = queue.claim('w');
  queue.complete(id, job.token, 'r');
  clock.advance(1_000);
  queue.compact();
  assert.throws(() => queue.complete(id, job.token, 'r'), UnknownJobError);
  assert.equal(queue.getResult(id), null);
  assert.equal(queue.getResult('j99'), null);
});

test('a lease past its deadline can still commit until someone acts on it', (t) => {
  const { queue, clock } = setup(t);
  const { id } = queue.enqueue('x', null);
  const job = queue.claim('w', { leaseMs: 100 });
  clock.advance(500);
  assert.equal(queue.complete(id, job.token, 'late').outcome, 'committed');

  const other = queue.enqueue('x', null).id;
  const second = queue.claim('w', { leaseMs: 100 });
  clock.advance(500);
  queue.reapExpired();
  assert.throws(() => queue.complete(other, second.token, 'late'), StaleLeaseError);
});

test('getResult reports finished jobs fully and others by status', (t) => {
  const { queue } = setup(t);
  const { id } = queue.enqueue('x', null);
  assert.deepEqual(queue.getResult(id), { id, status: 'ready' });
  const job = queue.claim('w');
  assert.deepEqual(queue.getResult(id), { id, status: 'leased' });
  queue.complete(id, job.token, 'r');
  assert.deepEqual(queue.getResult(id), { id, status: 'done', result: 'r', token: 1, attempts: 1, completedAt: 1_000, completionSeq: 1 });
});

test('completions are numbered in commit order and the numbering survives pruning and restart', (t) => {
  const { queue, dir, options, clock } = setup(t, { retainCompletedMs: 5_000 });
  const ids = [0, 1, 2].map((n) => queue.enqueue('x', n).id);
  const jobs = ids.map(() => queue.claim('w'));
  for (const job of [jobs[2], jobs[0]]) {
    queue.complete(job.id, job.token, job.payload);
    clock.advance(1);
  }
  assert.deepEqual(queue.completions().map((c) => [c.seq, c.id]), [[1, ids[2]], [2, ids[0]]]);
  assert.deepEqual(queue.completions({ after: 1 }).map((c) => c.seq), [2]);
  assert.equal(queue.completions({ limit: 1 }).length, 1);

  clock.advance(10_000);
  queue.compact();
  queue.complete(jobs[1].id, jobs[1].token, 1);
  queue.close();
  const reopened = openQueue(dir, options);
  assert.deepEqual(reopened.completions().map((c) => c.seq), [3]);
});

test('reclaimWorker releases only that worker, at once, without backoff, and counts the attempt', (t) => {
  const { queue } = setup(t);
  const ids = [queue.enqueue('x', 1).id, queue.enqueue('x', 2).id, queue.enqueue('x', 3, { maxAttempts: 1 }).id];
  const mine = queue.claim('dead');
  const theirs = queue.claim('alive');
  const last = queue.claim('dead');
  const done = queue.enqueue('x', 4).id;
  const finished = queue.claim('dead');
  queue.complete(done, finished.token, 'ok');
  const sizeBefore = queue.stats().logBytes;

  const result = queue.reclaimWorker('dead', { reason: 'pool saw it exit' });
  assert.deepEqual(result.sort((a, b) => a.id.localeCompare(b.id)), [
    { id: ids[0], status: 'ready' },
    { id: ids[2], status: 'dead' },
  ]);
  assert.ok(queue.stats().logBytes > sizeBefore);
  assert.equal(queue.getJob(ids[0]).lastError, 'pool saw it exit');
  assert.equal(queue.getJob(ids[1]).status, 'leased');
  assert.equal(queue.getJob(done).status, 'done');
  assert.throws(() => queue.heartbeat(ids[0], mine.token), StaleLeaseError);
  assert.equal(queue.reclaimWorker('dead').length, 0);
  const again = queue.claim('w2');
  assert.equal(again.id, ids[0]);
  assert.equal(again.attempt, 2);
  assert.ok(theirs && last);
});

test('a released job replays the same in every process and after compaction', (t) => {
  const { queue, dir, options } = setup(t);
  const { id } = queue.enqueue('x', null);
  queue.claim('dead');
  queue.reclaimWorker('dead');
  const other = openQueue(dir, options);
  assert.equal(other.getJob(id).availableAt, queue.getJob(id).availableAt);
  queue.compact();
  assert.equal(openQueue(dir, options).getJob(id).attempts, 1);
});

test('the crash table: a power cut around the commit', (t) => {
  powerLoss(t);
  const cases = [
    ['wal.before-append', false],
    ['wal.mid-append', false],
    ['wal.after-write', false],
    ['wal.after-fsync', true],
  ];
  for (const [point, committed] of cases) {
    const { dir, options, queue } = setup(t);
    const { id } = queue.enqueue('x', null);
    const job = queue.claim('w', { leaseMs: 100 });
    const image = crashAt(t, dir, point, () => queue.complete(id, job.token, 'r'), { type: 'complete' });
    const reopened = openQueue(image, options);
    assert.equal(reopened.getJob(id).status, committed ? 'done' : 'leased', point);
    if (!committed) {
      options.clock.advance(1_000);
      reopened.reapExpired();
      options.clock.advance(1_000);
      assert.equal(reopened.claim('w2')?.id, id, point);
    } else {
      options.clock.advance(1_000_000);
      assert.deepEqual(reopened.reapExpired(), []);
      assert.equal(reopened.claim('w2'), null);
    }
  }
});

test('a completion is durable when complete returns, with nothing else to flush it', (t) => {
  powerLoss(t);
  const { dir, options, queue } = setup(t);
  const { id } = queue.enqueue('x', null);
  const job = queue.claim('w');
  queue.complete(id, job.token, 'r');
  const image = crashAt(t, dir, 'wal.before-append', () => queue.enqueue('x', 'next'));
  assert.equal(openQueue(image, options).getJob(id).status, 'done');
});

test('a power cut during a compaction after a commit keeps the commit', (t) => {
  powerLoss(t);
  for (const point of ['compact.after-tmp-write', 'compact.before-rename', 'compact.after-rename']) {
    const { dir, options, queue } = setup(t);
    const { id } = queue.enqueue('x', null);
    const job = queue.claim('w');
    queue.complete(id, job.token, 'r');
    const image = crashAt(t, dir, point, () => queue.compact());
    const reopened = openQueue(image, options);
    assert.equal(reopened.getJob(id).status, 'done', point);
    assert.equal(reopened.complete(id, job.token, 'x').outcome, 'already-committed');
  }
});

function runnerFor(queue, handlers, events) {
  return new JobRunner({
    queue,
    workerId: 'w',
    handlers: new Map(Object.entries(handlers).map(([type, run]) => [type, { run, timeoutMs: null }])),
    leaseMs: 60_000,
    heartbeatMs: 1_000_000,
    pollMs: 1,
    emit: (event) => events.push(event.kind),
  });
}

test('a worker keeps trying to record a finished job until it is recorded', async (t) => {
  t.after(clearFailpoints);
  const { queue } = setup(t);
  const { id } = queue.enqueue('x', null);
  const job = queue.claim('w');
  const real = queue.complete.bind(queue);
  let failures = 3;
  queue.complete = (...args) => {
    if (failures-- > 0) throw new Error('disk hiccup');
    return real(...args);
  };
  const events = [];
  await runnerFor(queue, { x: async () => 'done' }, events).execute(job);
  assert.equal(queue.getJob(id).status, 'done');
  assert.deepEqual(events.filter((kind) => kind !== 'worker-error'), ['job-started', 'job-completed']);
  assert.equal(events.filter((kind) => kind === 'worker-error').length, 3);
});

test('a worker that learns it is fenced reports job-fenced and discards its result', async (t) => {
  const { queue } = setup(t);
  const { id } = queue.enqueue('x', null);
  const job = queue.claim('w');
  const events = [];
  await runnerFor(queue, { x: async () => { queue.cancel(id); return 'r'; } }, events).execute(job);
  assert.deepEqual(events, ['job-started', 'job-fenced']);
  assert.equal(queue.getJob(id).status, 'cancelled');
});

test('job.after-handler is not reached for a failed handler, and the failure is still recorded', async (t) => {
  t.after(clearFailpoints);
  const { queue } = setup(t);
  const { id } = queue.enqueue('x', null);
  const job = queue.claim('w');
  const seen = [];
  onFailpoint('job.after-handler', () => seen.push('after'));
  await runnerFor(queue, { x: async () => { throw new Error('nope'); } }, []).execute(job);
  assert.deepEqual(seen, []);
  assert.equal(queue.getJob(id).status, 'ready');
});