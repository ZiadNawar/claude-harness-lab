# Changelog

## 0.5.0

- RFC 007: `complete()` returns a receipt; `getResult()`, `completions()`, `reclaimWorker()`; `release` record; pools reclaim dead workers; workers keep retrying to record a finished job.
- A queue reopens after any crash or power cut: torn tails are cut off, not reported; damage with acknowledged records after it still raises `CorruptLogError`.
- Compaction syncs before it replaces the log, recovers from a leftover temp file, works while another process has the log open, and every process follows it.
- Snapshots keep idempotency keys, `priority`, `attempts` and `fence`; large states are split over several frames.
- Retry due times are fixed when written; heartbeats reach every process; claim and enqueue-by-key re-decide under the lock.
- `walq tail` no longer blocks compaction.
## 0.4.2

- Throughput work for busy queues: less log growth and fewer syncs in the common paths.
- Lower memory use when a process catches up.

## 0.4.1

- `cancel()` and `requeueDead()`.
- Job priorities.
- `metrics()` and the `metrics` command.

## 0.4.0

- Smaller snapshots.
- Worker pools replace dead workers automatically.
- Failpoints for crash testing.

## 0.3.0

- Idempotency keys.
- Automatic compaction past `compactAfterBytes`.

## 0.2.0

- Multi-process access through a shared lock. Workers became child processes.

## 0.1.0

- First version: one process, one log.
