# Compaction

The log only grows, so from time to time it's replaced by a shorter one that says the same thing: a new header with the next generation, and one `snapshot` record (followed by `snapshot-more` records if the state is too big for one frame).

## When

- `compact()` runs it on request.
- After any write, automatically, when the log has passed `compactAfterBytes` and has at least doubled since the last snapshot, so a live state larger than the threshold is not rewritten on every write. After a failure the next attempt waits for another `compactAfterBytes` of growth.

A failed automatic compaction doesn't fail the call that triggered it, because that call has already committed. `stats().lastCompactionError` shows the last failure.

## How

Compaction runs under the queue lock, after catching up, so the state it writes is complete.

1. Build the snapshot from the current state, dropping finished jobs past `retainCompletedMs`.
2. Write the header and snapshot to `wal.log.compact` (an earlier leftover is overwritten) and sync it.
3. Rename it over `wal.log`. If another process has `wal.log` open and the platform refuses (`EPERM`, `EACCES`, `EBUSY`), the old log is renamed to `wal.log.old.<generation>` first, the new one renamed in, and the old one removed.
4. Sync, and rebuild this process's state from the snapshot.

Opening a queue (under the lock) finishes any compaction that was cut short: if `wal.log` is missing the newest `wal.log.old.*` is put back, and leftovers are removed.

## What the snapshot holds

The jobs that are kept in full (including `priority`, `attempts` and `fence`), the idempotency keys still within their time to live, and the counters the log needs to carry on. See [guarantees.md](guarantees.md), G10 and G11.

## Other processes

A process that was reading the old log sees a different generation next time it catches up, and starts again from the new one, whatever the sizes of the two files.