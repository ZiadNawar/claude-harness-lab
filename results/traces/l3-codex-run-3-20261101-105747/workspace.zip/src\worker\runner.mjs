// JobRunner: the loop a worker process runs. Claim a job, run its handler with a
// heartbeat going, then record the outcome.

import { sleep } from '../clock.mjs';
import { QueueClosedError, StaleLeaseError, UnknownJobError, WalqError } from '../errors.mjs';
import { hit } from '../failpoints.mjs';
import { JOB_COMPLETED, JOB_FAILED, JOB_FENCED, JOB_STARTED, WORKER_ERROR } from './protocol.mjs';
import { runWithTimeout } from './registry.mjs';

const REPORT_RETRY_MAX_MS = 500;

export class JobRunner {
  constructor({ queue, workerId, handlers, leaseMs, heartbeatMs, pollMs = 20, types = null, emit = () => {} }) {
    this.queue = queue;
    this.workerId = workerId;
    this.handlers = handlers;
    this.leaseMs = leaseMs ?? queue.config.leaseMs;
    this.heartbeatMs = heartbeatMs ?? Math.max(10, Math.floor(this.leaseMs / 3));
    this.pollMs = pollMs;
    this.types = types;
    this.emit = emit;
    this.stopping = false;
  }

  stop() {
    this.stopping = true;
  }

  async run() {
    while (!this.stopping) {
      const job = this.#claimNext();
      if (job) await this.execute(job);
      else await sleep(this.pollMs);
    }
  }

  #claimNext() {
    try {
      return this.queue.claim(this.workerId, { leaseMs: this.leaseMs, types: this.types });
    } catch (err) {
      if (!(err instanceof WalqError)) throw err;
      this.emit({ kind: WORKER_ERROR, error: err.message });
      return null;
    }
  }

  async execute(job) {
    const { id, token } = job;
    hit('job.before-handler', { id });
    this.emit({ kind: JOB_STARTED, id, attempt: job.attempt, token });

    const abort = new AbortController();
    const beat = setInterval(() => {
      try {
        this.queue.heartbeat(id, token, { leaseMs: this.leaseMs });
      } catch (err) {
        if (err instanceof StaleLeaseError) {
          clearInterval(beat);
          abort.abort();
        } else {
          this.emit({ kind: WORKER_ERROR, error: err.message });
        }
      }
    }, this.heartbeatMs);

    let outcome;
    let handled = false;
    try {
      const handler = this.handlers.get(job.type);
      if (!handler) throw new Error(`no handler for job type ${job.type}`);
      const result = await runWithTimeout(
        handler,
        job.payload,
        { id, attempt: job.attempt, token, workerId: this.workerId, signal: abort.signal },
        abort,
      );
      handled = true;
      outcome = { call: () => this.queue.complete(id, token, result), kind: JOB_COMPLETED };
    } catch (err) {
      outcome = { call: () => this.queue.fail(id, token, err), kind: JOB_FAILED, cause: err };
    }

    if (handled) hit('job.after-handler', { id });
    try {
      await this.#report(id, outcome);
    } finally {
      clearInterval(beat);
    }
    hit('job.after-complete', { id });
  }

  // Once the handler has finished, recording the outcome comes before anything
  // else, so a failure to record it (a busy queue, a disk error) is retried until
  // it works or the job turns out to belong to someone else. The heartbeat keeps
  // running meanwhile, and no other job is started. A fenced worker has lost the
  // job: that is an expected end for this attempt, not an error.
  async #report(id, { call, kind, cause }) {
    for (let delayMs = this.pollMs; ; delayMs = Math.min(delayMs * 2, REPORT_RETRY_MAX_MS)) {
      try {
        call();
        this.emit({ kind, id, error: cause?.message });
        return;
      } catch (err) {
        if (err instanceof StaleLeaseError || err instanceof UnknownJobError) {
          this.emit({ kind: JOB_FENCED, id });
          return;
        }
        this.emit({ kind: WORKER_ERROR, id, error: err.message });
        if (err instanceof QueueClosedError) return;
      }
      await sleep(delayMs);
    }
  }
}