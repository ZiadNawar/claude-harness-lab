// The log file itself: a header, then checksummed frames, written only by the
// process holding the queue lock.

import path from 'node:path';
import { decodeHeader, encodeFrame, encodeHeader, HEADER_SIZE, scanFrames } from './frame.mjs';
import { hit, isArmed } from './failpoints.mjs';

// Bounds memory when a process has fallen far behind. A scan reads the file in
// pieces of this size, and in one piece when a single frame is larger.
const SCAN_CHUNK = 1024 * 1024;

export class Wal {
  constructor(file, ops) {
    this.file = file;
    this.ops = ops;
  }

  exists() {
    return this.ops.exists(this.file);
  }

  /** Creates an empty log. The header appears atomically, and durably, or not at all. */
  create(generation = 1) {
    const staging = `${this.file}.init`;
    this.ops.create(staging);
    this.ops.writeAt(staging, encodeHeader(generation), 0);
    this.ops.sync(staging);
    this.ops.rename(staging, this.file);
    hit('wal.after-create', {});
    this.ops.sync(this.file);
    this.ops.syncDir(path.dirname(this.file));
  }

  readHeader() {
    return decodeHeader(this.ops.read(this.file, 0, HEADER_SIZE), this.file);
  }

  size() {
    return this.ops.size(this.file);
  }

  /**
   * Decodes everything from `offset` to the end of the file, handing the frames to
   * `visit(frames, end)` a piece at a time, where `end` is the offset after them.
   * Returns where the good frames end and the torn `tail` after them, if any.
   * Throws CorruptLogError for damage that has valid records after it.
   */
  scanFrom(offset, visit) {
    const size = this.ops.size(this.file);
    let position = offset;
    let want = SCAN_CHUNK;
    while (position < size) {
      const length = Math.min(want, size - position);
      const bytes = this.ops.read(this.file, position, length);
      const atEnd = position + length >= size;
      const scan = scanFrames(bytes, position, { atEnd });
      if (scan.frames.length) visit(scan.frames, scan.end);
      position = scan.end;
      if (scan.tail) return { end: position, tail: scan.tail };
      if (scan.needAll) want = size - position;
      else if (scan.need) want = Math.max(scan.need, SCAN_CHUNK);
      else want = SCAN_CHUNK;
    }
    return { end: position, tail: null };
  }

  truncate(length) {
    this.ops.truncate(this.file, length);
  }

  /**
   * Writes records at the end of the file. Returns the new end offset. If the
   * write fails, whatever part of it reached the file is cut off again, so that a
   * call which reported an error leaves nothing behind.
   */
  append(records, { sync = true } = {}) {
    const type = records[0]?.t;
    const bytes = Buffer.concat(records.map(encodeFrame));
    const at = this.ops.size(this.file);
    try {
      hit('wal.before-append', { type });
      if (isArmed('wal.mid-append')) {
        const half = bytes.length >> 1;
        this.ops.writeAt(this.file, bytes.subarray(0, half), at);
        hit('wal.mid-append', { type });
        this.ops.writeAt(this.file, bytes.subarray(half), at + half);
      } else {
        this.ops.writeAt(this.file, bytes, at);
      }
      hit('wal.after-write', { type });
      if (sync) this.ops.sync(this.file);
    } catch (err) {
      this.#undo(at, err);
      throw err;
    }
    hit('wal.after-fsync', { type });
    return at + bytes.length;
  }

  #undo(length, cause) {
    try {
      this.ops.truncate(this.file, length);
    } catch (err) {
      cause.message += ` (and the partial write could not be removed: ${err.message})`;
    }
  }
}