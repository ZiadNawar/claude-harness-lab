// Runs one queue operation under the power-loss model, for tests that arm a kill
// failpoint. Usage: crash-child.mjs <dir> <op> [id] [token]

import { openQueue } from '../../src/index.mjs';

const [dir, op, id, token] = process.argv.slice(2);
const queue = openQueue(dir, { compactAfterBytes: 0 });

if (op === 'compact') queue.compact();
else if (op === 'complete') queue.complete(id, Number(token), { by: 'child' });
else if (op === 'complete-then-die') {
  queue.complete(id, Number(token), { by: 'child' });
  process.kill(process.pid, 'SIGKILL');
} else if (op === 'heartbeat-then-die') {
  queue.heartbeat(id, Number(token), { leaseMs: 60_000 });
  process.kill(process.pid, 'SIGKILL');
} else if (op === 'enqueue') queue.enqueue('from-child', { pid: process.pid });
else if (op === 'claim') queue.claim('child');
else if (op !== 'open') throw new Error(`unknown op ${op}`);

queue.close();
