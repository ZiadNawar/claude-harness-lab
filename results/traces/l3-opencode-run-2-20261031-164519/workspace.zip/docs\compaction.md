# Compaction

The log only grows, so from time to time it's replaced by a shorter one that says the same thing: a new header with the next generation, and one `snapshot` record.

## When

- `compact()` runs it on request.
- After any write, automatically, when the log has passed `compactAfterBytes` and has also at least doubled since the last compaction. The second condition keeps a live state bigger than `compactAfterBytes` from being rewritten on every write.

A failed automatic compaction doesn't fail the call that triggered it, because that call has already committed. `stats().lastCompactionError` shows the last failure. After a failure the next attempt waits until the log has grown by at least a quarter of `compactAfterBytes` and by half its size.

## How

Compaction runs under the queue lock, after catching up, so the state it writes is complete.

1. Build the snapshot from the current state, dropping finished jobs past `retainCompletedMs`.
2. Remove any `wal.log.compact` left by an earlier compaction (we hold the lock, so it is nobody's), then write the header and snapshot to it and sync it.
3. Rename it over `wal.log`, and sync the directory.
4. Rebuild this process's state from the snapshot.

The file is synced before the rename; otherwise a power cut just after it could leave a log with the right name and no content. On failure the temp file is removed. Windows does not let a rename replace a file that another program holds open (a backup, an editor); the compaction then fails, leaves everything as it was, and is tried again later.

## What the snapshot holds

The jobs that are kept with all of their fields, the counters the log needs to carry on, and the idempotency keys still within their time to live, including those of jobs that were pruned. See [guarantees.md](guarantees.md), G10 and G11.

## Other processes

A process that was reading the old log sees that the generation in the header has changed (whatever the new size) and starts again from the new log.
