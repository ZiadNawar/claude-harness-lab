import assert from 'node:assert/strict';
import { fork } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import { test } from 'node:test';
import { fileURLToPath } from 'node:url';
import { CorruptLogError, ManualClock, openQueue } from '../src/index.mjs';
import { encodeFrame } from '../src/frame.mjs';
import { defer, tempDir } from './helpers/tmp.mjs';

const CHILD = fileURLToPath(new URL('./helpers/crash-child.mjs', import.meta.url));

function runChild(t, dir, failpoints, ...args) {
  const markers = tempDir(t);
  const child = fork(CHILD, [dir, ...args], {
    env: {
      ...process.env,
      WALQ_SIMULATE_POWER_LOSS: '1',
      WALQ_FAILPOINTS: failpoints,
      WALQ_FAILPOINT_DIR: markers,
    },
    silent: true,
  });
  defer(t, () => child.kill());
  return new Promise((resolve) =>
    child.on('exit', (code, signal) =>
      resolve({ code, signal, hit: fs.readdirSync(markers).some((f) => f.endsWith('.hit')) }),
    ),
  );
}

function seedClaimed(t, extra = {}) {
  const dir = tempDir(t);
  const clock = new ManualClock(1_000);
  const queue = openQueue(dir, { clock, ...extra });
  const { id } = queue.enqueue('x', 'payload');
  const job = queue.claim('w1', { leaseMs: 1_000 });
  queue.close();
  return { dir, clock, id, token: job.token, log: path.join(dir, 'wal.log') };
}

// --- torn tails (G2, G3) ---------------------------------------------------

for (const [name, garbage] of [
  ['zeros', () => Buffer.alloc(300)],
  ['random bytes', () => Buffer.from(Array.from({ length: 77 }, (_, i) => (i * 37 + 11) & 0xff))],
  ['a frame with a wrong checksum', () => {
    const frame = encodeFrame({ t: 'enqueue', id: 'j99', type: 'x', payload: 1, at: 1 });
    frame[frame.length - 1] ^= 0x55;
    return frame;
  }],
  ['half a frame', () => encodeFrame({ t: 'enqueue', id: 'j99', type: 'x', payload: 'p'.repeat(100), at: 1 }).subarray(0, 60)],
  ['a frame header with an absurd length', () => Buffer.from([0xad, 0xfb, 0xff, 0xff, 0xff, 0xff, 1, 2, 3, 4, 5])],
]) {
  test(`a tail of ${name} is dropped, and later writes survive another reopen`, (t) => {
    const { dir, clock, log } = seedClaimed(t);
    const good = fs.readFileSync(log);
    fs.appendFileSync(log, garbage());
    const queue = openQueue(dir, { clock });
    assert.equal(queue.stats().total, 1);
    assert.equal(queue.stats().tornTailsDropped, 1);
    queue.enqueue('x', 'after the tear');
    queue.close();
    assert.ok(fs.readFileSync(log).subarray(0, good.length).equals(good), 'earlier bytes untouched');

    const again = openQueue(dir, { clock });
    assert.deepEqual(again.listJobs().map((j) => j.payload), ['payload', 'after the tear']);
    assert.equal(again.stats().tornTailsDropped, 0);
  });
}

test('damage inside acknowledged data is reported with its offset and the file is left alone', (t) => {
  const { dir, clock, log } = seedClaimed(t);
  const queue = openQueue(dir, { clock });
  queue.enqueue('x', 'second');
  queue.enqueue('x', 'third');
  queue.close();
  const bytes = fs.readFileSync(log);
  const first = 20; // header size: the first frame starts here
  bytes[first + 14] ^= 0xff; // inside the first frame's payload
  fs.writeFileSync(log, bytes);
  assert.throws(
    () => openQueue(dir, { clock }),
    (err) => err instanceof CorruptLogError && err.offset === first,
  );
  assert.ok(fs.readFileSync(log).equals(bytes), 'the log must not be modified');
});

test('a corrupted length field that swallows later records is damage, not a tail', (t) => {
  const { dir, clock, log } = seedClaimed(t);
  const queue = openQueue(dir, { clock });
  queue.enqueue('x', 'second');
  queue.close();
  const bytes = fs.readFileSync(log);
  bytes.writeUInt32LE(bytes.length * 2, 20 + 2);
  fs.writeFileSync(log, bytes);
  assert.throws(() => openQueue(dir, { clock }), CorruptLogError);
  assert.ok(fs.readFileSync(log).equals(bytes));
});

// --- size (G5) -------------------------------------------------------------

test('records and logs bigger than the read chunk are read in full', (t) => {
  const dir = tempDir(t);
  const clock = new ManualClock(1);
  const queue = openQueue(dir, { clock, compactAfterBytes: 0 });
  const big = 'x'.repeat(3 * 1024 * 1024 + 17);
  for (let i = 0; i < 40; i += 1) queue.enqueue('x', { i, pad: 'y'.repeat(60_000) });
  queue.enqueue('x', big);
  for (let i = 0; i < 40; i += 1) queue.enqueue('x', { i: 40 + i, pad: 'z'.repeat(60_000) });
  queue.close();
  assert.ok(fs.statSync(path.join(dir, 'wal.log')).size > 6 * 1024 * 1024);

  const reopened = openQueue(dir, { clock, compactAfterBytes: 0 });
  assert.equal(reopened.stats().total, 81);
  assert.equal(reopened.stats().tornTailsDropped, 0);
  assert.equal(reopened.getJob('j41').payload.length, big.length);
  const second = openQueue(dir, { clock, compactAfterBytes: 0 });
  second.enqueue('x', 'tail');
  assert.equal(reopened.stats().total, 82);
  assert.equal(reopened.compact().jobs, 82);
  assert.equal(openQueue(dir, { clock }).stats().total, 82);
});

test('a record over the format limit is refused and does not damage the log', (t) => {
  const dir = tempDir(t);
  const queue = openQueue(dir, { compactAfterBytes: 0 });
  queue.enqueue('x', 'fine');
  assert.throws(() => queue.enqueue('x', 'b'.repeat(65 * 1024 * 1024)), /limit/);
  queue.enqueue('x', 'still fine');
  queue.close();
  assert.equal(openQueue(dir).stats().total, 2);
});

// --- power loss (G1, G2, RFC 007 crash table) -------------------------------

test('power loss while a log is first created leaves something that opens', async (t) => {
  const dir = tempDir(t);
  const result = await runChild(t, dir, 'wal.after-create=kill', 'open');
  assert.ok(result.hit);
  const queue = openQueue(dir);
  assert.equal(queue.stats().total, 0);
});

for (const point of ['compact.after-tmp-write', 'compact.before-rename', 'compact.after-rename']) {
  test(`power loss at ${point} loses nothing, and compaction works afterwards`, async (t) => {
    const { dir, clock, id } = seedClaimed(t);
    const queue = openQueue(dir, { clock });
    queue.enqueue('x', 'two');
    queue.close();
    const result = await runChild(t, dir, `${point}=kill`, 'compact');
    assert.ok(result.hit);
    const reopened = openQueue(dir, { clock });
    assert.deepEqual(reopened.listJobs().map((j) => j.payload), ['payload', 'two']);
    assert.equal(reopened.getJob(id).status, 'leased');
    assert.equal(reopened.compact().jobs, 2);
    assert.ok(!fs.existsSync(path.join(dir, 'wal.log.compact')));
    assert.deepEqual(openQueue(dir, { clock }).listJobs().map((j) => j.payload), ['payload', 'two']);
  });
}

for (const [point, committed] of [
  ['wal.before-append#complete', false],
  ['wal.mid-append#complete', false],
  ['wal.after-write#complete', false],
  ['wal.after-fsync#complete', true],
]) {
  test(`a worker lost at ${point} ${committed ? 'has committed' : 'has not committed'}`, async (t) => {
    const { dir, clock, id, token } = seedClaimed(t);
    const result = await runChild(t, dir, `${point}=kill`, 'complete', id, String(token));
    assert.ok(result.hit);
    const queue = openQueue(dir, { clock });
    if (committed) {
      assert.equal(queue.getJob(id).status, 'done');
      assert.equal(queue.reapExpired().length, 0);
      assert.equal(queue.claim('w2'), null);
      assert.equal(queue.complete(id, token, 'ignored').outcome, 'already-committed');
    } else {
      assert.equal(queue.getJob(id).status, 'leased');
      clock.advance(2_000);
      assert.equal(queue.reapExpired().length, 1);
      clock.advance(60_000);
      assert.equal(queue.claim('w2').id, id);
    }
  });
}

test('an acknowledged complete is durable even if the process dies right after', async (t) => {
  const { dir, clock, id, token } = seedClaimed(t);
  const result = await runChild(t, dir, '', 'complete-then-die', id, String(token));
  assert.notEqual(result.code, 0, 'the child was killed');
  assert.equal(openQueue(dir, { clock }).getJob(id).status, 'done');
});

test('an acknowledged heartbeat does not need to be synced, but never corrupts the log', async (t) => {
  const { dir, clock, id, token } = seedClaimed(t);
  const result = await runChild(t, dir, '', 'heartbeat-then-die', id, String(token));
  assert.notEqual(result.code, 0, 'the child was killed');
  const queue = openQueue(dir, { clock });
  assert.equal(queue.getJob(id).status, 'leased');
  assert.equal(queue.getJob(id).lease.until, 1_000 + 1_000);
});

