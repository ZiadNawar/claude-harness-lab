// JobRunner: the loop a worker process runs. Claim a job, run its handler with a
// heartbeat going, then record the outcome.

import { sleep } from '../clock.mjs';
import { QueueClosedError, StaleLeaseError, UnknownJobError, WalqError } from '../errors.mjs';
import { hit } from '../failpoints.mjs';
import { JOB_COMPLETED, JOB_FAILED, JOB_FENCED, JOB_STARTED, WORKER_ERROR } from './protocol.mjs';
import { runWithTimeout } from './registry.mjs';

const RECORD_RETRY_MS = 50;

export class JobRunner {
  constructor({ queue, workerId, handlers, leaseMs, heartbeatMs, pollMs = 20, types = null, emit = () => {} }) {
    this.queue = queue;
    this.workerId = workerId;
    this.handlers = handlers;
    this.leaseMs = leaseMs ?? queue.config.leaseMs;
    this.heartbeatMs = heartbeatMs ?? Math.max(10, Math.floor(this.leaseMs / 3));
    this.pollMs = pollMs;
    this.types = types;
    this.emit = emit;
    this.stopping = false;
  }

  stop() {
    this.stopping = true;
  }

  async run() {
    while (!this.stopping) {
      const job = this.#claimNext();
      if (job) await this.execute(job);
      else await sleep(this.pollMs);
    }
  }

  #claimNext() {
    try {
      return this.queue.claim(this.workerId, { leaseMs: this.leaseMs, types: this.types });
    } catch (err) {
      if (!(err instanceof WalqError)) throw err;
      this.emit({ kind: WORKER_ERROR, error: err.message });
      return null;
    }
  }

  async execute(job) {
    const { id, token } = job;
    hit('job.before-handler', { id });
    this.emit({ kind: JOB_STARTED, id, attempt: job.attempt, token });

    const abort = new AbortController();
    // The heartbeat runs until the outcome is recorded, not just until the handler
    // returns: recording can take a while, and the lease must hold meanwhile.
    const beat = setInterval(() => {
      try {
        this.queue.heartbeat(id, token, { leaseMs: this.leaseMs });
      } catch (err) {
        if (err instanceof StaleLeaseError) {
          clearInterval(beat);
          abort.abort();
        } else {
          this.emit({ kind: WORKER_ERROR, error: err.message });
        }
      }
    }, this.heartbeatMs);

    try {
      let result;
      try {
        const handler = this.handlers.get(job.type);
        if (!handler) throw new Error(`no handler for job type ${job.type}`);
        result = await runWithTimeout(
          handler,
          job.payload,
          { id, attempt: job.attempt, token, workerId: this.workerId, signal: abort.signal },
          abort,
        );
      } catch (err) {
        await this.#reportFailure(id, token, err);
        return;
      }

      hit('job.after-handler', { id });
      await this.#commit(id, token, result);
      hit('job.after-complete', { id });
    } finally {
      clearInterval(beat);
    }
  }

  // A fenced worker has lost the job to someone else. That is an expected end for
  // this attempt, not an error.
  async #reportFailure(id, token, cause) {
    try {
      this.queue.fail(id, token, cause);
      this.emit({ kind: JOB_FAILED, id, error: cause?.message });
    } catch (err) {
      if (err instanceof StaleLeaseError || err instanceof UnknownJobError) {
        this.emit({ kind: JOB_FENCED, id });
      } else {
        // The lease will run out and the job will be tried again.
        this.emit({ kind: WORKER_ERROR, id, error: err.message });
      }
    }
  }

  // The handler has returned, so its result is worth more than anything else this
  // worker could do. Keep trying until the commit is recorded or the job is lost.
  // A commit that was written but not confirmed shows up as 'already-committed'.
  async #commit(id, token, result) {
    for (;;) {
      try {
        const receipt = this.queue.complete(id, token, result);
        this.emit({ kind: JOB_COMPLETED, id, outcome: receipt.outcome });
        return;
      } catch (err) {
        if (err instanceof StaleLeaseError || err instanceof UnknownJobError) {
          this.emit({ kind: JOB_FENCED, id });
          return;
        }
        this.emit({ kind: WORKER_ERROR, id, error: err.message });
        if (err instanceof QueueClosedError) return;
        await sleep(RECORD_RETRY_MS);
      }
    }
  }
}
