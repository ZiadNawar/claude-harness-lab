// The log file itself: a header, then checksummed frames, written only by the
// process holding the queue lock.

import path from 'node:path';
import { decodeHeader, encodeFrame, encodeHeader, HEADER_SIZE, scanFrames } from './frame.mjs';
import { hit, isArmed } from './failpoints.mjs';

// Bounds memory when a process has fallen far behind: the log is read and
// applied a chunk at a time. A frame bigger than a chunk is read whole.
const SCAN_CHUNK = 1024 * 1024;

export class Wal {
  constructor(file, ops) {
    this.file = file;
    this.ops = ops;
  }

  exists() {
    return this.ops.exists(this.file);
  }

  /**
   * Creates an empty log. The header is synced before the file gets its final
   * name, so the log appears complete or not at all, even across power loss.
   */
  create(generation = 1) {
    const staging = `${this.file}.init`;
    this.ops.create(staging);
    this.ops.writeAt(staging, encodeHeader(generation), 0);
    this.ops.sync(staging);
    this.ops.rename(staging, this.file);
    hit('wal.after-create', {});
    this.ops.syncDir(path.dirname(this.file));
  }

  readHeader() {
    return decodeHeader(this.ops.read(this.file, 0, HEADER_SIZE), this.file);
  }

  /**
   * Decodes everything from `offset` to the end of the file, passing the frames
   * to `visit` a chunk at a time. Returns where the last good frame ends and the
   * incomplete tail after it, if any (see scanFrames).
   */
  scanFrom(offset, visit) {
    const size = this.ops.size(this.file);
    let pos = offset;
    let want = SCAN_CHUNK;
    for (;;) {
      const bytes = this.ops.read(this.file, pos, want);
      const atEnd = pos + bytes.length >= size;
      const scan = scanFrames(bytes, pos);
      if (scan.frames.length) visit(scan.frames);
      pos = scan.end;
      if (atEnd) return { end: pos, tail: scan.tail };
      if (!scan.tail) {
        want = SCAN_CHUNK;
      } else if (scan.tail.reason === 'partial' && scan.tail.needed) {
        want = Math.max(scan.tail.needed, SCAN_CHUNK);
      } else if (scan.tail.reason === 'partial') {
        want = SCAN_CHUNK;
      } else {
        // The chunk ended before the file did, so whether this is a torn tail
        // or damage depends on what follows. Look at all of it.
        want = Infinity;
      }
    }
  }

  truncate(length) {
    this.ops.truncate(this.file, length);
  }

  /** Writes records at `at`, the end of the good log. Returns the new end offset. */
  append(records, { sync = true, at } = {}) {
    const type = records[0]?.t;
    const bytes = Buffer.concat(records.map(encodeFrame));
    hit('wal.before-append', { type });
    if (isArmed('wal.mid-append')) {
      const half = bytes.length >> 1;
      this.ops.writeAt(this.file, bytes.subarray(0, half), at);
      hit('wal.mid-append', { type });
      this.ops.writeAt(this.file, bytes.subarray(half), at + half);
    } else {
      this.ops.writeAt(this.file, bytes, at);
    }
    hit('wal.after-write', { type });
    if (sync) this.ops.sync(this.file);
    hit('wal.after-fsync', { type });
    return at + bytes.length;
  }
}
