# Changelog

## 0.5.0

- RFC 007: `complete()` returns a receipt; `getResult()`, `completions()`, `reclaimWorker()`; the `release` record; pools reclaim dead workers' leases at once; workers keep retrying a finished job's commit.
- Fix: a queue now reopens after a crash or power loss. Torn tails of any shape are dropped and removed; damage inside the log is reported as `CorruptLogError` and never repaired. Log creation and compaction sync before they rename.
- Fix: `complete()` is durable when it returns.
- Fix: claim, reap and key checks are decided under the lock, so racing processes no longer double-claim, reap live jobs, or create two jobs for one key. Tokens are checked, and never reused.
- Fix: heartbeats are logged, so a live worker keeps its job whichever process reaps.
- Fix: snapshots keep `attempts`, `fence`, `priority` and idempotency keys; retry due times no longer move on replay.
- Fix: compaction removes stale temp files, follows generation changes, and no longer rewrites a big live state on every write. `walq tail` no longer holds the log open.
- Fix: catching up reads the whole log, not its first megabyte; records bigger than a chunk work; oversize records are refused.
- Cancelled jobs are pruned after `retainCompletedMs` like other finished jobs.
## 0.4.2

- Throughput work for busy queues: less log growth and fewer syncs in the common paths.
- Lower memory use when a process catches up.

## 0.4.1

- `cancel()` and `requeueDead()`.
- Job priorities.
- `metrics()` and the `metrics` command.

## 0.4.0

- Smaller snapshots.
- Worker pools replace dead workers automatically.
- Failpoints for crash testing.

## 0.3.0

- Idempotency keys.
- Automatic compaction past `compactAfterBytes`.

## 0.2.0

- Multi-process access through a shared lock. Workers became child processes.

## 0.1.0

- First version: one process, one log.
