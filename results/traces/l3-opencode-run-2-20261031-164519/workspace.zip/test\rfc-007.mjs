﻿import assert from 'node:assert/strict';
import path from 'node:path';
import { test } from 'node:test';
import { fileURLToPath } from 'node:url';
import {
  JobRunner,
  LockTimeoutError,
  ManualClock,
  openQueue,
  StaleLeaseError,
  UnknownJobError,
  WorkerPool,
} from '../src/index.mjs';
import { defer, readLedger, tempDir } from './helpers/tmp.mjs';

const HANDLERS = fileURLToPath(new URL('./helpers/handlers.mjs', import.meta.url));
const OPTIONS = { backoff: { baseMs: 100, factor: 2, maxMs: 10_000 }, compactAfterBytes: 0 };

function setup(t, extra = {}) {
  const clock = new ManualClock(1_000);
  const dir = tempDir(t);
  const options = { clock, ...OPTIONS, ...extra };
  return { clock, dir, options, queue: openQueue(dir, options) };
}

function finish(queue, result = 'r') {
  const { id } = queue.enqueue('x', null);
  const job = queue.claim('w');
  return { id, job, receipt: queue.complete(id, job.token, result) };
}

// --- complete() and receipts ------------------------------------------------

test('the first commit returns a receipt, a repeat returns the same one and writes nothing', (t) => {
  const { queue, dir, options } = setup(t);
  const { id, job, receipt } = finish(queue, { v: 1 });
  assert.deepEqual(receipt, {
    id,
    outcome: 'committed',
    token: job.token,
    result: { v: 1 },
    completedAt: 1_000,
    completionSeq: 1,
  });
  const size = queue.stats().logBytes;
  const again = queue.complete(id, job.token, { v: 'ignored' });
  assert.deepEqual(again, { ...receipt, outcome: 'already-committed' });
  assert.equal(queue.stats().logBytes, size);

  queue.compact();
  assert.equal(queue.complete(id, job.token, 'x').outcome, 'already-committed');
  const reopened = openQueue(dir, options);
  assert.deepEqual(reopened.complete(id, job.token, 'x'), { ...receipt, outcome: 'already-committed' });
});

test('another token, or a pruned job, is refused', (t) => {
  const { queue, clock } = setup(t, { retainCompletedMs: 1_000 });
  const { id, job } = finish(queue);
  assert.throws(() => queue.complete(id, job.token + 1, 'x'), StaleLeaseError);
  assert.throws(() => queue.complete(id, 0, 'x'), StaleLeaseError);
  assert.equal(queue.getJob(id).result, 'r');
  clock.advance(1_000);
  queue.compact();
  assert.throws(() => queue.complete(id, job.token, 'x'), UnknownJobError);
});

test('a cancelled job cannot be completed with its old token', (t) => {
  const { queue } = setup(t);
  const { id } = queue.enqueue('x', null);
  const job = queue.claim('w');
  queue.cancel(id);
  assert.throws(() => queue.complete(id, job.token, 'x'), StaleLeaseError);
});

test('a lease past its deadline can still commit until someone acts on it', (t) => {
  const { queue, clock } = setup(t);
  const { id } = queue.enqueue('x', null);
  const job = queue.claim('w', { leaseMs: 100 });
  clock.advance(10_000);
  assert.equal(queue.complete(id, job.token, 'late but first').outcome, 'committed');

  const { id: other } = queue.enqueue('x', null);
  const second = queue.claim('w', { leaseMs: 100 });
  clock.advance(10_000);
  queue.reapExpired();
  assert.throws(() => queue.complete(other, second.token, 'too late'), StaleLeaseError);
});

test('a commit that was written is never run again, however the worker learns of it', (t) => {
  const { queue, clock } = setup(t);
  const { id } = queue.enqueue('x', null);
  const job = queue.claim('w', { leaseMs: 100 });
  queue.complete(id, job.token, 'r');
  clock.advance(1_000_000);
  assert.deepEqual(queue.reapExpired(), []);
  assert.deepEqual(queue.reclaimWorker('w'), []);
  assert.equal(queue.claim('w2'), null);
  assert.equal(queue.getJob(id).attempts, 1);
});

// --- getResult and completions ---------------------------------------------

test('getResult says what is known about a job', (t) => {
  const { queue } = setup(t);
  const { id, job } = finish(queue, [1, 2]);
  const { id: waiting } = queue.enqueue('x', null);
  assert.deepEqual(queue.getResult(waiting), { id: waiting, status: 'ready' });
  assert.deepEqual(queue.getResult(id), {
    id,
    status: 'done',
    result: [1, 2],
    token: job.token,
    attempts: 1,
    completedAt: 1_000,
    completionSeq: 1,
  });
  assert.equal(queue.getResult('j999'), null);
});

test('completions come in commit order, and numbering survives restarts, compaction and pruning', (t) => {
  const { queue, dir, options, clock } = setup(t, { retainCompletedMs: 5_000 });
  for (const name of ['a', 'b', 'c']) queue.enqueue('x', name);
  const claimed = [queue.claim('w'), queue.claim('w'), queue.claim('w')];
  queue.complete(claimed[2].id, claimed[2].token, 'c');
  queue.complete(claimed[0].id, claimed[0].token, 'a');
  assert.deepEqual(queue.completions().map((c) => [c.seq, c.id, c.result]), [
    [1, claimed[2].id, 'c'],
    [2, claimed[0].id, 'a'],
  ]);
  assert.deepEqual(queue.completions({ after: 1 }).map((c) => c.seq), [2]);
  assert.deepEqual(queue.completions({ limit: 1 }).map((c) => c.seq), [1]);
  assert.deepEqual(Object.keys(queue.completions()[0]).sort(), ['completedAt', 'id', 'result', 'seq', 'token']);

  queue.compact();
  clock.advance(10_000);
  queue.complete(claimed[1].id, claimed[1].token, 'b');
  queue.compact(); // prunes the first two
  const reopened = openQueue(dir, options);
  assert.deepEqual(reopened.completions().map((c) => c.seq), [3]);
  const { id } = finish(reopened);
  assert.deepEqual(reopened.completions({ after: 3 }).map((c) => [c.seq, c.id]), [[4, id]]);
});

// --- reclaimWorker -----------------------------------------------------------

test('reclaimWorker releases a dead worker leases at once, with no backoff', (t) => {
  const { queue, clock } = setup(t);
  const a = queue.enqueue('x', 'a').id;
  const b = queue.enqueue('x', 'b').id;
  const c = queue.enqueue('x', 'c').id;
  const ja = queue.claim('dead-worker', { leaseMs: 60_000 });
  const jb = queue.claim('live-worker', { leaseMs: 60_000 });
  const jc = queue.claim('dead-worker', { leaseMs: 60_000 });
  queue.complete(c, jc.token, 'finished before dying');

  const result = queue.reclaimWorker('dead-worker', { reason: 'host rebooted' });
  assert.deepEqual(result, [{ id: a, status: 'ready' }]);
  assert.equal(queue.getJob(a).lastError, 'host rebooted');
  assert.equal(queue.getJob(a).attempts, 1);
  assert.equal(queue.getJob(a).availableAt, clock.now());
  assert.equal(queue.getJob(b).status, 'leased');
  assert.equal(queue.getJob(c).status, 'done');
  assert.throws(() => queue.heartbeat(a, ja.token), StaleLeaseError);
  assert.throws(() => queue.complete(a, ja.token, 'zombie'), StaleLeaseError);

  const again = queue.claim('w2');
  assert.equal(again.id, a);
  assert.equal(again.attempt, 2);
  assert.notEqual(again.token, ja.token);
  assert.equal(queue.getJob(b).lease.fence, jb.token);
  assert.deepEqual(queue.reclaimWorker('nobody'), []);
});

test('reclaiming a worker whose attempts have run out kills the job', (t) => {
  const { queue, dir, options } = setup(t);
  const { id } = queue.enqueue('x', null, { maxAttempts: 1 });
  queue.claim('w');
  assert.deepEqual(queue.reclaimWorker('w', { reason: 'gone' }), [{ id, status: 'dead' }]);
  assert.equal(openQueue(dir, options).getJob(id).status, 'dead');
  assert.equal(queue.getJob(id).lastError, 'gone');
});

test('a release survives compaction and restart', (t) => {
  const { queue, dir, options } = setup(t);
  const { id } = queue.enqueue('x', null);
  queue.claim('w');
  queue.reclaimWorker('w');
  queue.compact();
  const reopened = openQueue(dir, options);
  assert.equal(reopened.getJob(id).status, 'ready');
  assert.equal(reopened.claim('w2').id, id);
});

// --- the runner --------------------------------------------------------------

function runnerFor(queue, { emitted, handler }) {
  return new JobRunner({
    queue,
    workerId: 'w',
    handlers: new Map([['x', { run: handler ?? (async () => 'result'), timeoutMs: null }]]),
    leaseMs: 60_000,
    heartbeatMs: 10_000,
    pollMs: 5,
    emit: (m) => emitted.push(m),
  });
}

test('a worker whose commit hits a busy queue keeps trying until it is recorded', async (t) => {
  const { queue } = setup(t);
  const { id } = queue.enqueue('x', null);
  queue.enqueue('x', null);
  const real = queue.complete.bind(queue);
  let failures = 2;
  queue.complete = (...args) => {
    if (failures-- > 0) throw new LockTimeoutError('queue.lock', 1);
    return real(...args);
  };
  const emitted = [];
  const job = queue.claim('w', { leaseMs: 60_000 });
  assert.equal(job.id, id);
  await runnerFor(queue, { emitted }).execute(job);
  assert.equal(queue.getJob(id).status, 'done');
  assert.equal(queue.getJob('j2').status, 'ready', 'no other job was started meanwhile');
  assert.equal(emitted.filter((m) => m.kind === 'worker-error').length, 2);
  assert.equal(emitted.at(-1).kind, 'job-completed');
});

test('a commit that was written but not confirmed shows up as already committed', async (t) => {
  const { queue } = setup(t);
  const { id } = queue.enqueue('x', null);
  const real = queue.complete.bind(queue);
  let first = true;
  queue.complete = (...args) => {
    const receipt = real(...args);
    if (first) {
      first = false;
      throw new Error('EIO after the write');
    }
    return receipt;
  };
  const emitted = [];
  await runnerFor(queue, { emitted }).execute(queue.claim('w', { leaseMs: 60_000 }));
  assert.equal(queue.getJob(id).status, 'done');
  assert.equal(queue.getJob(id).attempts, 1);
  assert.equal(emitted.at(-1).outcome, 'already-committed');
});

test('a fenced worker stops, reports job-fenced, and its result is discarded', async (t) => {
  const { queue } = setup(t);
  const { id } = queue.enqueue('x', null);
  const emitted = [];
  const job = queue.claim('w', { leaseMs: 60_000 });
  const runner = runnerFor(queue, {
    emitted,
    handler: async () => {
      queue.reclaimWorker('w');
      queue.claim('other', { leaseMs: 60_000 });
      return 'stale result';
    },
  });
  await runner.execute(job);
  assert.equal(emitted.at(-1).kind, 'job-fenced');
  assert.equal(queue.getJob(id).result, null);
  assert.equal(queue.getJob(id).lease.worker, 'other');
});

// --- the pool ------------------------------------------------------------------

function poolFor(t, dir, options, env = {}) {
  const ledger = path.join(dir, 'runs.jsonl');
  const pool = new WorkerPool({
    dir,
    handlers: HANDLERS,
    pollMs: 5,
    queue: OPTIONS,
    ...options,
    env: { WALQ_TEST_LEDGER: ledger, ...env },
  });
  defer(t, () => pool.stop());
  return { pool, ledger };
}

test('a killed worker is reclaimed at once, not when its long lease runs out', { timeout: 30_000 }, async (t) => {
  const dir = tempDir(t);
  const queue = openQueue(dir, OPTIONS);
  const { pool } = poolFor(
    t,
    dir,
    { size: 1, leaseMs: 120_000 },
    { WALQ_FAILPOINTS: 'job.before-handler=kill', WALQ_FAILPOINT_DIR: tempDir(t) },
  );
  const { id } = queue.enqueue('quick', { n: 1 });
  pool.start();
  await pool.drain({ timeoutMs: 20_000 });
  const job = queue.getJob(id);
  assert.equal(job.status, 'done');
  assert.equal(job.attempts, 2);
  assert.equal(job.lastError, 'worker exited');
});

test('a worker killed after committing does not make the job run again', { timeout: 30_000 }, async (t) => {
  const dir = tempDir(t);
  const queue = openQueue(dir, OPTIONS);
  const { pool, ledger } = poolFor(
    t,
    dir,
    { size: 1, leaseMs: 120_000 },
    { WALQ_FAILPOINTS: 'job.after-complete=kill', WALQ_FAILPOINT_DIR: tempDir(t) },
  );
  const { id } = queue.enqueue('quick', { n: 1 });
  pool.start();
  await pool.drain({ timeoutMs: 20_000 });
  await new Promise((resolve) => setTimeout(resolve, 300));
  assert.equal(readLedger(ledger).filter((e) => e.id === id).length, 1);
  assert.equal(queue.getJob(id).attempts, 1);
  assert.equal(queue.getResult(id).status, 'done');
});

test('a pool only reclaims its own dead workers, even on a shared directory', { timeout: 30_000 }, async (t) => {
  const dir = tempDir(t);
  const queue = openQueue(dir, OPTIONS);
  const a = poolFor(t, dir, { size: 1, leaseMs: 120_000, types: ['slow'] });
  const b = poolFor(
    t,
    dir,
    { size: 1, leaseMs: 120_000, types: ['quick'] },
    { WALQ_FAILPOINTS: 'job.before-handler=kill', WALQ_FAILPOINT_DIR: tempDir(t) },
  );
  assert.notEqual(a.pool.poolId, b.pool.poolId);
  const { id: slow } = queue.enqueue('slow', { ms: 1_500 });
  a.pool.start();
  await new Promise((resolve) => setTimeout(resolve, 400));
  const { id: quick } = queue.enqueue('quick', { n: 1 });
  b.pool.start();
  await Promise.all([a.pool.drain({ timeoutMs: 20_000 }), b.pool.drain({ timeoutMs: 20_000 })]);
  assert.equal(queue.getJob(slow).attempts, 1);
  assert.equal(queue.getJob(quick).attempts, 2);
  assert.equal(readLedger(a.ledger).filter((e) => e.id === slow).length, 1);
});

