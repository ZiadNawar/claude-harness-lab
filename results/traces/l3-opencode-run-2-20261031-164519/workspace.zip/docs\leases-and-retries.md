# Leases and retries

## Leases

`claim()` gives a job to a worker until `leaseUntil`, and hands back a `token`. The token goes on every later call about that attempt. A lease has expired once the clock reaches its deadline.

A worker running a long job calls `heartbeat()`. `JobRunner` does this on a timer, every `leaseMs / 3` by default, until the outcome is recorded. Each heartbeat is a record in the log (not synced: if the machine stops, the worker is gone with it), so a reaper in another process sees it.

When a `WorkerPool` sees a worker exit it does not wait for expiry: `reclaimWorker()` returns that worker's jobs at once, with no backoff (the attempt still counts). Anyone can call `reapExpired()`. It returns expired jobs to the queue with a backoff, or sends them to `dead` when attempts have run out. An expired lease counts as a used attempt.

## Tokens

The token is the job's `fence`, which goes up by one with each claim and is never reset, not even by `requeueDead()`, so a token is never issued twice for a job. A call with a token that isn't current throws `StaleLeaseError`.

## Backoff

After an attempt fails, the job is due again after:

```
delay = min(maxMs, baseMs * factor ^ (attempts - 1))
```

The due time is fixed when the failure is recorded (the record's time plus the delay), so restarts and compaction do not move it. With `jitter` above zero, the delay is reduced by up to that fraction. The reduction is derived from the job id and the attempt number, so that it's reproducible.

## Attempts

`attempts` counts claims. When an attempt ends in failure or expiry with `attempts >= maxAttempts`, the job goes `dead`. `requeueDead()` sets attempts back to zero and makes the job due now.

## Clocks

All processes are on one host and read the same system clock, so clock skew between processes isn't handled.
