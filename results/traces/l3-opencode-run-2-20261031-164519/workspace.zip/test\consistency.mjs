﻿import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { test } from 'node:test';
import { clearFailpoints, ManualClock, onFailpoint, openQueue, StaleLeaseError } from '../src/index.mjs';
import { tempDir } from './helpers/tmp.mjs';

const BACKOFF = { baseMs: 100, factor: 2, maxMs: 10_000 };

// Two instances of one directory stand in for two processes: each has its own
// replayed state and takes the same file lock.
function pair(t, extra = {}) {
  const clock = new ManualClock(1_000);
  const dir = tempDir(t);
  const options = { clock, backoff: BACKOFF, compactAfterBytes: 0, ...extra };
  t.after(clearFailpoints);
  return { clock, dir, options, a: openQueue(dir, options), b: openQueue(dir, options) };
}

test('two claimers racing for one job cannot both get it', (t) => {
  const { a, b } = pair(t);
  a.enqueue('x', 1);
  a.enqueue('x', 2);
  let theirs = null;
  onFailpoint('claim.before-lock', () => {
    clearFailpoints();
    theirs = b.claim('wb');
  });
  const mine = a.claim('wa');
  assert.notEqual(mine.id, theirs.id);
  assert.equal(new Set([mine.token, theirs.token]).size, 1, 'each job has its own first token');
  assert.equal(a.stats().leased, 2);
  assert.equal(a.listJobs().every((j) => j.attempts === 1), true);
});

test('a racing claim on the only job leaves one winner and nothing for the other', (t) => {
  const { a, b } = pair(t);
  a.enqueue('x', 1);
  onFailpoint('claim.before-lock', () => {
    clearFailpoints();
    assert.ok(b.claim('wb'));
  });
  assert.equal(a.claim('wa'), null);
});

test('a heartbeat is seen by another process, so its reaper leaves the job alone', (t) => {
  const { a, b, clock } = pair(t);
  a.enqueue('x', 1);
  const job = a.claim('wa', { leaseMs: 500 });
  clock.advance(400);
  a.heartbeat(job.id, job.token, { leaseMs: 500 });
  clock.advance(400);
  assert.deepEqual(b.reapExpired(), []);
  assert.equal(b.getJob(job.id).lease.until, 1_000 + 400 + 500);
});

test('a reaper that chose a job before its heartbeat landed does not reap it', (t) => {
  const { a, b, clock } = pair(t);
  a.enqueue('x', 1);
  const job = a.claim('wa', { leaseMs: 500 });
  clock.advance(600);
  onFailpoint('reap.before-lock', () => {
    clearFailpoints();
    a.heartbeat(job.id, job.token, { leaseMs: 500 });
  });
  assert.deepEqual(b.reapExpired(), []);
  assert.equal(a.getJob(job.id).status, 'leased');
});

test('a reaper that chose a job before it committed does not bring it back', (t) => {
  const { a, b, clock } = pair(t);
  a.enqueue('x', 1);
  const job = a.claim('wa', { leaseMs: 500 });
  clock.advance(600);
  onFailpoint('reap.before-lock', () => {
    clearFailpoints();
    a.complete(job.id, job.token, 'done');
  });
  assert.deepEqual(b.reapExpired(), []);
  assert.equal(b.getJob(job.id).status, 'done');
  assert.equal(b.claim('wb'), null);
});

test('two reapers do not return the same lease twice', (t) => {
  const { a, b, clock } = pair(t);
  a.enqueue('x', 1);
  a.claim('wa', { leaseMs: 500 });
  clock.advance(600);
  onFailpoint('reap.before-lock', () => {
    clearFailpoints();
    assert.equal(b.reapExpired().length, 1);
  });
  assert.deepEqual(a.reapExpired(), []);
  assert.equal(a.listJobs()[0].attempts, 1);
  const records = fs.readFileSync(path.join(a.dir, 'wal.log'));
  assert.equal(records.toString('latin1').split('"t":"expire"').length - 1, 1);
});

test('a key used by two processes at once makes one job', (t) => {
  const { a, b } = pair(t);
  onFailpoint('enqueue.before-lock', () => {
    clearFailpoints();
    assert.equal(b.enqueue('x', 'b', { key: 'k' }).deduped, false);
  });
  const mine = a.enqueue('x', 'a', { key: 'k' });
  assert.equal(mine.deduped, true);
  assert.equal(a.stats().total, 1);
});

test('an old token has no power over a job that has been claimed again', (t) => {
  const { a, clock } = pair(t);
  a.enqueue('x', 1);
  const first = a.claim('w1', { leaseMs: 100 });
  clock.advance(100);
  a.reapExpired();
  clock.advance(1_000);
  const second = a.claim('w2');
  assert.notEqual(first.token, second.token);
  assert.throws(() => a.heartbeat(first.id, first.token), StaleLeaseError);
  assert.throws(() => a.fail(first.id, first.token, 'late'), StaleLeaseError);
  assert.throws(() => a.complete(first.id, first.token, 'late'), StaleLeaseError);
  assert.equal(a.getJob(first.id).status, 'leased');
  assert.equal(a.complete(second.id, second.token, 'ok').outcome, 'committed');
});

test('tokens are never reused, across requeue, restart and compaction', (t) => {
  const { a, dir, options, clock } = pair(t, { maxAttempts: 1 });
  const { id } = a.enqueue('x', 1);
  const seen = [];
  for (let round = 0; round < 3; round += 1) {
    const job = a.claim('w');
    seen.push(job.token);
    a.fail(job.id, job.token, 'no');
    assert.equal(a.getJob(id).status, 'dead');
    if (round === 0) a.compact();
    if (round === 1) openQueue(dir, options).compact();
    a.requeueDead(id);
    clock.advance(1);
  }
  const reopened = openQueue(dir, options);
  seen.push(reopened.claim('w').token);
  assert.equal(new Set(seen).size, seen.length, `tokens ${seen}`);
});

// --- retries and attempts (G9) ---------------------------------------------

test('a retry keeps its due time across restarts and in every process', (t) => {
  const { a, b, dir, options, clock } = pair(t);
  a.enqueue('x', 1);
  const job = a.claim('w');
  const { retryAt } = a.fail(job.id, job.token, 'boom');
  assert.equal(retryAt, 1_100);
  clock.advance(5_000);
  const late = openQueue(dir, options);
  for (const queue of [a, b, late]) assert.equal(queue.getJob(job.id).availableAt, retryAt);
  assert.equal(late.claim('w2').id, job.id);
});

test('an expiry keeps its due time across compaction', (t) => {
  const { a, clock } = pair(t);
  a.enqueue('x', 1);
  a.claim('w', { leaseMs: 10 });
  clock.advance(10);
  const [{ retryAt }] = a.reapExpired();
  clock.advance(50);
  a.compact();
  assert.equal(a.getJob('j1').availableAt, retryAt);
  assert.equal(a.claim('w'), null);
});

test('attempts and backoff carry through compaction and restarts, so maxAttempts holds', (t) => {
  const { a, dir, options, clock } = pair(t, { maxAttempts: 5 });
  const { id } = a.enqueue('x', 1);
  const delays = [];
  let queue = a;
  for (let attempt = 1; attempt <= 5; attempt += 1) {
    const job = queue.claim('w');
    assert.equal(job.attempt, attempt);
    const outcome = queue.fail(job.id, job.token, `no ${attempt}`);
    if (attempt < 5) delays.push(outcome.retryAt - clock.now());
    else assert.equal(outcome.status, 'dead');
    queue.compact();
    queue = openQueue(dir, options);
    clock.advance(20_000);
  }
  assert.deepEqual(delays, [100, 200, 400, 800]);
  assert.equal(queue.getJob(id).status, 'dead');
  assert.equal(queue.claim('w'), null);
});

test('compaction changes no field of any job', (t) => {
  const { a, clock } = pair(t, { retainCompletedMs: 1e12 });
  a.enqueue('p', { n: 1 }, { priority: 7, maxAttempts: 9, key: 'k1' });
  a.enqueue('q', { n: 2 }, { delayMs: 500 });
  a.enqueue('r', 3, { priority: 2 });
  const j1 = a.claim('w', { leaseMs: 5_000 });
  a.fail(j1.id, j1.token, 'once');
  clock.advance(100);
  const again = a.claim('w2', { leaseMs: 5_000, types: ['p'] });
  a.heartbeat(again.id, again.token, { leaseMs: 9_000 });
  const done = a.claim('w3');
  a.complete(done.id, done.token, { ok: 1 });
  const before = a.listJobs();
  a.compact();
  assert.deepEqual(a.listJobs(), before);
  assert.deepEqual(openQueue(a.dir, a.config).listJobs(), before);
});

test('priority survives compaction', (t) => {
  const { a } = pair(t);
  a.enqueue('x', 'low');
  a.enqueue('x', 'high', { priority: 5 });
  a.compact();
  assert.equal(a.claim('w').payload, 'high');
});

// --- idempotency (G10) -----------------------------------------------------

test('a key outlives its job and many compactions', (t) => {
  const DAY = 24 * 3_600_000;
  const { a, dir, options, clock } = pair(t, { retainCompletedMs: DAY });
  const first = a.enqueue('report', 1, { key: 'monthly' });
  const job = a.claim('w');
  a.complete(job.id, job.token, { sent: 'yes' });
  clock.advance(3 * DAY);
  a.compact();
  assert.equal(a.getJob(first.id), null, 'the job itself is pruned');
  for (let i = 0; i < 3; i += 1) {
    const q = openQueue(dir, options);
    q.enqueue('noise', i);
    q.compact();
  }
  const again = openQueue(dir, options).enqueue('report', 2, { key: 'monthly' });
  assert.equal(again.deduped, true);
  assert.equal(again.id, first.id);
  assert.deepEqual(again.result, { sent: 'yes' });
  assert.equal(again.status, 'done');
});

test('a key is forgotten once its time to live has passed, measured from the enqueue', (t) => {
  const DAY = 24 * 3_600_000;
  const { a, clock } = pair(t, { retainCompletedMs: DAY, idempotencyTtlMs: 7 * DAY });
  a.enqueue('x', 1, { key: 'k' });
  clock.advance(7 * DAY - 1);
  a.compact();
  assert.equal(a.enqueue('x', 2, { key: 'k' }).deduped, true);
  clock.advance(1);
  assert.equal(a.enqueue('x', 3, { key: 'k' }).deduped, false);
  a.compact();
  assert.equal(a.enqueue('x', 4, { key: 'k' }).deduped, true);
});

test('cancelled and dead jobs are pruned past retention, but their keys are kept', (t) => {
  const { a, clock } = pair(t, { retainCompletedMs: 1_000, maxAttempts: 1 });
  const c = a.enqueue('x', 1, { key: 'c' });
  const d = a.enqueue('x', 1, { key: 'd' });
  a.cancel(c.id);
  const job = a.claim('w');
  a.fail(job.id, job.token, 'bad');
  clock.advance(1_000);
  a.compact();
  assert.equal(a.stats().total, 0);
  assert.equal(a.enqueue('x', 2, { key: 'c' }).status, 'cancelled');
  assert.equal(a.enqueue('x', 2, { key: 'd' }).status, 'dead');
  assert.equal(a.enqueue('x', 2, { key: 'd' }).id, d.id);
});

// --- compaction (G12, G13, G14) --------------------------------------------

test('a leftover temp file from a killed compaction does not stop the next one', (t) => {
  const { a, dir } = pair(t);
  a.enqueue('x', 1);
  fs.writeFileSync(path.join(dir, 'wal.log.compact'), 'leftover from a killed compaction');
  assert.equal(a.compact().jobs, 1);
  assert.ok(!fs.existsSync(path.join(dir, 'wal.log.compact')));
});

test('compaction blocked by an open handle fails cleanly, and works once it is released', (t) => {
  const { a, dir, clock } = pair(t, { compactAfterBytes: 400 });
  a.enqueue('x', 'one');
  const log = path.join(dir, 'wal.log');
  const fd = fs.openSync(log, 'r');
  let released = false;
  t.after(() => {
    if (!released) fs.closeSync(fd);
  });
  let blocked = false;
  try {
    a.compact();
  } catch (err) {
    blocked = true;
    assert.match(err.message, /compaction failed/);
    assert.ok(!fs.existsSync(path.join(dir, 'wal.log.compact')), 'no temp file is left behind');
    assert.equal(a.stats().total, 1);
    a.enqueue('x', 'two');
  }
  // Windows refuses to replace a log that another handle holds open.
  assert.ok(blocked || process.platform !== 'win32', 'expected the open log to block compaction');
  fs.closeSync(fd);
  released = true;
  clock.advance(1);
  assert.equal(a.compact().jobs, 2);
  assert.equal(a.stats().lastCompactionError, null);
  assert.equal(openQueue(dir).stats().total, 2);
});
test('automatic compaction that keeps failing does not retry on every write', (t) => {
  const { a, dir } = pair(t, { compactAfterBytes: 1_000 });
  const log = path.join(dir, 'wal.log');
  a.enqueue('x', 'seed');
  const fd = fs.openSync(log, 'r');
  let attempts = 0;
  onFailpoint('compact.before-rename', () => {
    attempts += 1;
  });
  try {
    for (let i = 0; i < 60; i += 1) a.enqueue('x', { i, pad: 'p'.repeat(30) });
  } finally {
    fs.closeSync(fd);
  }
  assert.ok(a.stats().total === 61);
  assert.ok(attempts < 20, `${attempts} compaction attempts for 60 writes`);
  a.enqueue('x', 'later');
  assert.equal(openQueue(dir).stats().total, 62);
});

test('another process follows a compaction even when the new log is bigger than the old one', (t) => {
  const { a, b } = pair(t, { retainCompletedMs: 1e12 });
  for (let i = 0; i < 3; i += 1) a.enqueue('x', i);
  b.stats();
  const readByB = b.store.offset;
  a.compact();
  const job = a.claim('w');
  a.compact();
  const size = fs.statSync(path.join(a.dir, 'wal.log')).size;
  assert.ok(size > readByB, `new log ${size} must be longer than what b had read (${readByB})`);
  assert.equal(b.stats().total, 3);
  assert.equal(b.getJob(job.id).status, 'leased');
  b.enqueue('x', 'from b');
  assert.equal(a.stats().total, 4);
  assert.equal(openQueue(a.dir, a.config).stats().total, 4);
});

test('automatic compaction stays cheap when the live state is bigger than the threshold', (t) => {
  const { dir, clock } = pair(t);
  const queue = openQueue(dir, { clock, compactAfterBytes: 2_000, backoff: BACKOFF });
  for (let i = 0; i < 60; i += 1) queue.enqueue('x', { i, pad: 'p'.repeat(50) });
  const generation = queue.stats().generation;
  assert.ok(queue.stats().logBytes > 2_000, 'the live state is bigger than the threshold');
  for (let i = 0; i < 100; i += 1) {
    const job = queue.claim('w');
    queue.heartbeat(job.id, job.token);
    queue.fail(job.id, job.token, 'again');
    clock.advance(100_000);
  }
  const compactions = queue.stats().generation - generation;
  assert.ok(compactions < 25, `${compactions} compactions for 300 writes`);
  assert.equal(queue.stats().total, 60);
});

test('a log that never compacts on its own is not forced to, with compactAfterBytes 0', (t) => {
  const { a } = pair(t);
  for (let i = 0; i < 100; i += 1) a.enqueue('x', i);
  assert.equal(a.stats().generation, 1);
});


