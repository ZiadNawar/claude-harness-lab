// Replaces the log with a one-record log holding the current state. Runs under
// the queue lock. docs/compaction.md describes the protocol.

import path from 'node:path';
import { encodeFrame, encodeHeader } from './frame.mjs';
import { hit } from './failpoints.mjs';
import { buildSnapshot } from './snapshot.mjs';

export function compactionTempPath(walFile) {
  return `${walFile}.compact`;
}

/**
 * Writes and installs the next generation of the log. Returns the snapshot and
 * the size of the new file. If this throws before the rename, the old log is
 * still in place and the temp file is gone.
 */
export function compactLog({ wal, ops, state, generation, now, config }) {
  const nextGeneration = generation + 1;
  const snapshot = buildSnapshot(state, now, config);
  const bytes = Buffer.concat([encodeHeader(nextGeneration), encodeFrame(snapshot)]);
  const tempPath = compactionTempPath(wal.file);

  try {
    // We hold the queue lock, so any temp file already here is the leftover of a
    // compaction that was killed or failed. Nobody else can be using it.
    ops.unlink(tempPath);
    ops.create(tempPath);
    ops.writeAt(tempPath, bytes, 0);
    // The bytes must be on disk before the file takes the log's name, or a power
    // cut right after the rename leaves a log that is empty.
    ops.sync(tempPath);
    hit('compact.after-tmp-write', { generation: nextGeneration });
    hit('compact.before-rename', { generation: nextGeneration });
    ops.rename(tempPath, wal.file);
    hit('compact.after-rename', { generation: nextGeneration });
    ops.syncDir(path.dirname(wal.file));
  } catch (err) {
    err.message = `compaction failed: ${err.message}`;
    try {
      ops.unlink(tempPath);
    } catch {
      // The next compaction removes it first. The original error is the one to report.
    }
    throw err;
  }

  return { snapshot, generation: nextGeneration, size: bytes.length };
}
