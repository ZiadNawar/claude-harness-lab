// JobRunner: the loop a worker process runs. Claim a job, run its handler with a
// heartbeat going, then record the outcome.

import { sleep } from '../clock.mjs';
import { StaleLeaseError, UnknownJobError, WalqError } from '../errors.mjs';
import { hit } from '../failpoints.mjs';
import { JOB_COMPLETED, JOB_FAILED, JOB_FENCED, JOB_STARTED, WORKER_ERROR } from './protocol.mjs';
import { runWithTimeout } from './registry.mjs';

const REPORT_RETRY_MS = 50;

export class JobRunner {
  constructor({ queue, workerId, handlers, leaseMs, heartbeatMs, pollMs = 20, types = null, emit = () => {} }) {
    this.queue = queue;
    this.workerId = workerId;
    this.handlers = handlers;
    this.leaseMs = leaseMs ?? queue.config.leaseMs;
    this.heartbeatMs = heartbeatMs ?? Math.max(10, Math.floor(this.leaseMs / 3));
    this.pollMs = pollMs;
    this.types = types;
    this.emit = emit;
    this.stopping = false;
  }

  stop() {
    this.stopping = true;
  }

  async run() {
    while (!this.stopping) {
      const job = this.#claimNext();
      if (job) await this.execute(job);
      else await sleep(this.pollMs);
    }
  }

  #claimNext() {
    try {
      return this.queue.claim(this.workerId, { leaseMs: this.leaseMs, types: this.types });
    } catch (err) {
      if (!(err instanceof WalqError)) throw err;
      this.emit({ kind: WORKER_ERROR, error: err.message });
      return null;
    }
  }

  async execute(job) {
    const { id, token } = job;
    hit('job.before-handler', { id });
    this.emit({ kind: JOB_STARTED, id, attempt: job.attempt, token });

    const abort = new AbortController();
    const beat = setInterval(() => {
      try {
        this.queue.heartbeat(id, token, { leaseMs: this.leaseMs });
      } catch (err) {
        if (err instanceof StaleLeaseError || err instanceof UnknownJobError) {
          clearInterval(beat);
          abort.abort();
        } else {
          this.emit({ kind: WORKER_ERROR, error: err.message });
        }
      }
    }, this.heartbeatMs);

    try {
      let result;
      let failure = null;
      try {
        const handler = this.handlers.get(job.type);
        if (!handler) throw new Error(`no handler for job type ${job.type}`);
        result = await runWithTimeout(
          handler,
          job.payload,
          { id, attempt: job.attempt, token, workerId: this.workerId, signal: abort.signal },
          abort,
        );
      } catch (err) {
        failure = err;
      }

      if (failure) {
        await this.#report(id, () => this.queue.fail(id, token, failure), JOB_FAILED, failure);
        return;
      }
      hit('job.after-handler', { id });
      await this.#report(id, () => this.queue.complete(id, token, result), JOB_COMPLETED);
      hit('job.after-complete', { id });
    } finally {
      clearInterval(beat);
    }
  }

  /**
   * Records the outcome of an attempt. The handler has finished, so the outcome
   * matters more than anything else this worker could do: if the queue is busy or
   * the disk fails, keep trying (the heartbeat keeps the lease alive meanwhile)
   * until it is recorded or the lease turns out to be lost.
   */
  async #report(id, call, kind, cause) {
    let lastError = null;
    for (;;) {
      try {
        call();
        this.emit({ kind, id, error: cause?.message });
        return;
      } catch (err) {
        if (err instanceof StaleLeaseError || err instanceof UnknownJobError) {
          this.emit({ kind: JOB_FENCED, id });
          return;
        }
        if (err.message !== lastError) {
          lastError = err.message;
          this.emit({ kind: WORKER_ERROR, id, error: err.message });
        }
        await sleep(REPORT_RETRY_MS);
      }
    }
  }
}
