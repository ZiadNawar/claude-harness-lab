// Replaces the log with a one-record log holding the current state. Runs under
// the queue lock. docs/compaction.md describes the protocol.

import path from 'node:path';
import { encodeFrame, encodeHeader } from './frame.mjs';
import { hit } from './failpoints.mjs';
import { buildSnapshot } from './snapshot.mjs';

export function compactionTempPath(walFile) {
  return `${walFile}.compact`;
}

const REPLACE_BLOCKED = new Set(['EPERM', 'EACCES', 'EBUSY']);

/**
 * Puts the new log in place. Where the platform allows it that is one atomic
 * rename. On Windows a rename over a file that another process holds open (a
 * `walq tail`, a backup) is refused, though moving that file out of the way is
 * not, so then the old log is moved aside first and removed afterwards. A crash
 * between the two renames leaves the old log under the aside name, which
 * Wal.recover() puts back.
 */
function installLog(wal, ops, tempPath) {
  try {
    ops.rename(tempPath, wal.file);
    return;
  } catch (err) {
    if (!REPLACE_BLOCKED.has(err.code)) throw err;
  }
  const aside = wal.asidePath;
  ops.unlink(aside);
  ops.rename(wal.file, aside);
  try {
    ops.rename(tempPath, wal.file);
  } catch (err) {
    ops.rename(aside, wal.file);
    throw err;
  }
  try {
    ops.unlink(aside);
  } catch {
    // Left over, and removed by the next compaction or by recover().
  }
}

/**
 * Writes and installs the next generation of the log. Returns the snapshot and
 * the size of the new file. If this throws, the old log is still in place, or
 * (when only the final syncs failed) the new one is, and every process finds
 * out which by the generation in the header.
 */
export function compactLog({ wal, ops, state, generation, now, config }) {
  const nextGeneration = generation + 1;
  const snapshot = buildSnapshot(state, now, config);
  const bytes = Buffer.concat([encodeHeader(nextGeneration), encodeFrame(snapshot)]);
  const tempPath = compactionTempPath(wal.file);
  let renamed = false;

  try {
    // We hold the queue lock, so nobody else is writing this file: anything
    // already here is left over from a compaction that died.
    ops.unlink(tempPath);
    ops.create(tempPath);
    ops.writeAt(tempPath, bytes, 0);
    // The new log must be on disk before it takes the old one's name, or a power
    // cut right after the rename leaves a log with nothing in it.
    ops.sync(tempPath);
    hit('compact.after-tmp-write', { generation: nextGeneration });
    hit('compact.before-rename', { generation: nextGeneration });
    installLog(wal, ops, tempPath);
    renamed = true;
    hit('compact.after-rename', { generation: nextGeneration });
    ops.sync(wal.file);
    ops.syncDir(path.dirname(wal.file));
  } catch (err) {
    if (!renamed) {
      try {
        ops.unlink(tempPath);
      } catch {
        // The next compaction removes it first. The error that matters is err.
      }
    }
    err.message = `compaction failed: ${err.message}`;
    throw err;
  }

  return { snapshot, generation: nextGeneration, size: bytes.length };
}
