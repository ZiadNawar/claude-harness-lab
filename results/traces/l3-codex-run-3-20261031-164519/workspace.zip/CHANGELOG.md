# Changelog

## 0.5.0

- Exactly-once completion (RFC 007): `complete()` returns a receipt, plus `getResult()`, `completions()`, `reclaimWorker()` and the `release` record. Pools reclaim a dead worker's leases at once, and workers keep retrying to record a finished job.
- Fixed: a torn tail no longer blocks later writes, a cut-off checksum or zero-filled tail opens, and damage in the middle of the log is reported.
- Fixed: heartbeats are logged, claims and reaps decide under the lock, and lease tokens are checked against the current lease.
- Fixed: retry times, attempts, priority and fences survive restart and compaction; `requeueDead()` no longer reissues tokens.
- Fixed: idempotency keys survive pruning and compaction for their whole time to live.
- Fixed: compaction syncs before it renames, clears leftover temp files, works while a tail or backup holds the log open, and processes follow it by generation. Large logs and records are read in full.

## 0.4.2

- Throughput work for busy queues: less log growth and fewer syncs in the common paths.
- Lower memory use when a process catches up.

## 0.4.1

- `cancel()` and `requeueDead()`.
- Job priorities.
- `metrics()` and the `metrics` command.

## 0.4.0

- Smaller snapshots.
- Worker pools replace dead workers automatically.
- Failpoints for crash testing.

## 0.3.0

- Idempotency keys.
- Automatic compaction past `compactAfterBytes`.

## 0.2.0

- Multi-process access through a shared lock. Workers became child processes.

## 0.1.0

- First version: one process, one log.
