#!/usr/bin/env node
// Operator tool.
//
//   node src/cli.mjs inspect <dir>        print every record in the log
//   node src/cli.mjs stats <dir>          print job counts
//   node src/cli.mjs compact <dir>        compact now
//   node src/cli.mjs tail <dir>           follow the log, keeping it open
//   node src/cli.mjs metrics <dir>        print operational numbers
//   node src/cli.mjs requeue <dir> <id>   give a dead job a fresh set of attempts
//   node src/cli.mjs cancel <dir> <id>    stop a job that has not finished

import fs from 'node:fs';
import path from 'node:path';
import { decodeHeader, HEADER_SIZE, scanFrames } from './frame.mjs';
import { describeRecord, inspectLog } from './inspect.mjs';
import { openQueue } from './queue.mjs';
import { WAL_FILE } from './store.mjs';

function usage() {
  console.error('usage: cli.mjs <inspect|stats|compact|tail|metrics|requeue|cancel> <dir> [id]');
  process.exitCode = 2;
}

function inspect(dir) {
  const view = inspectLog(dir);
  console.log(`${view.file}: generation ${view.header.generation}, ${view.size} bytes`);
  for (const frame of view.frames) console.log(`${frame.offset}\t${describeRecord(frame.record)}`);
  if (view.tail) console.log(`${view.tail.offset}\tincomplete tail (${view.tail.reason}, ${view.tail.bytes} bytes)`);
}

function stats(dir) {
  const queue = openQueue(dir);
  console.log(JSON.stringify(queue.stats(), null, 2));
  queue.close();
}

function compact(dir) {
  const queue = openQueue(dir);
  console.log(JSON.stringify(queue.compact()));
  queue.close();
}

function metrics(dir) {
  const queue = openQueue(dir);
  console.log(JSON.stringify(queue.metrics(), null, 2));
  queue.close();
}

function requeue(dir, id) {
  const queue = openQueue(dir);
  console.log(JSON.stringify(queue.requeueDead(id)));
  queue.close();
}

function cancel(dir, id) {
  const queue = openQueue(dir);
  console.log(JSON.stringify(queue.cancel(id)));
  queue.close();
}

// Opens the log afresh on every poll and closes it again. A handle kept open
// would stop compaction from replacing the file, and would go on reading the old
// one after it had been replaced. The generation in the header tells when that
// happened, and the tail then starts over on the new log.
function tail(dir) {
  const file = path.join(dir, WAL_FILE);
  let offset = HEADER_SIZE;
  let generation = null;
  const poll = () => {
    try {
      pollOnce();
    } catch (err) {
      if (!['ENOENT', 'EPERM', 'EBUSY', 'EACCES'].includes(err.code)) throw err;
    }
  };
  const pollOnce = () => {
    let bytes;
    let size;
    let header;
    const fd = fs.openSync(file, 'r');
    try {
      size = fs.fstatSync(fd).size;
      header = Buffer.alloc(Math.min(HEADER_SIZE, size));
      fs.readSync(fd, header, 0, header.length, 0);
      const current = decodeHeader(header, file).generation;
      if (generation !== null && (current !== generation || size < offset)) {
        console.log(`log replaced by generation ${current}`);
        offset = HEADER_SIZE;
      }
      generation = current;
      if (size <= offset) return;
      bytes = Buffer.alloc(size - offset);
      fs.readSync(fd, bytes, 0, bytes.length, offset);
    } finally {
      fs.closeSync(fd);
    }
    const { frames, end } = scanFrames(bytes, offset);
    for (const frame of frames) console.log(describeRecord(frame.record));
    offset = end;
  };
  const timer = setInterval(poll, 200);
  process.on('SIGINT', () => clearInterval(timer));
}

const [command, dir, id] = process.argv.slice(2);
const commands = { inspect, stats, compact, tail, metrics, requeue, cancel };
if (!commands[command] || !dir) usage();
else commands[command](dir, id);
