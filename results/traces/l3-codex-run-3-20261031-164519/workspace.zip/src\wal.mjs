// The log file itself: a header, then checksummed frames, written only by the
// process holding the queue lock.

import path from 'node:path';
import { decodeHeader, encodeFrame, encodeHeader, HEADER_SIZE, scanFrames } from './frame.mjs';
import { hit, isArmed } from './failpoints.mjs';

// Bounds memory when a process has fallen far behind. Catching up reads the log
// in pieces of this size, or in one piece for a record that is bigger.
const SCAN_CHUNK = 1024 * 1024;

export class Wal {
  constructor(file, ops) {
    this.file = file;
    this.ops = ops;
  }

  exists() {
    return this.ops.exists(this.file);
  }

  /** Creates an empty log. The header appears atomically or not at all. */
  create(generation = 1) {
    const staging = `${this.file}.init`;
    this.ops.create(staging);
    this.ops.writeAt(staging, encodeHeader(generation), 0);
    this.ops.sync(staging);
    this.ops.rename(staging, this.file);
    hit('wal.after-create', {});
    this.ops.sync(this.file);
    this.ops.syncDir(path.dirname(this.file));
  }

  get asidePath() {
    return `${this.file}.old`;
  }

  /**
   * Called under the lock. If a compaction died between moving the old log aside
   * and putting the new one in place, the log is missing and its aside copy is
   * the committed state: put it back. Returns true if the log is there.
   */
  recover() {
    if (this.ops.exists(this.file)) return true;
    if (!this.ops.exists(this.asidePath)) return false;
    this.ops.rename(this.asidePath, this.file);
    this.ops.syncDir(path.dirname(this.file));
    return true;
  }

  readHeader() {
    return decodeHeader(this.ops.read(this.file, 0, HEADER_SIZE), this.file);
  }

  /**
   * Decodes everything from `offset` to the end of the file, a piece at a time.
   * `onFrames(frames, end)` gets each piece's frames and the offset after them.
   * Returns `{ end, tail }`: where the good frames stop, and what is left over.
   */
  scanFrom(offset, onFrames) {
    const size = this.ops.size(this.file);
    let pos = offset;
    let want = SCAN_CHUNK;
    while (pos < size) {
      const bytes = this.ops.read(this.file, pos, Math.min(want, size - pos));
      const atEof = pos + bytes.length >= size;
      const scan = scanFrames(bytes, pos, atEof);
      if (scan.frames.length) onFrames(scan.frames, scan.end);
      pos = scan.end;
      if (!scan.tail) {
        want = SCAN_CHUNK;
        continue;
      }
      if (atEof) return { end: pos, tail: scan.tail };
      want = Math.max(SCAN_CHUNK, scan.tail.needed ?? 0);
    }
    return { end: pos, tail: null };
  }

  truncate(length) {
    this.ops.truncate(this.file, length);
  }

  /**
   * Writes records at `at`, which is the end of the good log. Returns the new
   * end offset.
   */
  append(records, { sync = true, at = this.ops.size(this.file) } = {}) {
    const type = records[0]?.t;
    const bytes = Buffer.concat(records.map(encodeFrame));
    hit('wal.before-append', { type });
    if (isArmed('wal.mid-append')) {
      const half = bytes.length >> 1;
      this.ops.writeAt(this.file, bytes.subarray(0, half), at);
      hit('wal.mid-append', { type });
      this.ops.writeAt(this.file, bytes.subarray(half), at + half);
    } else {
      this.ops.writeAt(this.file, bytes, at);
    }
    hit('wal.after-write', { type });
    if (sync) this.ops.sync(this.file);
    hit('wal.after-fsync', { type });
    return at + bytes.length;
  }
}
