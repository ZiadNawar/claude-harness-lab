import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { test } from 'node:test';
import {
  clearFailpoints,
  CorruptLogError,
  ManualClock,
  onFailpoint,
  openQueue,
  StaleLeaseError,
  UnknownJobError,
} from '../src/index.mjs';
import { defer, tempDir } from './helpers/tmp.mjs';

class Crash extends Error {}

// Power-loss model on, and a throwing failpoint standing in for a kill. The
// queue object that "died" is dropped, taking its unsynced bytes with it.
function powerLoss(t) {
  const before = process.env.WALQ_SIMULATE_POWER_LOSS;
  process.env.WALQ_SIMULATE_POWER_LOSS = '1';
  defer(t, () => {
    clearFailpoints();
    if (before === undefined) delete process.env.WALQ_SIMULATE_POWER_LOSS;
    else process.env.WALQ_SIMULATE_POWER_LOSS = before;
  });
}

function crashAt(point, fn, type = null) {
  const off = onFailpoint(point, (ctx) => {
    if (type === null || ctx.type === type) throw new Crash(point);
  });
  try {
    assert.throws(fn, Crash);
  } finally {
    off();
  }
}

const OPTIONS = { backoff: { baseMs: 100, factor: 2, maxMs: 10_000 } };

function setup(t, extra = {}) {
  powerLoss(t);
  const clock = new ManualClock(1_000);
  const dir = tempDir(t);
  const open = (more = {}) => openQueue(dir, { clock, ...OPTIONS, ...extra, ...more });
  return { clock, dir, open, log: path.join(dir, 'wal.log') };
}

const WAL_POINTS = ['wal.before-append', 'wal.mid-append', 'wal.after-write'];

for (const point of WAL_POINTS) {
  test(`a crash at ${point} leaves a log that opens, and later writes survive`, (t) => {
    const { open, log } = setup(t);
    const queue = open();
    queue.enqueue('x', 'first');
    crashAt(point, () => queue.enqueue('x', 'lost'));
    const reopened = open();
    assert.deepEqual(reopened.listJobs().map((j) => j.payload), ['first']);
    reopened.enqueue('x', 'after');
    const third = open();
    assert.deepEqual(third.listJobs().map((j) => j.payload), ['first', 'after']);
    assert.ok(fs.statSync(log).size > 0);
  });
}

test('a torn tail does not poison records written after it, even with the file left as found', (t) => {
  const { open, log } = setup(t);
  const queue = open();
  queue.enqueue('x', 'first');
  queue.enqueue('x', 'second');
  fs.truncateSync(log, fs.statSync(log).size - 7);
  const writer = open();
  writer.enqueue('x', 'third');
  writer.enqueue('x', 'fourth');
  assert.deepEqual(open().listJobs().map((j) => j.payload), ['first', 'third', 'fourth']);
});

test('a log ending in zeros (a size change that outran the data) opens', (t) => {
  const { open, log } = setup(t);
  const queue = open();
  queue.enqueue('x', 'first');
  fs.appendFileSync(log, Buffer.alloc(300));
  const reopened = open();
  assert.equal(reopened.stats().total, 1);
  reopened.enqueue('x', 'second');
  assert.deepEqual(open().listJobs().map((j) => j.payload), ['first', 'second']);
});

test('damage in the middle of the log is reported with its offset and the file is left alone', (t) => {
  const { open, log } = setup(t);
  const queue = open();
  queue.enqueue('x', 'first');
  const start = fs.statSync(log).size;
  queue.enqueue('x', 'second');
  queue.enqueue('x', 'third');
  const bytes = fs.readFileSync(log);
  bytes[start + 14] ^= 0xff;
  fs.writeFileSync(log, bytes);
  assert.throws(
    () => open(),
    (err) => err instanceof CorruptLogError && err.offset === start,
  );
  assert.deepEqual(fs.readFileSync(log), bytes);
});

test('a large log with a cut tail opens and reads every record', (t) => {
  const { open, log } = setup(t, { compactAfterBytes: 0 });
  const queue = open();
  const padding = 'p'.repeat(3_000);
  for (let i = 0; i < 1_200; i += 1) queue.enqueue('x', { i, padding });
  assert.ok(fs.statSync(log).size > 3 * 1024 * 1024);
  fs.truncateSync(log, fs.statSync(log).size - 100);
  const reopened = open();
  assert.equal(reopened.stats().total, 1_199);
});

test('a record bigger than the read chunk can be written and read back', (t) => {
  const { open } = setup(t, { compactAfterBytes: 0 });
  const queue = open();
  queue.enqueue('x', 'a'.repeat(3 * 1024 * 1024));
  queue.enqueue('x', 'small');
  const reopened = open();
  assert.equal(reopened.stats().total, 2);
  assert.equal(reopened.getJob('j1').payload.length, 3 * 1024 * 1024);
});

test('a log shrunk by hand while a process holds it makes that process start over', (t) => {
  const { open, dir } = setup(t);
  const one = open();
  const two = open();
  one.enqueue('x', 1);
  one.compact();
  one.enqueue('x', 2);
  assert.equal(two.stats().total, 2);
  two.compact();
  two.enqueue('x', 3);
  assert.equal(one.stats().total, 3);
  assert.equal(fs.readdirSync(dir).filter((n) => n.startsWith('wal.log.')).length, 0);
});

test('a second process follows a compaction whose new log is bigger than the old one', (t) => {
  const { open } = setup(t);
  const one = open();
  const two = open();
  const { id } = one.enqueue('x', 'a');
  const job = one.claim('w');
  one.heartbeat(id, job.token);
  assert.equal(two.stats().leased, 1);
  one.compact();
  one.compact();
  const other = one.enqueue('x', 'b');
  assert.equal(two.getJob(other.id).payload, 'b');
});

for (const point of ['compact.after-tmp-write', 'compact.before-rename', 'compact.after-rename']) {
  test(`a crash at ${point} leaves a queue that works and can compact again`, (t) => {
    const { open, dir } = setup(t);
    const queue = open();
    queue.enqueue('x', 'a');
    queue.enqueue('x', 'b');
    crashAt(point, () => queue.compact());
    const reopened = open();
    assert.equal(reopened.stats().total, 2);
    reopened.enqueue('x', 'c');
    assert.equal(reopened.compact().jobs, 3);
    assert.equal(open().stats().total, 3);
    assert.deepEqual(
      fs.readdirSync(dir).filter((n) => n.startsWith('wal.log.')),
      [],
    );
  });
}

test('after a power cut right after compaction the log is not empty', (t) => {
  const { open, log } = setup(t);
  const queue = open();
  for (let i = 0; i < 5; i += 1) queue.enqueue('x', i);
  crashAt('compact.after-rename', () => queue.compact());
  assert.ok(fs.statSync(log).size > 20);
  assert.equal(open().stats().total, 5);
});

test('a log created and cut right away has a header', (t) => {
  const { dir, open } = setup(t);
  crashAt('wal.after-create', () => open());
  assert.equal(open().stats().total, 0);
  assert.ok(fs.statSync(path.join(dir, 'wal.log')).size >= 20);
});

test('compaction works while another process holds the log open', (t) => {
  const { open, log } = setup(t);
  const queue = open();
  queue.enqueue('x', 'a');
  const fd = fs.openSync(log, 'r');
  try {
    assert.equal(queue.compact().jobs, 1);
    queue.enqueue('x', 'b');
    assert.equal(queue.compact().jobs, 2);
  } finally {
    fs.closeSync(fd);
  }
  assert.equal(open().stats().total, 2);
});

test('a leftover compaction temp file does not block compaction', (t) => {
  const { open, log } = setup(t);
  const queue = open();
  queue.enqueue('x', 'a');
  fs.writeFileSync(`${log}.compact`, 'junk');
  assert.equal(queue.compact().jobs, 1);
  assert.equal(fs.existsSync(`${log}.compact`), false);
});

test('retry times, attempts and tokens survive restart and compaction', (t) => {
  const { open, clock } = setup(t);
  const queue = open();
  const { id } = queue.enqueue('x', null, { maxAttempts: 3 });
  let job = queue.claim('w');
  const { retryAt } = queue.fail(id, job.token, 'one');
  clock.advance(10_000_000);
  const reopened = open();
  assert.equal(reopened.getJob(id).availableAt, retryAt);
  reopened.compact();
  const again = open();
  assert.equal(again.getJob(id).availableAt, retryAt);
  assert.equal(again.getJob(id).attempts, 1);
  job = again.claim('w');
  assert.equal(job.attempt, 2);
  assert.equal(job.token, 2);
  again.fail(id, job.token, 'two');
  clock.advance(10_000);
  again.compact();
  job = open().claim('w');
  assert.equal(job.attempt, 3);
  assert.equal(open().fail(id, job.token, 'three').status, 'dead');
});

test('a retry delay is the same in every process', (t) => {
  const { open, clock } = setup(t);
  const one = open();
  const two = open();
  const { id } = one.enqueue('x', null);
  const job = one.claim('w');
  one.fail(id, job.token, 'boom');
  const due = one.getJob(id).availableAt;
  clock.advance(5_000);
  assert.equal(two.getJob(id).availableAt, due);
  assert.equal(open().getJob(id).availableAt, due);
});

test('compaction keeps priority, attempts, fence and lease', (t) => {
  const { open } = setup(t);
  const queue = open();
  queue.enqueue('x', 'low');
  const { id } = queue.enqueue('x', 'high', { priority: 5 });
  const job = queue.claim('w', { leaseMs: 5_000 });
  assert.equal(job.id, id);
  const before = queue.getJob(id);
  queue.compact();
  assert.deepEqual(open().getJob(id), before);
});

test('requeueing a dead job never reissues a token', (t) => {
  const { open, clock } = setup(t);
  const queue = open();
  const { id } = queue.enqueue('x', null, { maxAttempts: 1 });
  const first = queue.claim('w');
  queue.fail(id, first.token, 'dead now');
  queue.requeueDead(id);
  const second = queue.claim('w');
  assert.notEqual(second.token, first.token);
  assert.throws(() => queue.complete(id, first.token, 'late'), StaleLeaseError);
  clock.advance(1);
  assert.equal(queue.complete(id, second.token, 'ok').outcome, 'committed');
});

test('a key is still remembered after its job was pruned and the log compacted', (t) => {
  const { open, clock } = setup(t, { retainCompletedMs: 1_000 });
  const queue = open();
  const first = queue.enqueue('report', 1, { key: 'monthly' });
  const job = queue.claim('w');
  queue.complete(job.id, job.token, { sent: true });
  clock.advance(60_000);
  queue.compact();
  assert.equal(queue.getJob(first.id), null);
  for (const q of [queue, open()]) {
    const again = q.enqueue('report', 2, { key: 'monthly' });
    assert.equal(again.deduped, true);
    assert.equal(again.id, first.id);
    assert.deepEqual(again.result, { sent: true });
  }
  queue.compact();
  const third = open().enqueue('report', 3, { key: 'monthly' });
  assert.equal(third.deduped, true);
  clock.advance(7 * 24 * 3_600_000);
  assert.equal(open().enqueue('report', 4, { key: 'monthly' }).deduped, false);
});

test('two processes enqueueing the same key create one job', (t) => {
  const { open } = setup(t);
  const one = open();
  const two = open();
  one.stats();
  two.stats();
  const a = one.enqueue('x', 1, { key: 'k' });
  const b = two.enqueue('x', 2, { key: 'k' });
  assert.equal(a.id, b.id);
  assert.equal(b.deduped, true);
});

test('two processes cannot both claim the same job', (t) => {
  const { open } = setup(t);
  const one = open();
  const two = open();
  one.enqueue('x', null);
  two.stats();
  let second = null;
  let entered = false;
  const off = onFailpoint('claim.before-lock', () => {
    if (entered) return;
    entered = true;
    second = two.claim('w2');
  });
  const first = one.claim('w1');
  off();
  assert.ok(second);
  assert.equal(first, null);
});

test('a reaper that raced a heartbeat does not take a live worker\'s job', (t) => {
  const { open, clock } = setup(t);
  const worker = open();
  const reaper = open();
  const { id } = worker.enqueue('x', null);
  const job = worker.claim('w', { leaseMs: 500 });
  clock.advance(450);
  worker.heartbeat(id, job.token, { leaseMs: 500 });
  clock.advance(100);
  assert.deepEqual(reaper.reapExpired(), []);
  assert.equal(worker.complete(id, job.token, 'ok').outcome, 'committed');
});

test('a reaper that decided on stale state does not expire a lease renewed meanwhile', (t) => {
  const { open, clock } = setup(t);
  const worker = open();
  const reaper = open();
  const { id } = worker.enqueue('x', null);
  const job = worker.claim('w', { leaseMs: 500 });
  clock.advance(600);
  const off = onFailpoint('reap.before-lock', () => {
    clock.advance(-200);
    worker.heartbeat(id, job.token, { leaseMs: 500 });
    clock.advance(200);
  });
  const reaped = reaper.reapExpired();
  off();
  assert.deepEqual(reaped, []);
  assert.equal(worker.getJob(id).status, 'leased');
});

test('a token from a finished attempt cannot touch the next one', (t) => {
  const { open, clock } = setup(t);
  const queue = open();
  const { id } = queue.enqueue('x', null);
  const old = queue.claim('w1', { leaseMs: 100 });
  clock.advance(100);
  queue.reapExpired();
  clock.advance(1_000);
  const fresh = queue.claim('w2');
  assert.notEqual(fresh.token, old.token);
  assert.throws(() => queue.heartbeat(id, old.token), StaleLeaseError);
  assert.throws(() => queue.complete(id, old.token, 'x'), StaleLeaseError);
  assert.throws(() => queue.fail(id, old.token, 'x'), StaleLeaseError);
  assert.equal(queue.getJob(id).status, 'leased');
});

test('a heartbeat is seen by other processes', (t) => {
  const { open, clock } = setup(t);
  const one = open();
  const two = open();
  const { id } = one.enqueue('x', null);
  const job = one.claim('w', { leaseMs: 500 });
  clock.advance(400);
  one.heartbeat(id, job.token, { leaseMs: 500 });
  assert.equal(two.getJob(id).lease.until, 1_000 + 400 + 500);
});

test('automatic compaction does not run on every write when the state is big', (t) => {
  const { open, dir } = setup(t, { compactAfterBytes: 2_000 });
  const queue = open();
  const generation = () => queue.stats().generation;
  for (let i = 0; i < 40; i += 1) queue.enqueue('x', { i, pad: 'p'.repeat(100) });
  const before = generation();
  for (let i = 0; i < 40; i += 1) queue.enqueue('x', { i, pad: 'p'.repeat(100) });
  assert.ok(generation() - before <= 4, `compacted ${generation() - before} times for 40 writes`);
  assert.equal(open().stats().total, 80);
  assert.ok(fs.existsSync(dir));
});

test('a failed automatic compaction is retried later and reported', (t) => {
  const { open, log } = setup(t, { compactAfterBytes: 600 });
  const queue = open();
  fs.mkdirSync(`${log}.compact`);
  for (let i = 0; i < 20; i += 1) queue.enqueue('x', { i, pad: 'p'.repeat(40) });
  assert.match(queue.stats().lastCompactionError, /compaction failed/);
  assert.equal(queue.stats().total, 20);
  fs.rmSync(`${log}.compact`, { recursive: true });
  for (let i = 0; i < 20; i += 1) queue.enqueue('x', { i, pad: 'p'.repeat(40) });
  assert.equal(queue.stats().lastCompactionError, null);
  assert.ok(queue.stats().generation > 1);
});

test('an oversized record is refused before it touches the log', (t) => {
  const { open, log } = setup(t);
  const queue = open();
  queue.enqueue('x', 'a');
  const size = fs.statSync(log).size;
  assert.throws(() => queue.enqueue('x', 'a'.repeat(65 * 1024 * 1024)), /limit/);
  assert.equal(fs.statSync(log).size, size);
  assert.equal(queue.enqueue('x', 'b').id, 'j2');
});

test('replaying a log gives the same state whatever the clock says now', (t) => {
  const { open, clock } = setup(t);
  const queue = open();
  const { id } = queue.enqueue('x', null);
  const job = queue.claim('w');
  queue.fail(id, job.token, 'boom');
  const state = queue.getJob(id);
  clock.advance(123_456);
  assert.deepEqual(open().getJob(id), state);
});

// RFC 007

test('complete returns a receipt and a repeat is already-committed', (t) => {
  const { open, clock } = setup(t);
  const queue = open();
  const { id } = queue.enqueue('x', null);
  const job = queue.claim('w');
  clock.advance(5);
  const receipt = queue.complete(id, job.token, { a: 1 });
  assert.deepEqual(receipt, {
    id,
    outcome: 'committed',
    token: job.token,
    result: { a: 1 },
    completedAt: 1_005,
    completionSeq: 1,
  });
  const size = fs.statSync(path.join(queue.dir, 'wal.log')).size;
  clock.advance(500);
  const again = queue.complete(id, job.token, { a: 'ignored' });
  assert.deepEqual(again, { ...receipt, outcome: 'already-committed' });
  assert.equal(fs.statSync(path.join(queue.dir, 'wal.log')).size, size);
  queue.compact();
  assert.deepEqual(open().complete(id, job.token, 'ignored'), { ...receipt, outcome: 'already-committed' });
  assert.throws(() => queue.complete(id, job.token + 1, 'x'), StaleLeaseError);
  assert.throws(() => queue.complete('nope', 1, 'x'), UnknownJobError);
});

test('an expired lease can still commit until someone acts on it', (t) => {
  const { open, clock } = setup(t);
  const queue = open();
  const { id } = queue.enqueue('x', null);
  const job = queue.claim('w', { leaseMs: 100 });
  clock.advance(10_000);
  assert.equal(queue.complete(id, job.token, 'late').outcome, 'committed');
});

test('getResult and completions follow the RFC', (t) => {
  const { open, clock } = setup(t, { retainCompletedMs: 1_000 });
  const queue = open();
  const ids = ['a', 'b', 'c'].map((p) => queue.enqueue('x', p).id);
  assert.deepEqual(queue.getResult(ids[0]), { id: ids[0], status: 'ready' });
  assert.equal(queue.getResult('nope'), null);
  for (const id of ids) {
    const job = queue.claim('w');
    assert.equal(job.id, id);
    clock.advance(1);
    queue.complete(id, job.token, `r-${id}`);
  }
  assert.deepEqual(queue.getResult(ids[1]), {
    id: ids[1],
    status: 'done',
    result: `r-${ids[1]}`,
    token: 1,
    attempts: 1,
    completedAt: 1_002,
    completionSeq: 2,
  });
  assert.deepEqual(queue.completions().map((c) => c.seq), [1, 2, 3]);
  assert.deepEqual(queue.completions({ after: 1, limit: 1 }).map((c) => c.id), [ids[1]]);
  clock.advance(1_001);
  queue.compact();
  const next = queue.enqueue('x', 'd');
  const job = queue.claim('w');
  queue.complete(next.id, job.token, 'r');
  assert.deepEqual(open().completions({ after: 0 }).map((c) => c.seq), [4]);
  assert.equal(open().getResult(ids[0]), null);
});

test('reclaimWorker frees only that worker\'s jobs, at once, without backoff', (t) => {
  const { open } = setup(t);
  const queue = open();
  const [a, b, c] = ['a', 'b', 'c'].map((p) => queue.enqueue('x', p).id);
  const ja = queue.claim('dead');
  const jb = queue.claim('alive');
  const jc = queue.claim('dead');
  queue.complete(jc.id, jc.token, 'done already');
  assert.deepEqual(queue.reclaimWorker('dead', { reason: 'power' }), [{ id: a, status: 'ready' }]);
  assert.equal(queue.getJob(a).lastError, 'power');
  assert.equal(queue.getJob(b).status, 'leased');
  assert.equal(queue.getJob(c).status, 'done');
  assert.throws(() => queue.complete(a, ja.token, 'x'), StaleLeaseError);
  const again = queue.claim('w2');
  assert.equal(again.id, a);
  assert.equal(again.attempt, 2);
  assert.deepEqual(queue.reclaimWorker('nobody'), []);
  assert.ok(jb);
});

test('reclaimWorker sends a job out of attempts to dead', (t) => {
  const { open } = setup(t);
  const queue = open();
  const { id } = queue.enqueue('x', null, { maxAttempts: 1 });
  queue.claim('w');
  assert.deepEqual(queue.reclaimWorker('w'), [{ id, status: 'dead' }]);
  assert.equal(queue.getJob(id).status, 'dead');
});

// The crash table: commit point is the durable complete record.

const CRASH_TABLE = [
  ['wal.before-append', 'complete', true],
  ['wal.mid-append', 'complete', true],
  ['wal.after-write', 'complete', true],
  ['wal.after-fsync', 'complete', false],
];

for (const [point, type, reruns] of CRASH_TABLE) {
  test(`a crash at ${point} while completing ${reruns ? 'runs the job again' : 'does not'}`, (t) => {
    const { open, clock } = setup(t);
    const queue = open();
    const { id } = queue.enqueue('x', null);
    const job = queue.claim('w', { leaseMs: 100 });
    crashAt(point, () => queue.complete(id, job.token, 'r'), type);
    const after = open();
    if (reruns) {
      assert.equal(after.getJob(id).status, 'leased');
      clock.advance(100);
      after.reapExpired();
      clock.advance(10_000);
      assert.equal(after.claim('w2').id, id);
    } else {
      assert.equal(after.getJob(id).status, 'done');
      clock.advance(10_000);
      assert.equal(after.reapExpired().length, 0);
      assert.equal(after.claim('w2'), null);
      assert.equal(after.complete(id, job.token, 'x').outcome, 'already-committed');
    }
  });
}

test('a compaction killed while a completion is the newest record loses nothing', (t) => {
  for (const point of ['compact.after-tmp-write', 'compact.before-rename', 'compact.after-rename']) {
    const { open, clock } = setup(t);
    const queue = open();
    const { id } = queue.enqueue('x', null);
    const job = queue.claim('w');
    queue.complete(id, job.token, 'r');
    crashAt(point, () => queue.compact());
    clock.advance(1_000_000);
    const after = open();
    assert.equal(after.getJob(id).status, 'done');
    assert.equal(after.claim('w2'), null);
  }
});