// On-disk encoding of the log. The layout is specified in docs/wal-format.md and
// is a compatibility contract: logs already in production must stay readable.

import { crc32 } from './crc32.mjs';
import { CorruptLogError, WalqError } from './errors.mjs';

export const FORMAT_VERSION = 1;
export const HEADER_SIZE = 20;
export const FRAME_OVERHEAD = 10;

const FILE_MAGIC = Buffer.from('WALQ', 'latin1');
const FRAME_MAGIC = 0xfbad;
export const MAX_PAYLOAD = 64 * 1024 * 1024;

export function encodeHeader(generation) {
  const header = Buffer.alloc(HEADER_SIZE);
  FILE_MAGIC.copy(header, 0);
  header.writeUInt16LE(FORMAT_VERSION, 4);
  header.writeUInt32LE(generation, 8);
  header.writeUInt32LE(crc32(header.subarray(0, 16)), 16);
  return header;
}

export function decodeHeader(bytes, file = 'log') {
  if (bytes.length < HEADER_SIZE) {
    throw new CorruptLogError(`${file}: header is missing or short (${bytes.length} bytes)`, { offset: 0 });
  }
  if (!bytes.subarray(0, 4).equals(FILE_MAGIC)) {
    throw new CorruptLogError(`${file}: not a walq log`, { offset: 0 });
  }
  if (bytes.readUInt32LE(16) !== crc32(bytes.subarray(0, 16))) {
    throw new CorruptLogError(`${file}: header checksum mismatch`, { offset: 0 });
  }
  const version = bytes.readUInt16LE(4);
  if (version !== FORMAT_VERSION) {
    throw new CorruptLogError(`${file}: unsupported format version ${version}`, { offset: 0 });
  }
  return { version, generation: bytes.readUInt32LE(8) };
}

export function encodeFrame(record) {
  const payload = Buffer.from(JSON.stringify(record), 'utf8');
  if (payload.length > MAX_PAYLOAD) {
    throw new WalqError(`record of ${payload.length} bytes exceeds the ${MAX_PAYLOAD} byte limit`);
  }
  const frame = Buffer.allocUnsafe(FRAME_OVERHEAD + payload.length);
  frame.writeUInt16LE(FRAME_MAGIC, 0);
  frame.writeUInt32LE(payload.length, 2);
  frame.writeUInt32LE(crc32(payload, crc32(frame.subarray(2, 6))), 6);
  payload.copy(frame, FRAME_OVERHEAD);
  return frame;
}

function isZeroFilled(bytes, from) {
  for (let i = from; i < bytes.length; i += 1) if (bytes[i] !== 0) return false;
  return true;
}

// Result of looking at one frame: ok, a torn tail (`tail: true`), or damage.
// Only the last frame of the file can be torn: a write that was cut off leaves
// the file short, zero-filled, or with a last frame that does not check out.
function decodeFrameAt(bytes, pos, atEof) {
  const remaining = bytes.length - pos;
  if (remaining < FRAME_OVERHEAD) return { ok: false, tail: true, reason: 'partial' };
  if (bytes.readUInt16LE(pos) !== FRAME_MAGIC) {
    if (isZeroFilled(bytes, pos)) {
      if (atEof) return { ok: false, tail: true, reason: 'zero-filled' };
      return { ok: false, tail: true, reason: 'partial', needed: 2 * remaining + 1 };
    }
    return { ok: false, reason: 'bad-magic' };
  }
  const length = bytes.readUInt32LE(pos + 2);
  if (length > MAX_PAYLOAD) return { ok: false, reason: 'bad-length' };
  const total = FRAME_OVERHEAD + length;
  if (remaining < total) return { ok: false, tail: true, reason: 'partial', needed: total };
  const start = pos + FRAME_OVERHEAD;
  const payload = bytes.subarray(start, start + length);
  const expected = bytes.readUInt32LE(pos + 6);
  if (expected !== crc32(payload, crc32(bytes.subarray(pos + 2, pos + 6)))) {
    if (atEof && start + length === bytes.length) return { ok: false, tail: true, reason: 'bad-checksum' };
    return { ok: false, reason: 'bad-checksum' };
  }
  try {
    return { ok: true, record: JSON.parse(payload.toString('utf8')), next: start + length };
  } catch {
    return { ok: false, reason: 'bad-payload' };
  }
}

/**
 * Walks frames starting at the beginning of `bytes`, which sit at `baseOffset`
 * in the file. Returns the decoded frames, the file offset just after the last
 * good one, and `tail` when the bytes after that are not a complete frame.
 *
 * `atEof` says that `bytes` reaches the end of the file. Only there can a last
 * frame with a bad checksum, or trailing zeros, be called a torn write. Anything
 * else that does not check out is damage and throws CorruptLogError. When the
 * bytes stop short of the end of the file, `tail.needed` is the size of the
 * frame that did not fit, if known.
 */
export function scanFrames(bytes, baseOffset = 0, atEof = true) {
  const frames = [];
  let pos = 0;
  let tail = null;
  while (pos < bytes.length) {
    const decoded = decodeFrameAt(bytes, pos, atEof);
    if (!decoded.ok) {
      if (!decoded.tail) {
        throw new CorruptLogError(
          `corrupt record at offset ${baseOffset + pos} (${decoded.reason})`,
          { offset: baseOffset + pos, reason: decoded.reason },
        );
      }
      tail = {
        offset: baseOffset + pos,
        reason: decoded.reason,
        bytes: bytes.length - pos,
        needed: decoded.needed ?? null,
      };
      break;
    }
    frames.push({ offset: baseOffset + pos, size: decoded.next - pos, record: decoded.record });
    pos = decoded.next;
  }
  return { frames, end: baseOffset + pos, tail };
}
