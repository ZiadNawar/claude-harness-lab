// Store: the replayed state plus the rules for reading and writing the log.
// Every read of shared state and every write happens inside withLock(), which
// first brings this process up to date with whatever other processes wrote.

import path from 'node:path';
import { compactLog } from './compactor.mjs';
import { QueueClosedError } from './errors.mjs';
import { FORMAT_VERSION, HEADER_SIZE } from './frame.mjs';
import { createFileOps, ensureDir } from './fsops.mjs';
import { acquireLock } from './lock.mjs';
import { createLogger } from './logger.mjs';
import { applyRecord, createState } from './state.mjs';
import { Wal } from './wal.mjs';

export const WAL_FILE = 'wal.log';
export const LOCK_FILE = 'queue.lock';

const log = createLogger('store');

export class Store {
  constructor(dir, config) {
    this.dir = dir;
    this.config = config;
    this.clock = config.clock;
    this.ops = createFileOps();
    this.wal = new Wal(path.join(dir, WAL_FILE), this.ops);
    this.lockPath = path.join(dir, LOCK_FILE);
    this.state = createState();
    this.generation = null;
    this.offset = HEADER_SIZE;
    this.snapshotBytes = 0;
    this.tornTailsDropped = 0;
    this.tornTailAt = null;
    this.nextCompactAt = 0;
    this.lastCompactionError = null;
    this.closed = false;
    this.holdingLock = false;
  }

  open() {
    ensureDir(this.dir);
    this.#locked(() => {
      if (!this.wal.recover()) this.wal.create();
      this.catchUp();
    });
  }

  close() {
    this.closed = true;
  }

  #locked(fn) {
    if (this.holdingLock) throw new Error('queue lock is not reentrant');
    const release = acquireLock(this.lockPath, { timeoutMs: this.config.lockTimeoutMs });
    this.holdingLock = true;
    try {
      return fn();
    } finally {
      this.holdingLock = false;
      release();
    }
  }

  withLock(fn) {
    if (this.closed) throw new QueueClosedError();
    return this.#locked(() => {
      this.catchUp();
      return fn();
    });
  }

  /** Brings this.state up to date with the log without doing anything else. */
  refresh() {
    this.withLock(() => {});
  }

  /**
   * Replays what other processes appended since the last call. A different
   * generation in the header means the log was replaced by a compaction, so
   * whatever this process knew about the old file's offsets is worthless and
   * the state is rebuilt from the new one.
   */
  catchUp() {
    this.wal.recover();
    const header = this.wal.readHeader();
    if (
      this.generation !== header.generation ||
      this.ops.size(this.wal.file) < this.offset
    ) {
      this.state = createState();
      this.offset = HEADER_SIZE;
      this.generation = header.generation;
      this.snapshotBytes = 0;
      this.tornTailAt = null;
    }

    const { end, tail } = this.wal.scanFrom(this.offset, (frames, upTo) => {
      for (const frame of frames) {
        applyRecord(this.state, frame.record);
        if (frame.record.t === 'snapshot') this.snapshotBytes = frame.size;
      }
      this.offset = upTo;
    });
    this.offset = end;

    if (tail && this.tornTailAt !== end) {
      this.tornTailAt = end;
      this.tornTailsDropped += 1;
      log.warn('ignored incomplete tail', { offset: end, reason: tail.reason, bytes: tail.bytes });
    }
  }

  /**
   * Must be called inside withLock(). Anything in the file past the end of the
   * good log is the debris of a write that was cut off; it goes before new
   * records are written, or it would sit in front of them and make the log
   * unreadable.
   */
  append(records, options) {
    if (this.ops.size(this.wal.file) > this.offset) {
      this.wal.truncate(this.offset);
      this.tornTailAt = null;
    }
    this.offset = this.wal.append(records, { ...options, at: this.offset });
    for (const record of records) applyRecord(this.state, record);
  }

  /** Must be called inside withLock(). */
  compact() {
    const bytesBefore = this.offset;
    const { snapshot, generation, size } = compactLog({
      wal: this.wal,
      ops: this.ops,
      state: this.state,
      generation: this.generation,
      now: this.clock.now(),
      config: this.config,
    });
    this.state = createState();
    applyRecord(this.state, snapshot);
    this.generation = generation;
    this.offset = size;
    this.snapshotBytes = size - HEADER_SIZE;
    this.tornTailAt = null;
    this.nextCompactAt = 0;
    log.info('compacted', { generation, bytesBefore, bytesAfter: size });
    return { generation, bytesBefore, bytesAfter: size, jobs: this.state.jobs.size };
  }

  /**
   * Compacts when the log has outgrown the threshold. A failure here must not
   * fail the operation that triggered it, because that operation has committed.
   *
   * The log has to grow past twice the size of its own snapshot, so that when
   * the live state is bigger than the threshold, compaction still happens once
   * per doubling and not once per write. After a failure the next try waits for
   * the log to grow by another threshold.
   */
  maybeCompact() {
    const threshold = this.config.compactAfterBytes;
    if (!threshold) return;
    if (this.offset < Math.max(threshold, 2 * (HEADER_SIZE + this.snapshotBytes))) return;
    if (this.offset < this.nextCompactAt) return;
    try {
      this.compact();
      this.lastCompactionError = null;
    } catch (err) {
      this.lastCompactionError = err;
      this.nextCompactAt = this.offset + threshold;
      log.warn('compaction failed', { error: err.message });
    }
  }

  describe() {
    return {
      format: FORMAT_VERSION,
      generation: this.generation,
      logBytes: this.offset,
      tornTailsDropped: this.tornTailsDropped,
      lastCompactionError: this.lastCompactionError?.message ?? null,
    };
  }
}
