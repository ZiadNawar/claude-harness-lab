# Compaction

The log only grows, so from time to time it's replaced by a shorter one that says the same thing: a new header with the next generation, and one `snapshot` record.

## When

- `compact()` runs it on request.
- After any write, automatically, when the log has passed `compactAfterBytes`.

Automatic compaction waits until the log is also twice the size of its last snapshot, so a large live state does not make every write compact. After a failure it waits for the log to grow by another `compactAfterBytes`. A failed automatic compaction doesn't fail the call that triggered it, because that call has already committed. `stats().lastCompactionError` shows the last failure.

## How

Compaction runs under the queue lock, after catching up, so the state it writes is complete.

1. Build the snapshot from the current state, dropping finished jobs past `retainCompletedMs`.
2. Remove any `wal.log.compact` left by a compaction that died, then write the header and snapshot to a new one and sync it.
3. Rename it over `wal.log`. If the platform refuses because another process has the log open (a `tail`, a backup), the old log is renamed to `wal.log.old`, the new one takes its place, and `wal.log.old` is removed. A crash between the two renames leaves only `wal.log.old`, and the next process to open the queue puts it back.
4. Sync, and rebuild this process's state from the snapshot.

## What the snapshot holds

The jobs that are kept with all their fields, the counters the log needs to carry on, and the idempotency keys still within their time to live (with the outcome, for jobs that were pruned). See [guarantees.md](guarantees.md), G10 and G11.

## Other processes

A process that was reading the old log sees a different generation in the header next time it catches up, and starts again from the new one, whatever the sizes of the two logs.
