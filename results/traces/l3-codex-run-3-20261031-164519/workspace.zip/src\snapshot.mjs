// A compacted log starts with one snapshot record holding the state it replaces.

import { isPastRetention } from './retention.mjs';

function serializeJob(job) {
  return {
    id: job.id,
    type: job.type,
    payload: job.payload,
    key: job.key,
    priority: job.priority,
    status: job.status,
    attempts: job.attempts,
    fence: job.fence,
    maxAttempts: job.maxAttempts,
    availableAt: job.availableAt,
    lease: job.lease,
    result: job.result,
    lastError: job.lastError,
    enqueuedAt: job.enqueuedAt,
    completedAt: job.completedAt,
    completionSeq: job.completionSeq,
    seq: job.seq,
  };
}

/**
 * The keys still within their time to live. A key whose job is being pruned
 * keeps the job's final status and result, so a repeat still sees the outcome.
 */
function serializeKeys(state, pruned, now, config) {
  const keys = [];
  for (const [key, entry] of state.idem) {
    if (now - entry.at >= config.idempotencyTtlMs) continue;
    const item = { key, id: entry.id, at: entry.at };
    const job = state.jobs.get(entry.id);
    if (job && pruned.has(job.id)) {
      item.status = job.status;
      item.result = job.result ?? null;
    } else if (!job) {
      item.status = entry.status ?? 'done';
      item.result = entry.result ?? null;
    }
    keys.push(item);
  }
  return keys;
}

/** Builds the snapshot record, dropping terminal jobs past their retention. */
export function buildSnapshot(state, now, config) {
  const kept = [];
  const pruned = new Set();
  for (const job of state.jobs.values()) {
    if (isPastRetention(job, now, config)) pruned.add(job.id);
    else kept.push(job);
  }

  return {
    t: 'snapshot',
    at: now,
    seq: state.seq,
    completionSeq: state.completionSeq,
    jobs: kept.map(serializeJob),
    idem: serializeKeys(state, pruned, now, config),
  };
}

export function loadSnapshot(state, rec) {
  state.seq = rec.seq;
  state.completionSeq = rec.completionSeq ?? 0;
  state.jobs = new Map();
  state.idem = new Map();
  for (const job of rec.jobs) {
    state.jobs.set(job.id, {
      ...job,
      priority: job.priority ?? 0,
      attempts: job.attempts ?? 0,
      fence: job.fence ?? job.lease?.fence ?? job.attempts ?? 0,
      completionSeq: job.completionSeq ?? null,
    });
    const known = state.idem.get(job.key);
    if (job.key && (!known || known.at < job.enqueuedAt)) {
      state.idem.set(job.key, { id: job.id, at: job.enqueuedAt });
    }
  }
  for (const item of rec.idem ?? []) {
    const entry = { id: item.id, at: item.at };
    if (item.status !== undefined) {
      entry.status = item.status;
      entry.result = item.result ?? null;
    }
    state.idem.set(item.key, entry);
  }
}
